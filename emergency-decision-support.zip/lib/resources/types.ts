/**
 * Resource Management System Types
 */

import type { ResourceType, AgencyType } from '@/lib/protocols/types'

/**
 * Operational status of a resource unit
 */
export type UnitStatus = 
  | 'disponible'      // Available at base
  | 'en_camino'       // En route to incident
  | 'en_escena'       // On scene
  | 'operando'        // Actively working
  | 'retornando'      // Returning to base
  | 'fuera_servicio'  // Out of service (maintenance, break, etc.)

/**
 * GPS coordinates
 */
export interface Coordinates {
  lat: number
  lng: number
}

/**
 * Resource unit (vehicle, team, etc.)
 */
export interface ResourceUnit {
  id: string
  code: string                    // e.g., "B-1", "A-03", "PL-05"
  type: ResourceType
  agency: AgencyType
  name: string                    // e.g., "Bomba Pesada 1", "Ambulancia SVB 03"
  status: UnitStatus
  currentLocation?: Coordinates
  baseLocation: Coordinates
  currentIncidentId?: string
  
  // Capabilities
  capabilities: string[]          // e.g., ["extincion", "rescate_altura"]
  crewSize: number
  
  // Timing
  lastStatusChange: string
  estimatedArrival?: string
  
  // Contact
  radioChannel?: string
  phoneNumber?: string
}

/**
 * Resource assignment to an incident
 */
export interface ResourceAssignment {
  id: string
  unitId: string
  incidentId: string
  assignedAt: string
  assignedBy: string              // Operator ID
  
  // Status tracking
  dispatchedAt?: string
  arrivedAt?: string
  operatingAt?: string
  releasedAt?: string
  
  // Notes
  notes: string[]
  tasks: string[]
}

/**
 * Base/station where resources are located
 */
export interface ResourceBase {
  id: string
  name: string
  agency: AgencyType
  location: Coordinates
  address: string
  units: string[]                 // Unit IDs stationed here
  contactPhone: string
}

/**
 * Resource request from incident
 */
export interface ResourceRequest {
  id: string
  incidentId: string
  requestedAt: string
  requestedBy: string
  resourceType: ResourceType
  quantity: number
  priority: 'urgente' | 'normal' | 'baja'
  status: 'pendiente' | 'asignado' | 'rechazado'
  notes?: string
  assignedUnits?: string[]
}

/**
 * Resource availability summary
 */
export interface ResourceAvailability {
  type: ResourceType
  total: number
  available: number
  enRoute: number
  onScene: number
  outOfService: number
}

/**
 * Resource deployment recommendation
 */
export interface DeploymentRecommendation {
  unitId: string
  unit: ResourceUnit
  estimatedTime: number           // minutes
  distance: number                // km
  score: number                   // 0-100, higher is better
  reasons: string[]
}
