/**
 * Resource Management Store
 * In-memory store for managing emergency resources
 */

import type { 
  ResourceUnit, 
  ResourceAssignment, 
  ResourceBase,
  ResourceAvailability,
  DeploymentRecommendation,
  UnitStatus 
} from './types'
import type { ResourceType, AgencyType } from '@/lib/protocols/types'

// Sample resource units
const SAMPLE_UNITS: ResourceUnit[] = [
  // Bomberos
  {
    id: 'unit-b1',
    code: 'B-1',
    type: 'bomberos',
    agency: 'bomberos',
    name: 'Bomba Pesada 1',
    status: 'disponible',
    baseLocation: { lat: 40.4168, lng: -3.7038 },
    capabilities: ['extincion', 'rescate_basico', 'ventilacion'],
    crewSize: 6,
    lastStatusChange: new Date().toISOString(),
    radioChannel: 'Canal 1',
  },
  {
    id: 'unit-b2',
    code: 'B-2',
    type: 'bomberos',
    agency: 'bomberos',
    name: 'Bomba Pesada 2',
    status: 'disponible',
    baseLocation: { lat: 40.4200, lng: -3.6900 },
    capabilities: ['extincion', 'rescate_altura', 'hazmat'],
    crewSize: 6,
    lastStatusChange: new Date().toISOString(),
    radioChannel: 'Canal 1',
  },
  {
    id: 'unit-b3',
    code: 'AE-1',
    type: 'bomberos',
    agency: 'bomberos',
    name: 'Autoescala 1',
    status: 'disponible',
    baseLocation: { lat: 40.4168, lng: -3.7038 },
    capabilities: ['rescate_altura', 'ventilacion'],
    crewSize: 3,
    lastStatusChange: new Date().toISOString(),
    radioChannel: 'Canal 1',
  },
  // Ambulancias
  {
    id: 'unit-a1',
    code: 'A-01',
    type: 'ambulancia',
    agency: 'servicios_medicos',
    name: 'Ambulancia SVB 01',
    status: 'disponible',
    baseLocation: { lat: 40.4100, lng: -3.7100 },
    capabilities: ['soporte_vital_basico', 'trauma'],
    crewSize: 2,
    lastStatusChange: new Date().toISOString(),
    radioChannel: 'Canal 3',
  },
  {
    id: 'unit-a2',
    code: 'A-02',
    type: 'ambulancia',
    agency: 'servicios_medicos',
    name: 'Ambulancia SVB 02',
    status: 'en_camino',
    currentLocation: { lat: 40.4150, lng: -3.7050 },
    baseLocation: { lat: 40.4100, lng: -3.7100 },
    capabilities: ['soporte_vital_basico', 'pediatrico'],
    crewSize: 2,
    lastStatusChange: new Date().toISOString(),
    currentIncidentId: 'inc-sample-1',
    radioChannel: 'Canal 3',
  },
  {
    id: 'unit-samu1',
    code: 'SAMU-1',
    type: 'samu',
    agency: 'servicios_medicos',
    name: 'UVI Movil 1',
    status: 'disponible',
    baseLocation: { lat: 40.4200, lng: -3.7000 },
    capabilities: ['soporte_vital_avanzado', 'cardiologia', 'pediatrico'],
    crewSize: 3,
    lastStatusChange: new Date().toISOString(),
    radioChannel: 'Canal 3',
  },
  // Policia
  {
    id: 'unit-pl1',
    code: 'PL-01',
    type: 'policia_local',
    agency: 'policia',
    name: 'Patrulla Local 01',
    status: 'disponible',
    baseLocation: { lat: 40.4180, lng: -3.7020 },
    capabilities: ['trafico', 'seguridad_ciudadana'],
    crewSize: 2,
    lastStatusChange: new Date().toISOString(),
    radioChannel: 'Canal 2',
  },
  {
    id: 'unit-pl2',
    code: 'PL-02',
    type: 'policia_local',
    agency: 'policia',
    name: 'Patrulla Local 02',
    status: 'operando',
    currentLocation: { lat: 40.4140, lng: -3.7080 },
    baseLocation: { lat: 40.4180, lng: -3.7020 },
    capabilities: ['trafico', 'atencion_victimas'],
    crewSize: 2,
    lastStatusChange: new Date().toISOString(),
    currentIncidentId: 'inc-sample-2',
    radioChannel: 'Canal 2',
  },
  // Proteccion Civil
  {
    id: 'unit-pc1',
    code: 'PC-01',
    type: 'proteccion_civil',
    agency: 'proteccion_civil',
    name: 'Unidad Logistica 01',
    status: 'disponible',
    baseLocation: { lat: 40.4220, lng: -3.6950 },
    capabilities: ['logistica', 'evacuacion', 'albergue'],
    crewSize: 4,
    lastStatusChange: new Date().toISOString(),
    radioChannel: 'Canal 5',
  },
  // HAZMAT
  {
    id: 'unit-hz1',
    code: 'HAZMAT-1',
    type: 'hazmat',
    agency: 'bomberos',
    name: 'Unidad NBQ',
    status: 'disponible',
    baseLocation: { lat: 40.4168, lng: -3.7038 },
    capabilities: ['quimico', 'biologico', 'radiologico', 'descontaminacion'],
    crewSize: 4,
    lastStatusChange: new Date().toISOString(),
    radioChannel: 'Canal 1',
  },
  // Grua
  {
    id: 'unit-gr1',
    code: 'GR-01',
    type: 'grua',
    agency: 'ayuntamiento',
    name: 'Grua Pesada 01',
    status: 'disponible',
    baseLocation: { lat: 40.4130, lng: -3.7150 },
    capabilities: ['retirada_vehiculos', 'pesados'],
    crewSize: 1,
    lastStatusChange: new Date().toISOString(),
    phoneNumber: '+34 600 000 001',
  },
]

const SAMPLE_BASES: ResourceBase[] = [
  {
    id: 'base-bomberos-central',
    name: 'Parque Central de Bomberos',
    agency: 'bomberos',
    location: { lat: 40.4168, lng: -3.7038 },
    address: 'Calle Mayor 1, Madrid',
    units: ['unit-b1', 'unit-b3', 'unit-hz1'],
    contactPhone: '+34 112',
  },
  {
    id: 'base-bomberos-norte',
    name: 'Parque Norte de Bomberos',
    agency: 'bomberos',
    location: { lat: 40.4200, lng: -3.6900 },
    address: 'Av. Norte 50, Madrid',
    units: ['unit-b2'],
    contactPhone: '+34 112',
  },
  {
    id: 'base-samur',
    name: 'Base SAMUR Central',
    agency: 'servicios_medicos',
    location: { lat: 40.4100, lng: -3.7100 },
    address: 'Plaza Salud 5, Madrid',
    units: ['unit-a1', 'unit-a2', 'unit-samu1'],
    contactPhone: '+34 061',
  },
]

// In-memory stores
let units: ResourceUnit[] = [...SAMPLE_UNITS]
let assignments: ResourceAssignment[] = []
const bases: ResourceBase[] = [...SAMPLE_BASES]

/**
 * Resource Store Class
 */
export class ResourceStore {
  /**
   * Get all units
   */
  static getAllUnits(): ResourceUnit[] {
    return [...units]
  }
  
  /**
   * Get unit by ID
   */
  static getUnitById(id: string): ResourceUnit | null {
    return units.find(u => u.id === id) || null
  }
  
  /**
   * Get units by type
   */
  static getUnitsByType(type: ResourceType): ResourceUnit[] {
    return units.filter(u => u.type === type)
  }
  
  /**
   * Get units by agency
   */
  static getUnitsByAgency(agency: AgencyType): ResourceUnit[] {
    return units.filter(u => u.agency === agency)
  }
  
  /**
   * Get available units by type
   */
  static getAvailableUnitsByType(type: ResourceType): ResourceUnit[] {
    return units.filter(u => u.type === type && u.status === 'disponible')
  }
  
  /**
   * Get units assigned to an incident
   */
  static getUnitsForIncident(incidentId: string): ResourceUnit[] {
    return units.filter(u => u.currentIncidentId === incidentId)
  }
  
  /**
   * Update unit status
   */
  static updateUnitStatus(
    unitId: string, 
    status: UnitStatus, 
    incidentId?: string,
    location?: { lat: number; lng: number }
  ): ResourceUnit | null {
    const unitIndex = units.findIndex(u => u.id === unitId)
    if (unitIndex === -1) return null
    
    units[unitIndex] = {
      ...units[unitIndex],
      status,
      currentIncidentId: incidentId,
      currentLocation: location || units[unitIndex].currentLocation,
      lastStatusChange: new Date().toISOString(),
    }
    
    return units[unitIndex]
  }
  
  /**
   * Assign unit to incident
   */
  static assignUnitToIncident(
    unitId: string,
    incidentId: string,
    operatorId: string
  ): ResourceAssignment | null {
    const unit = this.getUnitById(unitId)
    if (!unit || unit.status !== 'disponible') return null
    
    // Update unit status
    this.updateUnitStatus(unitId, 'en_camino', incidentId)
    
    // Create assignment
    const assignment: ResourceAssignment = {
      id: `assign-${Date.now()}`,
      unitId,
      incidentId,
      assignedAt: new Date().toISOString(),
      assignedBy: operatorId,
      dispatchedAt: new Date().toISOString(),
      notes: [],
      tasks: [],
    }
    
    assignments.push(assignment)
    return assignment
  }
  
  /**
   * Release unit from incident
   */
  static releaseUnit(unitId: string): ResourceUnit | null {
    const unit = this.getUnitById(unitId)
    if (!unit) return null
    
    // Update assignment
    const assignment = assignments.find(
      a => a.unitId === unitId && !a.releasedAt
    )
    if (assignment) {
      assignment.releasedAt = new Date().toISOString()
    }
    
    // Update unit
    return this.updateUnitStatus(unitId, 'retornando', undefined)
  }
  
  /**
   * Get resource availability summary
   */
  static getAvailabilitySummary(): ResourceAvailability[] {
    const types: ResourceType[] = [
      'bomberos', 'ambulancia', 'samu', 'policia_local', 
      'proteccion_civil', 'hazmat', 'grua'
    ]
    
    return types.map(type => {
      const typeUnits = units.filter(u => u.type === type)
      return {
        type,
        total: typeUnits.length,
        available: typeUnits.filter(u => u.status === 'disponible').length,
        enRoute: typeUnits.filter(u => u.status === 'en_camino').length,
        onScene: typeUnits.filter(u => 
          u.status === 'en_escena' || u.status === 'operando'
        ).length,
        outOfService: typeUnits.filter(u => u.status === 'fuera_servicio').length,
      }
    }).filter(a => a.total > 0)
  }
  
  /**
   * Get deployment recommendations for a resource type
   * Returns units sorted by estimated response time
   */
  static getDeploymentRecommendations(
    type: ResourceType,
    targetLocation?: { lat: number; lng: number }
  ): DeploymentRecommendation[] {
    const availableUnits = this.getAvailableUnitsByType(type)
    
    if (!targetLocation) {
      // Without location, just return available units with basic scoring
      return availableUnits.map(unit => ({
        unitId: unit.id,
        unit,
        estimatedTime: 10, // Default 10 min
        distance: 5,       // Default 5 km
        score: 80,
        reasons: ['Unidad disponible'],
      }))
    }
    
    // Calculate distances and scores
    return availableUnits.map(unit => {
      const location = unit.currentLocation || unit.baseLocation
      const distance = this.calculateDistance(location, targetLocation)
      const estimatedTime = Math.round(distance * 2) // ~30 km/h avg in urban
      
      // Score: lower time = higher score
      const timeScore = Math.max(0, 100 - estimatedTime * 5)
      const capabilityScore = unit.capabilities.length * 5
      const score = Math.min(100, timeScore + capabilityScore)
      
      const reasons: string[] = []
      if (distance < 3) reasons.push('Muy cercana')
      else if (distance < 5) reasons.push('Cercana')
      if (unit.capabilities.length > 3) reasons.push('Multipropósito')
      if (unit.crewSize >= 4) reasons.push('Dotacion completa')
      
      return {
        unitId: unit.id,
        unit,
        estimatedTime,
        distance: Math.round(distance * 10) / 10,
        score,
        reasons: reasons.length > 0 ? reasons : ['Unidad disponible'],
      }
    }).sort((a, b) => b.score - a.score)
  }
  
  /**
   * Calculate distance between two points (Haversine formula)
   */
  private static calculateDistance(
    point1: { lat: number; lng: number },
    point2: { lat: number; lng: number }
  ): number {
    const R = 6371 // Earth radius in km
    const dLat = this.toRad(point2.lat - point1.lat)
    const dLng = this.toRad(point2.lng - point1.lng)
    const a = 
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRad(point1.lat)) * Math.cos(this.toRad(point2.lat)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  }
  
  private static toRad(deg: number): number {
    return deg * (Math.PI / 180)
  }
  
  /**
   * Get all bases
   */
  static getAllBases(): ResourceBase[] {
    return [...bases]
  }
  
  /**
   * Get assignments for an incident
   */
  static getAssignmentsForIncident(incidentId: string): ResourceAssignment[] {
    return assignments.filter(a => a.incidentId === incidentId)
  }
}
