/**
 * Protocol System Types
 * Defines structures for emergency response protocols
 */

import type { IncidentType, PriorityLevel } from '@/lib/types'

/**
 * Resource types available in the system
 */
export type ResourceType =
  | 'bomberos'
  | 'ambulancia'
  | 'policia_local'
  | 'policia_nacional'
  | 'guardia_civil'
  | 'proteccion_civil'
  | 'samu'
  | 'usar' // Urban Search and Rescue
  | 'hazmat'
  | 'grua'
  | 'helicoptero'
  | 'k9' // Unidad canina
  | 'coordinador'

/**
 * Agency types for multi-agency coordination
 */
export type AgencyType =
  | 'bomberos'
  | 'servicios_medicos'
  | 'policia'
  | 'proteccion_civil'
  | 'ayuntamiento'
  | 'compania_servicios' // Gas, electricidad, agua

/**
 * Resource requirement with quantity
 */
export interface ResourceRequirement {
  type: ResourceType
  quantity: number
  priority: 'obligatorio' | 'recomendado' | 'opcional'
  notes?: string
}

/**
 * Single step in a protocol
 */
export interface ProtocolStep {
  id: string
  order: number
  action: string
  description: string
  responsible: AgencyType
  timeLimit?: string // e.g., "inmediato", "5 min", "15 min"
  isCritical: boolean
  checkpoints?: string[]
  warnings?: string[]
}

/**
 * Communication flow between agencies
 */
export interface CommunicationFlow {
  from: AgencyType
  to: AgencyType
  channel: 'radio' | 'telefono' | 'presencial' | 'digital'
  message: string
  timing: string
}

/**
 * Escalation criteria
 */
export interface EscalationCriteria {
  condition: string
  newPriority: PriorityLevel
  additionalResources: ResourceRequirement[]
  notifyAgencies: AgencyType[]
}

/**
 * Complete protocol definition
 */
export interface Protocol {
  id: string
  name: string
  incidentType: IncidentType
  applicablePriorities: PriorityLevel[]
  description: string
  objectives: string[]
  
  // Phase 1: Initial Response
  initialAssessment: ProtocolStep[]
  
  // Phase 2: Resource Deployment
  resourceRequirements: {
    minimum: ResourceRequirement[]
    byPriority: Record<PriorityLevel, ResourceRequirement[]>
  }
  
  // Phase 3: Operational Actions
  operationalSteps: ProtocolStep[]
  
  // Phase 4: Coordination
  coordinationFlows: CommunicationFlow[]
  
  // Escalation
  escalationCriteria: EscalationCriteria[]
  
  // Safety
  safetyConsiderations: string[]
  
  // Metadata
  legalReferences?: string[]
  lastUpdated: string
  version: string
}

/**
 * Protocol execution state
 */
export interface ProtocolExecution {
  protocolId: string
  incidentId: string
  startedAt: string
  currentPhase: 'assessment' | 'deployment' | 'operations' | 'coordination' | 'closure'
  completedSteps: string[]
  skippedSteps: string[]
  notes: string[]
  assignedResources: {
    resourceType: ResourceType
    unitId: string
    assignedAt: string
    status: 'en_camino' | 'en_escena' | 'operando' | 'liberado'
  }[]
}

/**
 * Command chain position
 */
export interface CommandPosition {
  role: string
  agency: AgencyType
  responsibilities: string[]
  reportsTo?: string
  supervises?: string[]
}

/**
 * Incident Command Structure
 */
export interface CommandStructure {
  incidentType: IncidentType
  priority: PriorityLevel
  positions: CommandPosition[]
  coordinationPoint: string
}
