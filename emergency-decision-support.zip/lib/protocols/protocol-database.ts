/**
 * Protocol Database
 * Contains predefined emergency response protocols
 */

import type { Protocol, CommandStructure } from './types'

/**
 * Fire Emergency Protocol
 */
export const PROTOCOL_INCENDIO: Protocol = {
  id: 'proto-incendio-001',
  name: 'Protocolo de Incendio Urbano',
  incidentType: 'incendio',
  applicablePriorities: ['critica', 'alta', 'media', 'baja'],
  description: 'Protocolo estandar para la gestion de incendios en entorno urbano, incluyendo viviendas, comercios e industrias.',
  
  objectives: [
    'Salvaguardar vidas humanas',
    'Controlar y extinguir el fuego',
    'Proteger bienes y propiedades',
    'Preservar evidencias para investigacion',
  ],
  
  initialAssessment: [
    {
      id: 'inc-assess-1',
      order: 1,
      action: 'Confirmar ubicacion exacta',
      description: 'Verificar direccion, puntos de referencia y accesos al lugar',
      responsible: 'bomberos',
      timeLimit: 'inmediato',
      isCritical: true,
      checkpoints: ['Direccion confirmada', 'Accesos identificados'],
    },
    {
      id: 'inc-assess-2',
      order: 2,
      action: 'Evaluar magnitud del incendio',
      description: 'Determinar extension, tipo de fuego y estructuras afectadas',
      responsible: 'bomberos',
      timeLimit: '2 min',
      isCritical: true,
      checkpoints: ['Tipo de fuego identificado', 'Extension estimada'],
    },
    {
      id: 'inc-assess-3',
      order: 3,
      action: 'Verificar personas atrapadas',
      description: 'Confirmar si hay victimas o personas en peligro',
      responsible: 'bomberos',
      timeLimit: '2 min',
      isCritical: true,
      warnings: ['Priorizar rescate sobre extincion si hay victimas'],
    },
    {
      id: 'inc-assess-4',
      order: 4,
      action: 'Identificar riesgos adicionales',
      description: 'Evaluar presencia de materiales peligrosos, instalaciones de gas, electricidad',
      responsible: 'bomberos',
      timeLimit: '3 min',
      isCritical: true,
      warnings: ['Solicitar HAZMAT si hay materiales peligrosos'],
    },
  ],
  
  resourceRequirements: {
    minimum: [
      { type: 'bomberos', quantity: 1, priority: 'obligatorio', notes: 'Unidad de extincion' },
      { type: 'ambulancia', quantity: 1, priority: 'obligatorio', notes: 'Soporte vital basico' },
    ],
    byPriority: {
      critica: [
        { type: 'bomberos', quantity: 3, priority: 'obligatorio', notes: 'Incluir unidad de rescate' },
        { type: 'ambulancia', quantity: 2, priority: 'obligatorio', notes: 'SVA y SVB' },
        { type: 'samu', quantity: 1, priority: 'obligatorio' },
        { type: 'policia_local', quantity: 2, priority: 'obligatorio', notes: 'Control de trafico y perimetro' },
        { type: 'coordinador', quantity: 1, priority: 'obligatorio' },
      ],
      alta: [
        { type: 'bomberos', quantity: 2, priority: 'obligatorio' },
        { type: 'ambulancia', quantity: 1, priority: 'obligatorio' },
        { type: 'policia_local', quantity: 1, priority: 'recomendado' },
      ],
      media: [
        { type: 'bomberos', quantity: 1, priority: 'obligatorio' },
        { type: 'ambulancia', quantity: 1, priority: 'recomendado' },
      ],
      baja: [
        { type: 'bomberos', quantity: 1, priority: 'obligatorio' },
      ],
    },
  },
  
  operationalSteps: [
    {
      id: 'inc-op-1',
      order: 1,
      action: 'Establecer perimetro de seguridad',
      description: 'Delimitar zona de exclusion y punto de encuentro',
      responsible: 'policia',
      timeLimit: '5 min',
      isCritical: true,
    },
    {
      id: 'inc-op-2',
      order: 2,
      action: 'Evacuar zona afectada',
      description: 'Coordinar evacuacion de edificios adyacentes si es necesario',
      responsible: 'proteccion_civil',
      timeLimit: '10 min',
      isCritical: true,
    },
    {
      id: 'inc-op-3',
      order: 3,
      action: 'Corte de suministros',
      description: 'Solicitar corte de gas y electricidad en la zona',
      responsible: 'bomberos',
      timeLimit: '15 min',
      isCritical: true,
      warnings: ['No entrar si no se confirma corte de gas'],
    },
    {
      id: 'inc-op-4',
      order: 4,
      action: 'Iniciar extincion',
      description: 'Aplicar tecnicas de extincion segun tipo de fuego',
      responsible: 'bomberos',
      timeLimit: 'variable',
      isCritical: true,
    },
    {
      id: 'inc-op-5',
      order: 5,
      action: 'Busqueda y rescate',
      description: 'Rastreo sistematico de victimas en estructura',
      responsible: 'bomberos',
      isCritical: true,
      warnings: ['Usar ERA obligatorio', 'Mantener comunicacion constante'],
    },
    {
      id: 'inc-op-6',
      order: 6,
      action: 'Atencion sanitaria',
      description: 'Triaje y atencion de victimas',
      responsible: 'servicios_medicos',
      isCritical: true,
    },
  ],
  
  coordinationFlows: [
    {
      from: 'bomberos',
      to: 'servicios_medicos',
      channel: 'radio',
      message: 'Numero de victimas y estado',
      timing: 'Al detectar victimas',
    },
    {
      from: 'bomberos',
      to: 'policia',
      channel: 'radio',
      message: 'Solicitud de perimetro y control de accesos',
      timing: 'Al llegar a escena',
    },
    {
      from: 'bomberos',
      to: 'compania_servicios',
      channel: 'telefono',
      message: 'Solicitud de corte de suministros',
      timing: 'Antes de entrar en estructura',
    },
  ],
  
  escalationCriteria: [
    {
      condition: 'Propagacion a edificios adyacentes',
      newPriority: 'critica',
      additionalResources: [
        { type: 'bomberos', quantity: 2, priority: 'obligatorio' },
        { type: 'proteccion_civil', quantity: 1, priority: 'obligatorio' },
      ],
      notifyAgencies: ['ayuntamiento', 'proteccion_civil'],
    },
    {
      condition: 'Mas de 5 victimas',
      newPriority: 'critica',
      additionalResources: [
        { type: 'ambulancia', quantity: 3, priority: 'obligatorio' },
        { type: 'samu', quantity: 1, priority: 'obligatorio' },
      ],
      notifyAgencies: ['servicios_medicos'],
    },
    {
      condition: 'Materiales peligrosos detectados',
      newPriority: 'critica',
      additionalResources: [
        { type: 'hazmat', quantity: 1, priority: 'obligatorio' },
      ],
      notifyAgencies: ['proteccion_civil'],
    },
  ],
  
  safetyConsiderations: [
    'Uso obligatorio de ERA en interiores con humo',
    'Mantener distancia de seguridad con estructuras debilitadas',
    'No entrar en estructura hasta confirmar corte de gas',
    'Rotacion de equipos cada 20 minutos en ambientes calurosos',
    'Hidratacion constante del personal',
  ],
  
  legalReferences: [
    'Ley 17/2015 del Sistema Nacional de Proteccion Civil',
    'RD 393/2007 Norma Basica de Autoproteccion',
    'Ordenanza municipal de prevencion de incendios',
  ],
  
  lastUpdated: '2024-01-15',
  version: '2.1',
}

/**
 * Traffic Accident Protocol
 */
export const PROTOCOL_ACCIDENTE: Protocol = {
  id: 'proto-accidente-001',
  name: 'Protocolo de Accidente de Trafico',
  incidentType: 'accidente',
  applicablePriorities: ['critica', 'alta', 'media', 'baja'],
  description: 'Protocolo para la gestion de accidentes de trafico con posibles victimas.',
  
  objectives: [
    'Asistir a las victimas',
    'Asegurar la zona del accidente',
    'Restablecer la circulacion',
    'Preservar evidencias para investigacion',
  ],
  
  initialAssessment: [
    {
      id: 'acc-assess-1',
      order: 1,
      action: 'Confirmar ubicacion y via',
      description: 'Verificar punto kilometrico, direccion y sentido de circulacion',
      responsible: 'policia',
      timeLimit: 'inmediato',
      isCritical: true,
    },
    {
      id: 'acc-assess-2',
      order: 2,
      action: 'Evaluar numero de vehiculos y victimas',
      description: 'Determinar gravedad del accidente y necesidades sanitarias',
      responsible: 'servicios_medicos',
      timeLimit: '2 min',
      isCritical: true,
    },
    {
      id: 'acc-assess-3',
      order: 3,
      action: 'Identificar riesgos',
      description: 'Evaluar derrame de combustible, mercancias peligrosas, riesgo de incendio',
      responsible: 'bomberos',
      timeLimit: '3 min',
      isCritical: true,
    },
  ],
  
  resourceRequirements: {
    minimum: [
      { type: 'policia_local', quantity: 1, priority: 'obligatorio' },
      { type: 'ambulancia', quantity: 1, priority: 'obligatorio' },
    ],
    byPriority: {
      critica: [
        { type: 'ambulancia', quantity: 2, priority: 'obligatorio' },
        { type: 'samu', quantity: 1, priority: 'obligatorio' },
        { type: 'bomberos', quantity: 1, priority: 'obligatorio', notes: 'Excarcelacion' },
        { type: 'policia_local', quantity: 2, priority: 'obligatorio' },
        { type: 'grua', quantity: 1, priority: 'recomendado' },
        { type: 'helicoptero', quantity: 1, priority: 'opcional', notes: 'Si evacuacion urgente' },
      ],
      alta: [
        { type: 'ambulancia', quantity: 1, priority: 'obligatorio' },
        { type: 'bomberos', quantity: 1, priority: 'recomendado' },
        { type: 'policia_local', quantity: 1, priority: 'obligatorio' },
        { type: 'grua', quantity: 1, priority: 'recomendado' },
      ],
      media: [
        { type: 'ambulancia', quantity: 1, priority: 'recomendado' },
        { type: 'policia_local', quantity: 1, priority: 'obligatorio' },
        { type: 'grua', quantity: 1, priority: 'opcional' },
      ],
      baja: [
        { type: 'policia_local', quantity: 1, priority: 'obligatorio' },
      ],
    },
  },
  
  operationalSteps: [
    {
      id: 'acc-op-1',
      order: 1,
      action: 'Senalizacion y balizamiento',
      description: 'Colocar triangulos y desviar trafico',
      responsible: 'policia',
      timeLimit: '5 min',
      isCritical: true,
    },
    {
      id: 'acc-op-2',
      order: 2,
      action: 'Triaje de victimas',
      description: 'Clasificar victimas segun gravedad',
      responsible: 'servicios_medicos',
      timeLimit: '5 min',
      isCritical: true,
    },
    {
      id: 'acc-op-3',
      order: 3,
      action: 'Excarcelacion si necesario',
      description: 'Liberacion de victimas atrapadas',
      responsible: 'bomberos',
      isCritical: true,
      warnings: ['Coordinar con sanitarios antes de mover victimas'],
    },
    {
      id: 'acc-op-4',
      order: 4,
      action: 'Atencion sanitaria y evacuacion',
      description: 'Estabilizar y trasladar victimas',
      responsible: 'servicios_medicos',
      isCritical: true,
    },
    {
      id: 'acc-op-5',
      order: 5,
      action: 'Limpieza de via',
      description: 'Retirar vehiculos y residuos',
      responsible: 'policia',
      timeLimit: 'variable',
      isCritical: false,
    },
  ],
  
  coordinationFlows: [
    {
      from: 'policia',
      to: 'servicios_medicos',
      channel: 'radio',
      message: 'Estado de victimas y necesidades',
      timing: 'Al llegar a escena',
    },
    {
      from: 'servicios_medicos',
      to: 'bomberos',
      channel: 'radio',
      message: 'Victimas atrapadas - solicitud excarcelacion',
      timing: 'Si hay atrapados',
    },
  ],
  
  escalationCriteria: [
    {
      condition: 'Vehiculo con mercancias peligrosas',
      newPriority: 'critica',
      additionalResources: [
        { type: 'hazmat', quantity: 1, priority: 'obligatorio' },
        { type: 'bomberos', quantity: 1, priority: 'obligatorio' },
      ],
      notifyAgencies: ['proteccion_civil'],
    },
    {
      condition: 'Mas de 3 victimas graves',
      newPriority: 'critica',
      additionalResources: [
        { type: 'samu', quantity: 1, priority: 'obligatorio' },
        { type: 'helicoptero', quantity: 1, priority: 'recomendado' },
      ],
      notifyAgencies: ['servicios_medicos'],
    },
  ],
  
  safetyConsiderations: [
    'Usar chaleco reflectante siempre',
    'Posicionarse fuera del flujo de trafico',
    'Atencion a derrames de combustible',
    'No mover victimas sin inmovilizacion cervical',
  ],
  
  legalReferences: [
    'Ley de Trafico y Seguridad Vial',
    'Protocolo de atencion al accidente de trafico (DGT)',
  ],
  
  lastUpdated: '2024-01-10',
  version: '1.5',
}

/**
 * Medical Emergency Protocol
 */
export const PROTOCOL_EMERGENCIA_MEDICA: Protocol = {
  id: 'proto-medica-001',
  name: 'Protocolo de Emergencia Medica',
  incidentType: 'emergencia_medica',
  applicablePriorities: ['critica', 'alta', 'media', 'baja'],
  description: 'Protocolo para la gestion de emergencias sanitarias en via publica o domicilio.',
  
  objectives: [
    'Preservar la vida del paciente',
    'Estabilizar constantes vitales',
    'Trasladar al centro sanitario adecuado',
  ],
  
  initialAssessment: [
    {
      id: 'med-assess-1',
      order: 1,
      action: 'Confirmar ubicacion y acceso',
      description: 'Verificar direccion exacta, piso, codigo portal',
      responsible: 'servicios_medicos',
      timeLimit: 'inmediato',
      isCritical: true,
    },
    {
      id: 'med-assess-2',
      order: 2,
      action: 'Obtener informacion del paciente',
      description: 'Edad, sexo, sintomas principales, antecedentes',
      responsible: 'servicios_medicos',
      timeLimit: '1 min',
      isCritical: true,
    },
    {
      id: 'med-assess-3',
      order: 3,
      action: 'Evaluar nivel de consciencia',
      description: 'Determinar si responde, respira, tiene pulso',
      responsible: 'servicios_medicos',
      timeLimit: '1 min',
      isCritical: true,
    },
  ],
  
  resourceRequirements: {
    minimum: [
      { type: 'ambulancia', quantity: 1, priority: 'obligatorio' },
    ],
    byPriority: {
      critica: [
        { type: 'samu', quantity: 1, priority: 'obligatorio', notes: 'SVA con medico' },
        { type: 'ambulancia', quantity: 1, priority: 'recomendado', notes: 'Apoyo SVB' },
      ],
      alta: [
        { type: 'ambulancia', quantity: 1, priority: 'obligatorio', notes: 'SVB' },
        { type: 'samu', quantity: 1, priority: 'recomendado' },
      ],
      media: [
        { type: 'ambulancia', quantity: 1, priority: 'obligatorio' },
      ],
      baja: [
        { type: 'ambulancia', quantity: 1, priority: 'opcional' },
      ],
    },
  },
  
  operationalSteps: [
    {
      id: 'med-op-1',
      order: 1,
      action: 'Instrucciones telefonicas',
      description: 'Guiar al alertante en primeros auxilios si es necesario',
      responsible: 'servicios_medicos',
      timeLimit: 'durante espera',
      isCritical: true,
      checkpoints: ['RCP iniciada si PCR', 'PLS si inconsciente'],
    },
    {
      id: 'med-op-2',
      order: 2,
      action: 'Valoracion primaria',
      description: 'ABCDE al llegar a escena',
      responsible: 'servicios_medicos',
      timeLimit: '3 min',
      isCritical: true,
    },
    {
      id: 'med-op-3',
      order: 3,
      action: 'Estabilizacion',
      description: 'Tratar problemas vitales identificados',
      responsible: 'servicios_medicos',
      isCritical: true,
    },
    {
      id: 'med-op-4',
      order: 4,
      action: 'Decision de traslado',
      description: 'Determinar hospital destino segun patologia',
      responsible: 'servicios_medicos',
      isCritical: true,
    },
  ],
  
  coordinationFlows: [
    {
      from: 'servicios_medicos',
      to: 'servicios_medicos',
      channel: 'radio',
      message: 'Preaviso hospitalario con codigo patologia',
      timing: 'Durante traslado',
    },
  ],
  
  escalationCriteria: [
    {
      condition: 'PCR - Parada cardiorrespiratoria',
      newPriority: 'critica',
      additionalResources: [
        { type: 'samu', quantity: 1, priority: 'obligatorio' },
      ],
      notifyAgencies: ['servicios_medicos'],
    },
    {
      condition: 'Acceso dificil - puerta cerrada',
      newPriority: 'alta',
      additionalResources: [
        { type: 'bomberos', quantity: 1, priority: 'obligatorio', notes: 'Apertura de puerta' },
      ],
      notifyAgencies: ['bomberos'],
    },
  ],
  
  safetyConsiderations: [
    'Usar EPIs ante sospecha de enfermedad contagiosa',
    'Precaucion en escenas con violencia',
    'Solicitar policia si hay riesgo para el personal',
  ],
  
  legalReferences: [
    'Ley 41/2002 de Autonomia del Paciente',
    'Protocolos de SVA y SVB vigentes',
  ],
  
  lastUpdated: '2024-02-01',
  version: '2.0',
}

/**
 * Protocol map for quick access
 */
export const PROTOCOLS: Record<string, Protocol> = {
  incendio: PROTOCOL_INCENDIO,
  accidente: PROTOCOL_ACCIDENTE,
  emergencia_medica: PROTOCOL_EMERGENCIA_MEDICA,
}

/**
 * Command structures by incident type
 */
export const COMMAND_STRUCTURES: Record<string, CommandStructure> = {
  incendio: {
    incidentType: 'incendio',
    priority: 'critica',
    positions: [
      {
        role: 'Jefe de Intervencion',
        agency: 'bomberos',
        responsibilities: [
          'Direccion tactica de la intervencion',
          'Coordinacion de recursos de extincion',
          'Decision de estrategia ofensiva/defensiva',
        ],
        supervises: ['Sector Extincion', 'Sector Rescate'],
      },
      {
        role: 'Coordinador Sanitario',
        agency: 'servicios_medicos',
        responsibilities: [
          'Gestion del area de triaje',
          'Coordinacion de evacuaciones',
          'Enlace con hospitales',
        ],
        reportsTo: 'Jefe de Intervencion',
      },
      {
        role: 'Jefe de Seguridad',
        agency: 'policia',
        responsibilities: [
          'Control de perimetro',
          'Gestion de trafico',
          'Evacuacion de zona',
        ],
        reportsTo: 'Jefe de Intervencion',
      },
    ],
    coordinationPoint: 'Puesto de Mando Avanzado',
  },
  accidente: {
    incidentType: 'accidente',
    priority: 'alta',
    positions: [
      {
        role: 'Jefe de Operaciones',
        agency: 'policia',
        responsibilities: [
          'Coordinacion general',
          'Gestion de trafico',
          'Investigacion del accidente',
        ],
        supervises: ['Sector Sanitario', 'Sector Rescate'],
      },
      {
        role: 'Responsable Sanitario',
        agency: 'servicios_medicos',
        responsibilities: [
          'Triaje y atencion de victimas',
          'Decision de traslados',
        ],
        reportsTo: 'Jefe de Operaciones',
      },
    ],
    coordinationPoint: 'Zona segura junto a vehiculos',
  },
}

/**
 * Get protocol by incident type
 */
export function getProtocolForIncident(incidentType: string): Protocol | null {
  return PROTOCOLS[incidentType] || null
}

/**
 * Get command structure by incident type
 */
export function getCommandStructure(incidentType: string): CommandStructure | null {
  return COMMAND_STRUCTURES[incidentType] || null
}
