/**
 * Type definitions for the Emergency Decision Support System
 * 
 * This file contains all TypeScript interfaces and types used
 * throughout the application.
 */

/**
 * Supported incident types that the NLP engine can classify
 */
export type IncidentType =
  | 'incendio'
  | 'inundacion'
  | 'accidente'
  | 'derrumbe'
  | 'explosion'
  | 'fuga_gas'
  | 'persona_atrapada'
  | 'emergencia_medica'
  | 'otro'

/**
 * Priority levels for incidents
 */
export type PriorityLevel = 'critica' | 'alta' | 'media' | 'baja'

/**
 * Incident processing status
 */
export type IncidentStatus = 'pendiente' | 'confirmado'

/**
 * Result of NLP extraction process
 */
export interface NLPExtractionResult {
  incidentType: IncidentType
  location: string | null
  urgencyScore: number
  impactScore: number
  priority: PriorityLevel
  extractedAt: string
}

/**
 * Main Incident object
 * Represents a processed emergency incident
 */
export interface Incident {
  id: string
  rawText: string
  incidentType: IncidentType
  location: string | null
  urgencyScore: number
  impactScore: number
  priority: PriorityLevel
  status: IncidentStatus
  createdAt: string
  processedAt: string
  confirmedAt: string | null
  ttfd: number | null
}

/**
 * Statistics for metrics display
 */
export interface SystemMetrics {
  totalIncidents: number
  pendingIncidents: number
  confirmedIncidents: number
  averageTTFD: number | null
  incidentsByType: Record<IncidentType, number>
  incidentsByPriority: Record<PriorityLevel, number>
}

/**
 * API response types
 */
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
}

/**
 * Sample data type for demo purposes
 */
export interface SampleReport {
  id: string
  title: string
  text: string
}
