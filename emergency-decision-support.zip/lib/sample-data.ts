/**
 * Sample emergency reports for testing and demonstration
 * 
 * These examples simulate real citizen reports, emails, and
 * emergency notifications that the system would process.
 */

import type { SampleReport } from './types'

export const SAMPLE_REPORTS: SampleReport[] = [
  {
    id: '1',
    title: 'Incendio en edificio residencial',
    text: 'URGENTE: Se ha declarado un incendio en la Calle Mayor 45, 3er piso. Hay humo visible desde la calle y se reportan varias personas atrapadas. El fuego se está propagando rapidamente hacia los pisos superiores. Hay niños en el edificio.',
  },
  {
    id: '2',
    title: 'Accidente de trafico multiple',
    text: 'Accidente de trafico en la Avenida de la Constitucion con 3 vehiculos implicados. Se reportan varios heridos, al menos dos personas inconscientes. El trafico está completamente cortado en ambos sentidos.',
  },
  {
    id: '3',
    title: 'Inundacion en zona comercial',
    text: 'Inundacion importante en el barrio de San Juan debido al desbordamiento del rio. El nivel del agua está subiendo y varias viviendas tienen el agua hasta un metro de altura. Hay personas mayores que no pueden evacuar por sus propios medios.',
  },
  {
    id: '4',
    title: 'Fuga de gas en zona industrial',
    text: 'Se detecta fuerte olor a gas en la zona industrial cerca de la fabrica QuimiPro en el Poligono Industrial Norte. Los trabajadores han evacuado el area. Situación potencialmente crítica.',
  },
  {
    id: '5',
    title: 'Derrumbe parcial de edificio',
    text: 'Derrumbe parcial de la fachada de un edificio antiguo en Plaza España, 12. Escombros en la via publica. No hay heridos confirmados pero se cree que puede haber personas atrapadas en el interior. El edificio es una residencia de ancianos.',
  },
  {
    id: '6',
    title: 'Emergencia medica en colegio',
    text: 'Solicitan ambulancia urgente en el Colegio San Francisco, Calle del Pino 8. Un alumno ha sufrido lo que parece ser un paro cardiaco durante la clase de educacion fisica. El personal está aplicando RCP.',
  },
  {
    id: '7',
    title: 'Explosion en vivienda',
    text: 'Explosion en una vivienda de la Calle Real 23. Se sospecha de una fuga de gas. Hay daños graves en el inmueble y edificios colindantes. Se reportan multiples heridos graves. Peligro inmediato.',
  },
  {
    id: '8',
    title: 'Persona atrapada en ascensor',
    text: 'Persona atrapada en el ascensor del edificio de oficinas en Paseo de la Castellana 100. Lleva dos horas sin poder salir. Reporta que tiene claustrofobia y está teniendo ataques de ansiedad.',
  },
  {
    id: '9',
    title: 'Incendio forestal cercano',
    text: 'Incendio forestal detectado en el km 15 de la carretera A-45, cerca del area recreativa. El viento está empujando el fuego hacia la urbanizacion Las Colinas. Se recomienda preparar evacuacion.',
  },
  {
    id: '10',
    title: 'Averia de agua menor',
    text: 'Se ha producido una averia de agua en la Calle Nueva, hay un charco en la acera. No hay peligro pero está causando molestias a los vecinos.',
  },
]

/**
 * Returns a random sample report for quick testing
 */
export function getRandomSample(): SampleReport {
  const index = Math.floor(Math.random() * SAMPLE_REPORTS.length)
  return SAMPLE_REPORTS[index]
}
