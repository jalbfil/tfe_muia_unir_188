/**
 * NLP Engine for Emergency Incident Processing
 * 
 * This module provides basic Natural Language Processing capabilities
 * for extracting structured information from emergency reports.
 * 
 * Features:
 * - Named Entity Recognition (NER) for locations
 * - Incident type classification
 * - Urgency signal detection
 * - Priority scoring
 */

import type { Incident, IncidentType, PriorityLevel, NLPExtractionResult } from './types'

// Incident type patterns with Spanish keywords
const INCIDENT_PATTERNS: Record<IncidentType, RegExp[]> = {
  incendio: [
    /incendio/i,
    /fuego/i,
    /llamas/i,
    /humo/i,
    /quema/i,
    /ardiendo/i,
    /combusti[oó]n/i,
  ],
  inundacion: [
    /inundaci[oó]n/i,
    /riada/i,
    /desbordamiento/i,
    /anegado/i,
    /agua.*nivel/i,
    /crecida/i,
    /inundado/i,
  ],
  accidente: [
    /accidente/i,
    /colisi[oó]n/i,
    /choque/i,
    /atropello/i,
    /vuelco/i,
    /siniestro.*vial/i,
    /tr[aá]fico/i,
  ],
  derrumbe: [
    /derrumbe/i,
    /colapso/i,
    /desplome/i,
    /hundimiento/i,
    /estructura.*ca[iy]da/i,
    /edificio.*ca[iy]do/i,
  ],
  explosion: [
    /explosi[oó]n/i,
    /detonaci[oó]n/i,
    /estallido/i,
    /deflagraci[oó]n/i,
  ],
  fuga_gas: [
    /fuga.*gas/i,
    /escape.*gas/i,
    /olor.*gas/i,
    /gas.*natural/i,
  ],
  persona_atrapada: [
    /atrapado/i,
    /atrapada/i,
    /encerrado/i,
    /sin.*salida/i,
    /no.*puede.*salir/i,
  ],
  emergencia_medica: [
    /herido/i,
    /lesionado/i,
    /inconsciente/i,
    /infarto/i,
    /paro.*card[ií]aco/i,
    /emergencia.*m[eé]dica/i,
    /ambulancia/i,
  ],
  otro: [],
}

// Urgency signal patterns
const URGENCY_SIGNALS: { pattern: RegExp; weight: number }[] = [
  { pattern: /urgente/i, weight: 3 },
  { pattern: /inmediato/i, weight: 3 },
  { pattern: /r[aá]pido/i, weight: 2 },
  { pattern: /peligro.*muerte/i, weight: 4 },
  { pattern: /vida.*riesgo/i, weight: 4 },
  { pattern: /graves/i, weight: 3 },
  { pattern: /cr[ií]tico/i, weight: 4 },
  { pattern: /ni[nñ]os?/i, weight: 2 },
  { pattern: /ancianos?/i, weight: 2 },
  { pattern: /hospital/i, weight: 2 },
  { pattern: /colegio/i, weight: 2 },
  { pattern: /escuela/i, weight: 2 },
  { pattern: /residencia/i, weight: 2 },
  { pattern: /se.*propaga/i, weight: 3 },
  { pattern: /descontrolado/i, weight: 3 },
  { pattern: /muchas.*personas/i, weight: 2 },
  { pattern: /varios.*heridos/i, weight: 3 },
  { pattern: /m[uú]ltiples/i, weight: 2 },
]

// Location extraction patterns
const LOCATION_PATTERNS: RegExp[] = [
  /(?:en|cerca de|junto a)\s+(?:la\s+)?(?:calle|c\/|avda\.?|avenida|plaza|paseo)\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)*/gi,
  /(?:calle|c\/|avda\.?|avenida|plaza|paseo)\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)*(?:\s*,?\s*n[uú]mero?\s*\d+)?/gi,
  /(?:barrio|distrito|zona)\s+(?:de\s+)?[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+/gi,
  /[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+(?:\s+[A-ZÁÉÍÓÚÑ][a-záéíóúñ]+)*\s*,\s*\d{5}/g,
  /km\s*\d+(?:\.\d+)?\s+(?:de\s+)?(?:la\s+)?(?:carretera|autov[ií]a|autopista)\s+[A-Z]-?\d+/gi,
]

// Impact assessment patterns
const IMPACT_PATTERNS: { pattern: RegExp; score: number }[] = [
  { pattern: /persona|gente|habitantes/i, score: 3 },
  { pattern: /veh[ií]culos?/i, score: 2 },
  { pattern: /edificio/i, score: 3 },
  { pattern: /vivienda/i, score: 3 },
  { pattern: /industria|f[aá]brica/i, score: 4 },
  { pattern: /centro.*comercial/i, score: 4 },
  { pattern: /hospital|cl[ií]nica/i, score: 5 },
  { pattern: /colegio|escuela|universidad/i, score: 5 },
  { pattern: /estaci[oó]n/i, score: 4 },
  { pattern: /aeropuerto/i, score: 5 },
]

/**
 * Detects the incident type from text
 */
function detectIncidentType(text: string): IncidentType {
  for (const [type, patterns] of Object.entries(INCIDENT_PATTERNS)) {
    for (const pattern of patterns) {
      if (pattern.test(text)) {
        return type as IncidentType
      }
    }
  }
  return 'otro'
}

/**
 * Extracts location information from text
 */
function extractLocation(text: string): string | null {
  for (const pattern of LOCATION_PATTERNS) {
    const matches = text.match(pattern)
    if (matches && matches.length > 0) {
      // Clean up the match
      return matches[0]
        .replace(/^(?:en|cerca de|junto a)\s+/i, '')
        .trim()
    }
  }
  return null
}

/**
 * Calculates urgency score from text
 */
function calculateUrgencyScore(text: string): number {
  let score = 0
  for (const signal of URGENCY_SIGNALS) {
    if (signal.pattern.test(text)) {
      score += signal.weight
    }
  }
  return Math.min(score, 10) // Cap at 10
}

/**
 * Calculates impact score from text
 */
function calculateImpactScore(text: string): number {
  let score = 0
  for (const impact of IMPACT_PATTERNS) {
    if (impact.pattern.test(text)) {
      score += impact.score
    }
  }
  return Math.min(score, 10) // Cap at 10
}

/**
 * Determines priority level based on scores
 */
function determinePriority(urgencyScore: number, impactScore: number, incidentType: IncidentType): PriorityLevel {
  // Base score from urgency and impact
  let totalScore = urgencyScore + impactScore
  
  // Type-based modifiers
  const typeModifiers: Partial<Record<IncidentType, number>> = {
    explosion: 3,
    persona_atrapada: 3,
    fuga_gas: 2,
    incendio: 2,
    derrumbe: 2,
    accidente: 1,
  }
  
  totalScore += typeModifiers[incidentType] || 0
  
  if (totalScore >= 12) return 'critica'
  if (totalScore >= 8) return 'alta'
  if (totalScore >= 4) return 'media'
  return 'baja'
}

/**
 * Main NLP processing function
 * Extracts structured information from emergency text
 */
export function processEmergencyText(text: string): NLPExtractionResult {
  const incidentType = detectIncidentType(text)
  const location = extractLocation(text)
  const urgencyScore = calculateUrgencyScore(text)
  const impactScore = calculateImpactScore(text)
  const priority = determinePriority(urgencyScore, impactScore, incidentType)
  
  return {
    incidentType,
    location,
    urgencyScore,
    impactScore,
    priority,
    extractedAt: new Date().toISOString(),
  }
}

/**
 * Creates a full Incident object from text
 */
export function createIncidentFromText(text: string): Incident {
  const extraction = processEmergencyText(text)
  
  return {
    id: crypto.randomUUID(),
    rawText: text,
    incidentType: extraction.incidentType,
    location: extraction.location,
    urgencyScore: extraction.urgencyScore,
    impactScore: extraction.impactScore,
    priority: extraction.priority,
    status: 'pendiente',
    createdAt: new Date().toISOString(),
    processedAt: extraction.extractedAt,
    confirmedAt: null,
    ttfd: null,
  }
}

/**
 * Calculates Time To First Decision in seconds
 */
export function calculateTTFD(incident: Incident): number | null {
  if (!incident.confirmedAt || !incident.createdAt) return null
  
  const created = new Date(incident.createdAt).getTime()
  const confirmed = new Date(incident.confirmedAt).getTime()
  
  return Math.round((confirmed - created) / 1000)
}

/**
 * Formats TTFD for display
 */
export function formatTTFD(seconds: number | null): string {
  if (seconds === null) return 'N/A'
  
  if (seconds < 60) {
    return `${seconds}s`
  } else if (seconds < 3600) {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}m ${secs}s`
  } else {
    const hours = Math.floor(seconds / 3600)
    const mins = Math.floor((seconds % 3600) / 60)
    return `${hours}h ${mins}m`
  }
}

/**
 * Gets display name for incident type in Spanish
 */
export function getIncidentTypeLabel(type: IncidentType): string {
  const labels: Record<IncidentType, string> = {
    incendio: 'Incendio',
    inundacion: 'Inundacion',
    accidente: 'Accidente',
    derrumbe: 'Derrumbe',
    explosion: 'Explosion',
    fuga_gas: 'Fuga de Gas',
    persona_atrapada: 'Persona Atrapada',
    emergencia_medica: 'Emergencia Medica',
    otro: 'Otro',
  }
  return labels[type]
}

/**
 * Gets display name for priority level in Spanish
 */
export function getPriorityLabel(priority: PriorityLevel): string {
  const labels: Record<PriorityLevel, string> = {
    critica: 'Critica',
    alta: 'Alta',
    media: 'Media',
    baja: 'Baja',
  }
  return labels[priority]
}

/**
 * Gets suggested decision text based on incident analysis
 */
export function getSuggestedDecision(incident: Incident): string {
  const decisions: Record<IncidentType, string> = {
    incendio: `Despachar unidades de bomberos al lugar. ${incident.priority === 'critica' || incident.priority === 'alta' ? 'Activar protocolo de evacuacion de zona.' : 'Evaluar necesidad de evacuacion.'}`,
    inundacion: `Activar protocolo de emergencia hidrica. ${incident.priority === 'critica' ? 'Solicitar apoyo de Proteccion Civil y equipos de rescate acuatico.' : 'Coordinar con servicios municipales de drenaje.'}`,
    accidente: `Enviar ambulancia y policia local. ${incident.impactScore >= 6 ? 'Activar plan de emergencias viales y solicitar mas recursos.' : 'Evaluar necesidad de grua y corte de trafico.'}`,
    derrumbe: `Activar equipo de rescate urbano (USAR). ${incident.priority === 'critica' ? 'Solicitar unidades caninas de busqueda.' : 'Asegurar perimetro y evaluar estabilidad estructural.'}`,
    explosion: `Activar protocolo de emergencia mayor. Despachar bomberos, ambulancias y policia. Evaluar posible evacuacion de la zona.`,
    fuga_gas: `Evacuar inmediatamente la zona afectada. Contactar compania de gas para corte de suministro. Despachar bomberos con equipo HAZMAT.`,
    persona_atrapada: `Enviar equipo de rescate especializado. ${incident.priority === 'critica' ? 'Activar protocolo de rescate urgente con soporte medico en sitio.' : 'Evaluar mejor acceso y herramientas necesarias.'}`,
    emergencia_medica: `Despachar ambulancia medicalizada. ${incident.urgencyScore >= 7 ? 'Alertar hospital mas cercano para preparar recepcion.' : 'Evaluar gravedad en sitio.'}`,
    otro: `Evaluar situacion en sitio con unidad de respuesta rapida. Determinar recursos necesarios segun informe inicial.`,
  }
  return decisions[incident.incidentType]
}

/**
 * Gets suggested resources based on incident type and priority
 */
export function getSuggestedResources(incident: Incident): string[] {
  const baseResources: Record<IncidentType, string[]> = {
    incendio: ['Bomberos', 'Ambulancia'],
    inundacion: ['Proteccion Civil', 'Bomberos'],
    accidente: ['Ambulancia', 'Policia Local'],
    derrumbe: ['USAR', 'Bomberos', 'Ambulancia'],
    explosion: ['Bomberos', 'Ambulancia', 'Policia', 'HAZMAT'],
    fuga_gas: ['Bomberos', 'HAZMAT', 'Compania de Gas'],
    persona_atrapada: ['Bomberos', 'Ambulancia'],
    emergencia_medica: ['Ambulancia', 'SAMU'],
    otro: ['Unidad de Respuesta'],
  }
  
  const resources = [...baseResources[incident.incidentType]]
  
  // Add resources based on priority
  if (incident.priority === 'critica') {
    if (!resources.includes('Coordinador de Emergencias')) {
      resources.push('Coordinador de Emergencias')
    }
  }
  
  if (incident.priority === 'critica' || incident.priority === 'alta') {
    if (incident.incidentType === 'incendio' && !resources.includes('Policia')) {
      resources.push('Policia')
    }
    if (incident.incidentType === 'accidente' && !resources.includes('Grua')) {
      resources.push('Grua')
    }
  }
  
  return resources
}

/**
 * Gets action label for operator actions
 */
export function getActionLabel(action: string): string {
  const labels: Record<string, string> = {
    despachar: 'Despachar Recursos',
    escalar: 'Escalar Prioridad',
    reasignar: 'Reasignar Tipo de Incidente',
    descartar: 'Descartar Incidente',
  }
  return labels[action] || action
}

/**
 * Gets action description for operator actions
 */
export function getActionDescription(action: string): string {
  const descriptions: Record<string, string> = {
    despachar: 'Se enviaran los recursos sugeridos al lugar del incidente. El sistema registrara la decision y notificara a las unidades correspondientes.',
    escalar: 'Se aumentara el nivel de prioridad del incidente, reasignando recursos y alertando a mandos superiores si es necesario.',
    reasignar: 'Se cambiara la clasificacion del tipo de incidente, ajustando los recursos sugeridos segun la nueva clasificacion.',
    descartar: 'Se marcara el incidente como falsa alarma o duplicado. Esta accion es irreversible y el incidente se archivara.',
  }
  return descriptions[action] || ''
}
