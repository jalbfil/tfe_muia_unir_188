/**
 * In-memory incident store for the MVP
 * 
 * In a production environment, this would be replaced with
 * a proper database (e.g., SQLite, PostgreSQL).
 * 
 * For the academic MVP, this provides a simple way to
 * store and retrieve incidents during a session.
 */

import type { Incident, SystemMetrics, IncidentType, PriorityLevel } from './types'

// In-memory storage
let incidents: Incident[] = []

/**
 * Adds a new incident to the store
 */
export function addIncident(incident: Incident): Incident {
  incidents.push(incident)
  return incident
}

/**
 * Retrieves all incidents, sorted by priority and creation time
 */
export function getAllIncidents(): Incident[] {
  const priorityOrder: Record<PriorityLevel, number> = {
    critica: 0,
    alta: 1,
    media: 2,
    baja: 3,
  }
  
  return [...incidents].sort((a, b) => {
    // First sort by status (pending first)
    if (a.status !== b.status) {
      return a.status === 'pendiente' ? -1 : 1
    }
    // Then by priority
    if (a.priority !== b.priority) {
      return priorityOrder[a.priority] - priorityOrder[b.priority]
    }
    // Then by creation time (newest first)
    return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
  })
}

/**
 * Retrieves a single incident by ID
 */
export function getIncidentById(id: string): Incident | null {
  return incidents.find(i => i.id === id) || null
}

/**
 * Confirms an incident (human decision made)
 */
export function confirmIncident(id: string): Incident | null {
  const incident = incidents.find(i => i.id === id)
  if (!incident) return null
  
  const confirmedAt = new Date().toISOString()
  const createdTime = new Date(incident.createdAt).getTime()
  const confirmedTime = new Date(confirmedAt).getTime()
  const ttfd = Math.round((confirmedTime - createdTime) / 1000)
  
  incident.status = 'confirmado'
  incident.confirmedAt = confirmedAt
  incident.ttfd = ttfd
  
  return incident
}

/**
 * Calculates system metrics
 */
export function getMetrics(): SystemMetrics {
  const total = incidents.length
  const pending = incidents.filter(i => i.status === 'pendiente').length
  const confirmed = incidents.filter(i => i.status === 'confirmado').length
  
  // Calculate average TTFD for confirmed incidents
  const confirmedWithTTFD = incidents.filter(i => i.ttfd !== null)
  const avgTTFD = confirmedWithTTFD.length > 0
    ? Math.round(confirmedWithTTFD.reduce((sum, i) => sum + (i.ttfd || 0), 0) / confirmedWithTTFD.length)
    : null
  
  // Count by type
  const byType: Record<IncidentType, number> = {
    incendio: 0,
    inundacion: 0,
    accidente: 0,
    derrumbe: 0,
    explosion: 0,
    fuga_gas: 0,
    persona_atrapada: 0,
    emergencia_medica: 0,
    otro: 0,
  }
  
  for (const incident of incidents) {
    byType[incident.incidentType]++
  }
  
  // Count by priority
  const byPriority: Record<PriorityLevel, number> = {
    critica: 0,
    alta: 0,
    media: 0,
    baja: 0,
  }
  
  for (const incident of incidents) {
    byPriority[incident.priority]++
  }
  
  return {
    totalIncidents: total,
    pendingIncidents: pending,
    confirmedIncidents: confirmed,
    averageTTFD: avgTTFD,
    incidentsByType: byType,
    incidentsByPriority: byPriority,
  }
}

/**
 * Clears all incidents (for testing/reset)
 */
export function clearIncidents(): void {
  incidents = []
}

/**
 * Gets pending incidents count
 */
export function getPendingCount(): number {
  return incidents.filter(i => i.status === 'pendiente').length
}
