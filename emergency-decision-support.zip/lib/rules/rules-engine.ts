/**
 * Normative Rules Engine
 * Evaluates incidents against regulatory rules
 */

import type {
  NormativeDocument,
  NormativeRule,
  RuleCondition,
  RuleEvaluation,
  ComplianceCheck,
  RuleAction,
  Regulation,
} from './types'
import type { Incident } from '@/lib/types'

// Sample normative documents with extracted rules
const SAMPLE_DOCUMENTS: NormativeDocument[] = [
  {
    id: 'doc-ley-17-2015',
    type: 'ley',
    title: 'Ley 17/2015, de 9 de julio, del Sistema Nacional de Proteccion Civil',
    shortTitle: 'Ley SNPC',
    reference: 'BOE-A-2015-8047',
    publicationDate: '2015-07-10',
    effectiveDate: '2015-07-11',
    issuingAuthority: 'Jefatura del Estado',
    officialSource: 'https://www.boe.es/buscar/act.php?id=BOE-A-2015-8047',
    summary: 'Establece el Sistema Nacional de Proteccion Civil, sus competencias y procedimientos de actuacion ante emergencias.',
    scope: 'Nacional',
    status: 'vigente',
    lastUpdated: '2024-01-01',
    rules: [
      {
        id: 'rule-ley17-art7',
        documentId: 'doc-ley-17-2015',
        articleReference: 'Art. 7',
        name: 'Deber de colaboracion ciudadana',
        description: 'Los ciudadanos deben colaborar en las tareas de proteccion civil siguiendo las instrucciones de las autoridades.',
        conditions: [],
        conditionLogic: 'AND',
        actions: [
          {
            type: 'inform_authority',
            details: 'Informar a los ciudadanos de sus deberes de colaboracion',
            mandatory: false,
          },
        ],
        applicableIncidentTypes: 'all',
        applicablePriorities: ['critica', 'alta'],
        geographicScope: 'nacional',
        isActive: true,
        effectiveFrom: '2015-07-11',
        lastReviewed: '2024-01-01',
        complianceLevel: 'informativo',
      },
      {
        id: 'rule-ley17-art14',
        documentId: 'doc-ley-17-2015',
        articleReference: 'Art. 14',
        name: 'Activacion del Plan Territorial',
        description: 'Cuando la emergencia supere el ambito local, debe activarse el Plan Territorial de Proteccion Civil correspondiente.',
        conditions: [
          { field: 'priority', operator: 'in', value: ['critica', 'alta'] },
          { field: 'impactScore', operator: 'greater_than', value: 6 },
        ],
        conditionLogic: 'AND',
        actions: [
          {
            type: 'activate_plan',
            target: 'Plan Territorial',
            details: 'Activar el Plan Territorial de Proteccion Civil',
            mandatory: true,
            timeLimit: 'inmediato',
          },
          {
            type: 'notify_agency',
            target: 'proteccion_civil',
            details: 'Notificar a Proteccion Civil autonómica',
            mandatory: true,
            timeLimit: '15 min',
          },
        ],
        applicableIncidentTypes: 'all',
        applicablePriorities: ['critica', 'alta'],
        geographicScope: 'nacional',
        isActive: true,
        effectiveFrom: '2015-07-11',
        lastReviewed: '2024-01-01',
        complianceLevel: 'obligatorio',
      },
    ],
  },
  {
    id: 'doc-rd-393-2007',
    type: 'real_decreto',
    title: 'Real Decreto 393/2007, de 23 de marzo, Norma Basica de Autoproteccion',
    shortTitle: 'NBA',
    reference: 'BOE-A-2007-6237',
    publicationDate: '2007-03-24',
    effectiveDate: '2007-03-25',
    issuingAuthority: 'Ministerio del Interior',
    officialSource: 'https://www.boe.es/buscar/act.php?id=BOE-A-2007-6237',
    summary: 'Regula la obligacion de disponer de planes de autoproteccion en determinadas actividades y centros.',
    scope: 'Nacional',
    status: 'vigente',
    lastUpdated: '2024-01-01',
    rules: [
      {
        id: 'rule-rd393-incendio',
        documentId: 'doc-rd-393-2007',
        articleReference: 'Anexo I',
        name: 'Notificacion de incendios en actividades catalogadas',
        description: 'Los incendios en actividades del catalogo deben notificarse a la autoridad competente en un plazo maximo de 24 horas.',
        conditions: [
          { field: 'incidentType', operator: 'equals', value: 'incendio' },
        ],
        conditionLogic: 'AND',
        actions: [
          {
            type: 'document_requirement',
            details: 'Generar informe de incidente para notificacion a autoridad competente',
            mandatory: true,
            timeLimit: '24 horas',
          },
        ],
        applicableIncidentTypes: ['incendio', 'explosion'],
        applicablePriorities: 'all',
        geographicScope: 'nacional',
        isActive: true,
        effectiveFrom: '2007-03-25',
        lastReviewed: '2024-01-01',
        complianceLevel: 'obligatorio',
      },
    ],
  },
  {
    id: 'doc-plan-especial-incendios',
    type: 'plan_especial',
    title: 'Plan Especial de Emergencias por Incendios Forestales',
    shortTitle: 'PEIF',
    reference: 'PEIF-2023',
    publicationDate: '2023-06-01',
    effectiveDate: '2023-06-15',
    issuingAuthority: 'Direccion General de Proteccion Civil',
    officialSource: 'https://www.proteccioncivil.es',
    summary: 'Plan especial para la gestion de emergencias por incendios forestales.',
    scope: 'Nacional',
    status: 'vigente',
    lastUpdated: '2024-01-01',
    rules: [
      {
        id: 'rule-peif-situacion1',
        documentId: 'doc-plan-especial-incendios',
        articleReference: 'Cap. 4.1',
        name: 'Activacion Situacion 1 - Incendio que puede ser controlado',
        description: 'Incendios que pueden ser controlados con medios locales.',
        conditions: [
          { field: 'incidentType', operator: 'equals', value: 'incendio' },
          { field: 'priority', operator: 'in', value: ['media', 'baja'] },
        ],
        conditionLogic: 'AND',
        actions: [
          {
            type: 'require_resource',
            target: 'bomberos',
            details: 'Activar medios de extincion locales',
            mandatory: true,
          },
        ],
        applicableIncidentTypes: ['incendio'],
        applicablePriorities: ['media', 'baja'],
        geographicScope: 'nacional',
        isActive: true,
        effectiveFrom: '2023-06-15',
        lastReviewed: '2024-01-01',
        complianceLevel: 'obligatorio',
      },
      {
        id: 'rule-peif-situacion2',
        documentId: 'doc-plan-especial-incendios',
        articleReference: 'Cap. 4.2',
        name: 'Activacion Situacion 2 - Incendio que supera capacidad local',
        description: 'Incendios que requieren movilizacion de medios extraordinarios.',
        conditions: [
          { field: 'incidentType', operator: 'equals', value: 'incendio' },
          { field: 'priority', operator: 'in', value: ['critica', 'alta'] },
        ],
        conditionLogic: 'AND',
        actions: [
          {
            type: 'activate_plan',
            target: 'Plan Especial',
            details: 'Activar Plan Especial de Incendios Forestales',
            mandatory: true,
            timeLimit: 'inmediato',
          },
          {
            type: 'require_resource',
            target: 'helicoptero',
            details: 'Solicitar medios aereos si disponibles',
            mandatory: false,
          },
          {
            type: 'notify_agency',
            target: 'proteccion_civil',
            details: 'Notificar al Centro de Coordinacion Operativa',
            mandatory: true,
            timeLimit: '10 min',
          },
        ],
        applicableIncidentTypes: ['incendio'],
        applicablePriorities: ['critica', 'alta'],
        geographicScope: 'nacional',
        isActive: true,
        effectiveFrom: '2023-06-15',
        lastReviewed: '2024-01-01',
        complianceLevel: 'obligatorio',
      },
    ],
  },
  {
    id: 'doc-protocolo-hazmat',
    type: 'procedimiento_operativo',
    title: 'Protocolo de Actuacion ante Emergencias con Materiales Peligrosos',
    shortTitle: 'HAZMAT Protocol',
    reference: 'PO-HAZMAT-2022',
    publicationDate: '2022-01-15',
    effectiveDate: '2022-02-01',
    issuingAuthority: 'Consorcio de Bomberos',
    officialSource: 'Procedimiento interno',
    summary: 'Protocolo operativo para emergencias con materiales peligrosos.',
    scope: 'Provincial',
    status: 'vigente',
    lastUpdated: '2024-01-01',
    rules: [
      {
        id: 'rule-hazmat-fuga',
        documentId: 'doc-protocolo-hazmat',
        articleReference: 'Sec. 3',
        name: 'Activacion equipo HAZMAT',
        description: 'Ante cualquier fuga de gas o materiales peligrosos, activar equipo especializado.',
        conditions: [
          { field: 'incidentType', operator: 'in', value: ['fuga_gas', 'explosion'] },
        ],
        conditionLogic: 'OR',
        actions: [
          {
            type: 'require_resource',
            target: 'hazmat',
            details: 'Activar equipo HAZMAT',
            mandatory: true,
            timeLimit: 'inmediato',
          },
          {
            type: 'mandate_protocol',
            target: 'Protocolo HAZMAT',
            details: 'Seguir protocolo especifico de materiales peligrosos',
            mandatory: true,
          },
        ],
        applicableIncidentTypes: ['fuga_gas', 'explosion'],
        applicablePriorities: 'all',
        geographicScope: 'provincial',
        isActive: true,
        effectiveFrom: '2022-02-01',
        lastReviewed: '2024-01-01',
        complianceLevel: 'obligatorio',
      },
      {
        id: 'rule-hazmat-evacuacion',
        documentId: 'doc-protocolo-hazmat',
        articleReference: 'Sec. 4',
        name: 'Evacuacion preventiva HAZMAT',
        description: 'Evacuar perimetro de seguridad segun tipo de sustancia.',
        conditions: [
          { field: 'incidentType', operator: 'equals', value: 'fuga_gas' },
          { field: 'priority', operator: 'in', value: ['critica', 'alta'] },
        ],
        conditionLogic: 'AND',
        actions: [
          {
            type: 'notify_agency',
            target: 'policia',
            details: 'Solicitar apoyo policial para evacuacion',
            mandatory: true,
            timeLimit: 'inmediato',
          },
          {
            type: 'notify_agency',
            target: 'proteccion_civil',
            details: 'Activar plan de evacuacion si necesario',
            mandatory: true,
          },
        ],
        applicableIncidentTypes: ['fuga_gas'],
        applicablePriorities: ['critica', 'alta'],
        geographicScope: 'provincial',
        isActive: true,
        effectiveFrom: '2022-02-01',
        lastReviewed: '2024-01-01',
        complianceLevel: 'obligatorio',
      },
    ],
  },
]

// In-memory document storage
let documents: NormativeDocument[] = [...SAMPLE_DOCUMENTS]

/**
 * Rules Engine Class
 */
export class RulesEngine {
  /**
   * Get all normative documents
   */
  static getAllDocuments(): NormativeDocument[] {
    return [...documents]
  }
  
  /**
   * Get document by ID
   */
  static getDocumentById(id: string): NormativeDocument | null {
    return documents.find(d => d.id === id) || null
  }
  
  /**
   * Get all active rules
   */
  static getAllActiveRules(): NormativeRule[] {
    return documents.flatMap(d => d.rules.filter(r => r.isActive))
  }
  
  /**
   * Evaluate a single condition against incident
   */
  private static evaluateCondition(
    condition: RuleCondition,
    incident: Incident
  ): { matched: boolean; actualValue: unknown } {
    let actualValue: unknown
    
    switch (condition.field) {
      case 'incidentType':
        actualValue = incident.incidentType
        break
      case 'priority':
        actualValue = incident.priority
        break
      case 'urgencyScore':
        actualValue = incident.urgencyScore
        break
      case 'impactScore':
        actualValue = incident.impactScore
        break
      case 'location':
        actualValue = incident.location
        break
      case 'keyword':
        actualValue = incident.rawText.toLowerCase()
        break
      default:
        return { matched: false, actualValue: null }
    }
    
    let matched = false
    
    switch (condition.operator) {
      case 'equals':
        matched = actualValue === condition.value
        break
      case 'contains':
        matched = typeof actualValue === 'string' && 
                  actualValue.includes(String(condition.value).toLowerCase())
        break
      case 'greater_than':
        matched = typeof actualValue === 'number' && 
                  actualValue > (condition.value as number)
        break
      case 'less_than':
        matched = typeof actualValue === 'number' && 
                  actualValue < (condition.value as number)
        break
      case 'in':
        matched = Array.isArray(condition.value) && 
                  condition.value.includes(actualValue as string)
        break
    }
    
    return { matched, actualValue }
  }
  
  /**
   * Evaluate a rule against an incident
   */
  static evaluateRule(rule: NormativeRule, incident: Incident): RuleEvaluation {
    // Check if rule applies to this incident type
    if (rule.applicableIncidentTypes !== 'all' && 
        !rule.applicableIncidentTypes.includes(incident.incidentType)) {
      return {
        ruleId: rule.id,
        rule,
        triggered: false,
        matchedConditions: [],
        requiredActions: [],
        complianceNotes: ['Regla no aplicable a este tipo de incidente'],
      }
    }
    
    // Check if rule applies to this priority
    if (rule.applicablePriorities !== 'all' && 
        !rule.applicablePriorities.includes(incident.priority)) {
      return {
        ruleId: rule.id,
        rule,
        triggered: false,
        matchedConditions: [],
        requiredActions: [],
        complianceNotes: ['Regla no aplicable a esta prioridad'],
      }
    }
    
    // Evaluate conditions
    const matchedConditions = rule.conditions.map(condition => ({
      condition,
      ...this.evaluateCondition(condition, incident),
    }))
    
    // Determine if rule is triggered
    let triggered: boolean
    if (rule.conditions.length === 0) {
      triggered = true // Rules without conditions always apply
    } else if (rule.conditionLogic === 'AND') {
      triggered = matchedConditions.every(mc => mc.matched)
    } else {
      triggered = matchedConditions.some(mc => mc.matched)
    }
    
    const complianceNotes: string[] = []
    if (triggered) {
      complianceNotes.push(`Regla activada: ${rule.name}`)
      if (rule.complianceLevel === 'obligatorio') {
        complianceNotes.push('CUMPLIMIENTO OBLIGATORIO')
      }
    }
    
    return {
      ruleId: rule.id,
      rule,
      triggered,
      matchedConditions,
      requiredActions: triggered ? rule.actions : [],
      complianceNotes,
    }
  }
  
  /**
   * Check compliance for an incident against all active rules
   */
  static checkCompliance(incident: Incident): ComplianceCheck {
    const activeRules = this.getAllActiveRules()
    const evaluations = activeRules.map(rule => this.evaluateRule(rule, incident))
    
    const triggeredRules = evaluations
      .filter(e => e.triggered)
      .map(e => e.rule)
    
    const allActions = evaluations
      .filter(e => e.triggered)
      .flatMap(e => e.requiredActions)
    
    const mandatoryActions = allActions.filter(a => a.mandatory)
    const recommendedActions = allActions.filter(a => !a.mandatory)
    
    // Calculate compliance
    const violations: string[] = []
    const warnings: string[] = []
    
    // Check for unmet mandatory requirements
    mandatoryActions.forEach(action => {
      if (action.type === 'require_resource') {
        warnings.push(`Recurso requerido: ${action.target} - ${action.details}`)
      }
      if (action.type === 'notify_agency') {
        warnings.push(`Notificacion requerida: ${action.target} - ${action.details}`)
      }
      if (action.type === 'activate_plan') {
        warnings.push(`Plan a activar: ${action.target} - ${action.details}`)
      }
    })
    
    // Calculate compliance score
    const totalMandatory = mandatoryActions.length
    const complianceScore = totalMandatory === 0 ? 100 : 
      Math.round((1 - violations.length / totalMandatory) * 100)
    
    // Get applicable documents
    const applicableDocuments = [...new Set(triggeredRules.map(r => r.documentId))]
      .map(docId => {
        const doc = documents.find(d => d.id === docId)
        if (!doc) return null
        const relevantRules = triggeredRules.filter(r => r.documentId === docId)
        return {
          documentId: docId,
          title: doc.shortTitle,
          relevantArticles: relevantRules.map(r => r.articleReference),
        }
      })
      .filter((d): d is NonNullable<typeof d> => d !== null)
    
    return {
      incidentId: incident.id,
      checkedAt: new Date().toISOString(),
      evaluations,
      triggeredRules,
      mandatoryActions,
      recommendedActions,
      isCompliant: violations.length === 0,
      complianceScore,
      warnings,
      violations,
      applicableDocuments,
    }
  }
  
  /**
   * Add a new document
   */
  static addDocument(document: NormativeDocument): void {
    documents.push(document)
  }
  
  /**
   * Add a rule to a document
   */
  static addRuleToDocument(documentId: string, rule: NormativeRule): boolean {
    const doc = documents.find(d => d.id === documentId)
    if (!doc) return false
    doc.rules.push(rule)
    return true
  }
  
  /**
   * Toggle rule active status
   */
  static toggleRuleActive(ruleId: string): boolean {
    for (const doc of documents) {
      const rule = doc.rules.find(r => r.id === ruleId)
      if (rule) {
        rule.isActive = !rule.isActive
        return true
      }
    }
    return false
  }
  
  /**
   * Get rules applicable to an incident type
   */
  static getRulesForIncidentType(incidentType: string): NormativeRule[] {
    return this.getAllActiveRules().filter(rule => 
      rule.applicableIncidentTypes === 'all' || 
      rule.applicableIncidentTypes.includes(incidentType as any)
    )
  }
}

// Helper to map document types to categories
function mapDocumentTypeToCategory(type: string): import('./types').RuleCategory {
  const mapping: Record<string, import('./types').RuleCategory> = {
    ley: 'ley',
    real_decreto: 'ley',
    orden_ministerial: 'protocolo',
    plan_territorial: 'protocolo',
    plan_especial: 'protocolo',
    procedimiento_operativo: 'procedimiento',
    ordenanza_municipal: 'normativa_local',
    directriz: 'directriz',
  }
  return mapping[type] || 'procedimiento'
}

// Singleton instance for API usage
export const rulesEngine = {
  getRegulations: (): Regulation[] => {
    return documents.map(doc => ({
      id: doc.id,
      title: doc.title,
      description: doc.summary,
      category: mapDocumentTypeToCategory(doc.type),
      sourceDocument: doc.reference,
      effectiveDate: doc.effectiveDate,
      status: doc.status,
      rules: doc.rules.map(rule => ({
        id: rule.id,
        condition: rule.conditions.length > 0 
          ? rule.conditions.map(c => `${c.field} ${c.operator} ${c.value}`).join(' AND ')
          : rule.name,
        action: rule.actions.map(a => a.details).join('; '),
        priority: rule.complianceLevel === 'obligatorio' ? 5 : rule.complianceLevel === 'recomendado' ? 3 : 1,
        isMandatory: rule.complianceLevel === 'obligatorio',
      }))
    }))
  },
  addRegulation: (data: {
    title: string
    description?: string
    category: string
    sourceDocument?: string
    content: string
  }) => {
    // Create a new document from the input
    const newDoc: NormativeDocument = {
      id: `doc-${Date.now()}`,
      type: 'protocolo',
      title: data.title,
      shortTitle: data.title.substring(0, 30),
      reference: data.sourceDocument || 'Manual',
      publicationDate: new Date().toISOString().split('T')[0],
      effectiveDate: new Date().toISOString().split('T')[0],
      issuingAuthority: 'Puesto de Mando',
      summary: data.description || '',
      scope: 'Local',
      status: 'vigente',
      lastUpdated: new Date().toISOString().split('T')[0],
      rules: [],
    }
    
    // Extract rules from content
    const extractedRules = rulesEngine.extractRulesFromText(data.content)
    newDoc.rules = extractedRules.map((rule, idx) => ({
      id: `rule-${newDoc.id}-${idx}`,
      documentId: newDoc.id,
      articleReference: `Seccion ${idx + 1}`,
      name: rule.condition.substring(0, 50),
      description: rule.action,
      conditions: [],
      conditionLogic: 'AND' as const,
      actions: [{
        type: 'follow_protocol' as const,
        details: rule.action,
        mandatory: rule.priority >= 3,
      }],
      applicableIncidentTypes: 'all',
      applicablePriorities: ['critica', 'alta', 'media', 'baja'],
      geographicScope: 'local',
      isActive: true,
      lastReviewDate: new Date().toISOString().split('T')[0],
    }))
    
    RulesEngine.addDocument(newDoc)
    
    return {
      ...newDoc,
      category: data.category,
      extractedRules: extractedRules,
    }
  },
  extractRulesFromText: (content: string) => {
    // Placeholder for rule extraction logic
    return []
  },
  evaluateIncident: (context: any) => {
    // Placeholder for incident evaluation logic
    return []
  },
}
