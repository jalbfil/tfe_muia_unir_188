/**
 * Normative Rules Engine Types
 * For managing regulatory documents and extracted rules
 */

import type { IncidentType, PriorityLevel } from '@/lib/types'
import type { AgencyType, ResourceType } from '@/lib/protocols/types'

/**
 * Regulatory document types
 */
export type DocumentType =
  | 'ley'
  | 'real_decreto'
  | 'orden_ministerial'
  | 'plan_territorial'
  | 'plan_especial'
  | 'procedimiento_operativo'
  | 'ordenanza_municipal'
  | 'directriz'

/**
 * Rule trigger conditions
 */
export interface RuleCondition {
  field: 'incidentType' | 'priority' | 'urgencyScore' | 'impactScore' | 'location' | 'keyword'
  operator: 'equals' | 'contains' | 'greater_than' | 'less_than' | 'in'
  value: string | number | string[]
}

/**
 * Rule action types
 */
export type RuleActionType =
  | 'notify_agency'
  | 'require_resource'
  | 'mandate_protocol'
  | 'escalate_priority'
  | 'activate_plan'
  | 'require_authorization'
  | 'inform_authority'
  | 'document_requirement'

/**
 * Rule action definition
 */
export interface RuleAction {
  type: RuleActionType
  target?: AgencyType | ResourceType | string
  details: string
  mandatory: boolean
  timeLimit?: string
}

/**
 * Extracted rule from normative document
 */
export interface NormativeRule {
  id: string
  documentId: string
  articleReference: string        // e.g., "Art. 15.2"
  
  // Rule definition
  name: string
  description: string
  conditions: RuleCondition[]
  conditionLogic: 'AND' | 'OR'
  actions: RuleAction[]
  
  // Applicability
  applicableIncidentTypes: IncidentType[] | 'all'
  applicablePriorities: PriorityLevel[] | 'all'
  geographicScope: 'nacional' | 'autonomico' | 'provincial' | 'municipal'
  
  // Metadata
  isActive: boolean
  effectiveFrom: string
  effectiveUntil?: string
  lastReviewed: string
  
  // Compliance tracking
  complianceLevel: 'obligatorio' | 'recomendado' | 'informativo'
}

/**
 * Normative document
 */
export interface NormativeDocument {
  id: string
  type: DocumentType
  title: string
  shortTitle: string
  reference: string               // e.g., "BOE-A-2015-8047"
  publicationDate: string
  effectiveDate: string
  
  // Source
  issuingAuthority: string
  officialSource: string          // URL or reference
  
  // Content
  summary: string
  scope: string
  
  // Extracted rules
  rules: NormativeRule[]
  
  // Metadata
  lastUpdated: string
  status: 'vigente' | 'derogado' | 'modificado'
  supersededBy?: string
}

/**
 * Rule evaluation result
 */
export interface RuleEvaluation {
  ruleId: string
  rule: NormativeRule
  triggered: boolean
  matchedConditions: {
    condition: RuleCondition
    actualValue: unknown
    matched: boolean
  }[]
  requiredActions: RuleAction[]
  complianceNotes: string[]
}

/**
 * Compliance check result for an incident
 */
export interface ComplianceCheck {
  incidentId: string
  checkedAt: string
  
  // Evaluated rules
  evaluations: RuleEvaluation[]
  triggeredRules: NormativeRule[]
  
  // Required actions
  mandatoryActions: RuleAction[]
  recommendedActions: RuleAction[]
  
  // Compliance status
  isCompliant: boolean
  complianceScore: number         // 0-100
  warnings: string[]
  violations: string[]
  
  // Referenced documents
  applicableDocuments: {
    documentId: string
    title: string
    relevantArticles: string[]
  }[]
}

/**
 * Rule suggestion for manual review
 */
export interface RuleSuggestion {
  id: string
  documentId: string
  extractedText: string
  suggestedRule: Partial<NormativeRule>
  confidence: number              // 0-100
  status: 'pending' | 'accepted' | 'rejected' | 'modified'
  reviewedBy?: string
  reviewedAt?: string
  notes?: string
}

/**
 * Rule category for UI display
 */
export type RuleCategory = 
  | 'ley'
  | 'protocolo' 
  | 'procedimiento'
  | 'directriz'
  | 'normativa_local'

/**
 * Simplified regulation for UI display
 */
export interface Regulation {
  id: string
  title: string
  description: string
  category: RuleCategory
  sourceDocument: string
  effectiveDate: string
  status: 'vigente' | 'derogado' | 'modificado'
  rules: ExtractedRule[]
}

/**
 * Extracted rule in simplified format
 */
export interface ExtractedRule {
  id: string
  condition: string
  action: string
  priority: number
  isMandatory: boolean
}
