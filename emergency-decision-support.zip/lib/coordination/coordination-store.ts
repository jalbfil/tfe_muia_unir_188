/**
 * Coordination Store
 * Manages multi-agency coordination data
 */

import type {
  CoordinationMessage,
  AgencyContact,
  CoordinationRequest,
  AgencyNotification,
  CoordinationLogEntry,
  AgencyIncidentStatus,
  IncidentCoordination,
} from './types'
import type { AgencyType } from '@/lib/protocols/types'

// Sample agency contacts
const AGENCY_CONTACTS: AgencyContact[] = [
  {
    agency: 'bomberos',
    name: 'Central de Bomberos',
    role: 'Coordinador de Guardia',
    radioChannel: 'Canal 1',
    phoneNumber: '+34 112',
    email: 'coordinacion@bomberos.es',
    available: true,
  },
  {
    agency: 'servicios_medicos',
    name: 'SAMUR Central',
    role: 'Coordinador Sanitario',
    radioChannel: 'Canal 3',
    phoneNumber: '+34 061',
    email: 'coordinacion@samur.es',
    available: true,
  },
  {
    agency: 'policia',
    name: 'Policia Local',
    role: 'Jefe de Turno',
    radioChannel: 'Canal 2',
    phoneNumber: '+34 092',
    email: 'coordinacion@policia.es',
    available: true,
  },
  {
    agency: 'proteccion_civil',
    name: 'Proteccion Civil',
    role: 'Coordinador Provincial',
    radioChannel: 'Canal 5',
    phoneNumber: '+34 900 112 112',
    email: 'emergencias@proteccioncivil.es',
    available: true,
  },
  {
    agency: 'ayuntamiento',
    name: 'Ayuntamiento - Emergencias',
    role: 'Concejal de Seguridad',
    phoneNumber: '+34 010',
    email: 'emergencias@ayto.es',
    available: true,
  },
  {
    agency: 'compania_servicios',
    name: 'Servicios Publicos',
    role: 'Central de Averias',
    phoneNumber: '+34 900 100 100',
    available: true,
  },
]

// In-memory coordination data
const incidentCoordinations: Map<string, IncidentCoordination> = new Map()

/**
 * Coordination Store Class
 */
export class CoordinationStore {
  /**
   * Get all agency contacts
   */
  static getAgencyContacts(): AgencyContact[] {
    return [...AGENCY_CONTACTS]
  }
  
  /**
   * Get contact for specific agency
   */
  static getAgencyContact(agency: AgencyType): AgencyContact | null {
    return AGENCY_CONTACTS.find(c => c.agency === agency) || null
  }
  
  /**
   * Initialize coordination for an incident
   */
  static initializeIncidentCoordination(
    incidentId: string,
    leadAgency: AgencyType
  ): IncidentCoordination {
    const existing = incidentCoordinations.get(incidentId)
    if (existing) return existing
    
    const coordination: IncidentCoordination = {
      incidentId,
      leadAgency,
      involvedAgencies: [{
        agency: leadAgency,
        status: 'notificada',
        unitsAssigned: 0,
        lastUpdate: new Date().toISOString(),
        notes: [],
      }],
      messages: [],
      requests: [],
      notifications: [],
      log: [{
        id: `log-${Date.now()}`,
        incidentId,
        timestamp: new Date().toISOString(),
        agency: leadAgency,
        action: 'Coordinacion iniciada',
        details: `${leadAgency} asume el mando del incidente`,
      }],
    }
    
    incidentCoordinations.set(incidentId, coordination)
    return coordination
  }
  
  /**
   * Get coordination data for an incident
   */
  static getIncidentCoordination(incidentId: string): IncidentCoordination | null {
    return incidentCoordinations.get(incidentId) || null
  }
  
  /**
   * Add agency to incident
   */
  static addAgencyToIncident(
    incidentId: string,
    agency: AgencyType
  ): IncidentCoordination | null {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return null
    
    if (coordination.involvedAgencies.some(a => a.agency === agency)) {
      return coordination
    }
    
    coordination.involvedAgencies.push({
      agency,
      status: 'notificada',
      unitsAssigned: 0,
      lastUpdate: new Date().toISOString(),
      notes: [],
    })
    
    coordination.log.push({
      id: `log-${Date.now()}`,
      incidentId,
      timestamp: new Date().toISOString(),
      agency,
      action: 'Agencia incorporada',
      details: `${agency} se incorpora a la coordinacion`,
    })
    
    return coordination
  }
  
  /**
   * Update agency status in incident
   */
  static updateAgencyStatus(
    incidentId: string,
    agency: AgencyType,
    status: AgencyIncidentStatus['status'],
    notes?: string
  ): IncidentCoordination | null {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return null
    
    const agencyStatus = coordination.involvedAgencies.find(a => a.agency === agency)
    if (!agencyStatus) return null
    
    agencyStatus.status = status
    agencyStatus.lastUpdate = new Date().toISOString()
    if (notes) {
      agencyStatus.notes.push(notes)
    }
    
    coordination.log.push({
      id: `log-${Date.now()}`,
      incidentId,
      timestamp: new Date().toISOString(),
      agency,
      action: `Estado actualizado: ${status}`,
      details: notes || `${agency} cambia estado a ${status}`,
    })
    
    return coordination
  }
  
  /**
   * Send coordination message
   */
  static sendMessage(
    incidentId: string,
    message: Omit<CoordinationMessage, 'id' | 'timestamp'>
  ): CoordinationMessage | null {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return null
    
    const newMessage: CoordinationMessage = {
      ...message,
      id: `msg-${Date.now()}`,
      timestamp: new Date().toISOString(),
    }
    
    coordination.messages.push(newMessage)
    
    coordination.log.push({
      id: `log-${Date.now()}`,
      incidentId,
      timestamp: new Date().toISOString(),
      agency: message.fromAgency,
      action: 'Mensaje enviado',
      details: `A ${message.toAgency}: ${message.subject}`,
      relatedMessageId: newMessage.id,
    })
    
    return newMessage
  }
  
  /**
   * Acknowledge message
   */
  static acknowledgeMessage(
    incidentId: string,
    messageId: string,
    acknowledgedBy: string
  ): CoordinationMessage | null {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return null
    
    const message = coordination.messages.find(m => m.id === messageId)
    if (!message) return null
    
    message.acknowledgedAt = new Date().toISOString()
    message.acknowledgedBy = acknowledgedBy
    
    return message
  }
  
  /**
   * Create coordination request
   */
  static createRequest(
    incidentId: string,
    request: Omit<CoordinationRequest, 'id' | 'status' | 'createdAt'>
  ): CoordinationRequest | null {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return null
    
    const newRequest: CoordinationRequest = {
      ...request,
      id: `req-${Date.now()}`,
      status: 'pendiente',
      createdAt: new Date().toISOString(),
    }
    
    coordination.requests.push(newRequest)
    
    coordination.log.push({
      id: `log-${Date.now()}`,
      incidentId,
      timestamp: new Date().toISOString(),
      agency: request.requestingAgency,
      action: `Solicitud creada: ${request.type}`,
      details: request.description,
    })
    
    return newRequest
  }
  
  /**
   * Respond to coordination request
   */
  static respondToRequest(
    incidentId: string,
    requestId: string,
    status: 'aceptada' | 'rechazada',
    notes?: string
  ): CoordinationRequest | null {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return null
    
    const request = coordination.requests.find(r => r.id === requestId)
    if (!request) return null
    
    request.status = status
    request.respondedAt = new Date().toISOString()
    request.responseNotes = notes
    
    coordination.log.push({
      id: `log-${Date.now()}`,
      incidentId,
      timestamp: new Date().toISOString(),
      agency: request.targetAgency,
      action: `Solicitud ${status}`,
      details: notes || `Respuesta a solicitud de ${request.requestingAgency}`,
    })
    
    return request
  }
  
  /**
   * Send notification to agencies
   */
  static sendNotification(
    incidentId: string,
    notification: Omit<AgencyNotification, 'id' | 'createdAt' | 'readBy'>
  ): AgencyNotification | null {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return null
    
    const newNotification: AgencyNotification = {
      ...notification,
      id: `notif-${Date.now()}`,
      createdAt: new Date().toISOString(),
      readBy: [],
    }
    
    coordination.notifications.push(newNotification)
    
    coordination.log.push({
      id: `log-${Date.now()}`,
      incidentId,
      timestamp: new Date().toISOString(),
      agency: coordination.leadAgency,
      action: `Notificacion: ${notification.type}`,
      details: notification.title,
    })
    
    return newNotification
  }
  
  /**
   * Establish command post
   */
  static establishCommandPost(
    incidentId: string,
    location: string,
    frequency: string
  ): IncidentCoordination | null {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return null
    
    coordination.commandPost = {
      location,
      established: new Date().toISOString(),
      frequency,
    }
    
    coordination.log.push({
      id: `log-${Date.now()}`,
      incidentId,
      timestamp: new Date().toISOString(),
      agency: coordination.leadAgency,
      action: 'Puesto de Mando establecido',
      details: `Ubicacion: ${location}, Frecuencia: ${frequency}`,
    })
    
    return coordination
  }
  
  /**
   * Get coordination log for an incident
   */
  static getCoordinationLog(incidentId: string): CoordinationLogEntry[] {
    const coordination = incidentCoordinations.get(incidentId)
    if (!coordination) return []
    
    return [...coordination.log].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    )
  }
}
