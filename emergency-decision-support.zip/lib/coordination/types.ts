/**
 * Multi-Agency Coordination Types
 */

import type { AgencyType } from '@/lib/protocols/types'

/**
 * Communication message between agencies
 */
export interface CoordinationMessage {
  id: string
  incidentId: string
  fromAgency: AgencyType
  toAgency: AgencyType | 'all'
  channel: 'radio' | 'telefono' | 'digital' | 'presencial'
  priority: 'urgente' | 'normal' | 'informativo'
  subject: string
  content: string
  timestamp: string
  acknowledgedAt?: string
  acknowledgedBy?: string
}

/**
 * Agency contact information
 */
export interface AgencyContact {
  agency: AgencyType
  name: string
  role: string
  radioChannel?: string
  phoneNumber: string
  email?: string
  available: boolean
}

/**
 * Coordination request (e.g., request for resources from another agency)
 */
export interface CoordinationRequest {
  id: string
  incidentId: string
  requestingAgency: AgencyType
  targetAgency: AgencyType
  type: 'recurso' | 'informacion' | 'apoyo' | 'autorizacion'
  description: string
  status: 'pendiente' | 'aceptada' | 'rechazada' | 'completada'
  createdAt: string
  respondedAt?: string
  responseNotes?: string
}

/**
 * Inter-agency notification
 */
export interface AgencyNotification {
  id: string
  incidentId: string
  agencies: AgencyType[]
  type: 'activacion' | 'escalada' | 'cierre' | 'actualizacion' | 'alerta'
  title: string
  message: string
  createdAt: string
  readBy: { agency: AgencyType; readAt: string }[]
}

/**
 * Coordination log entry
 */
export interface CoordinationLogEntry {
  id: string
  incidentId: string
  timestamp: string
  agency: AgencyType
  action: string
  details: string
  relatedMessageId?: string
}

/**
 * Agency status in an incident
 */
export interface AgencyIncidentStatus {
  agency: AgencyType
  status: 'notificada' | 'en_camino' | 'en_escena' | 'operando' | 'finalizada'
  contactPerson?: string
  unitsAssigned: number
  lastUpdate: string
  notes: string[]
}

/**
 * Incident coordination summary
 */
export interface IncidentCoordination {
  incidentId: string
  leadAgency: AgencyType
  involvedAgencies: AgencyIncidentStatus[]
  messages: CoordinationMessage[]
  requests: CoordinationRequest[]
  notifications: AgencyNotification[]
  log: CoordinationLogEntry[]
  commandPost?: {
    location: string
    established: string
    frequency: string
  }
}
