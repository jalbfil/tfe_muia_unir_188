/**
 * Timeline and Situation Analysis Types
 */

import type { AgencyType, ResourceType } from '@/lib/protocols/types'
import type { PriorityLevel, IncidentType } from '@/lib/types'

/**
 * Timeline event categories
 */
export type EventCategory =
  | 'alerta'           // Initial alert received
  | 'clasificacion'    // NLP classification
  | 'decision'         // Operator decision
  | 'despacho'         // Resource dispatch
  | 'llegada'          // Unit arrival
  | 'operacion'        // Operational action
  | 'escalada'         // Priority escalation
  | 'coordinacion'     // Multi-agency coordination
  | 'actualizacion'    // Status update
  | 'cierre'           // Incident closure

/**
 * Single timeline event
 */
export interface TimelineEvent {
  id: string
  incidentId: string
  timestamp: string
  category: EventCategory
  title: string
  description: string
  agency?: AgencyType
  resourceType?: ResourceType
  operator?: string
  metadata?: Record<string, unknown>
  isAutomatic: boolean // True if system-generated, false if operator action
}

/**
 * Situation assessment at a point in time
 */
export interface SituationSnapshot {
  id: string
  incidentId: string
  timestamp: string
  assessedBy: string
  
  // Current state
  priority: PriorityLevel
  incidentType: IncidentType
  location: string | null
  
  // Evolution indicators
  controlled: boolean
  spreading: boolean
  casualties: {
    confirmed: number
    estimated: number
    evacuated: number
  }
  
  // Resources on scene
  resourcesOnScene: {
    type: ResourceType
    count: number
  }[]
  
  // Assessment
  threats: string[]
  needs: string[]
  nextActions: string[]
  
  notes: string
}

/**
 * Escalation prediction
 */
export interface EscalationRisk {
  level: 'bajo' | 'medio' | 'alto' | 'critico'
  probability: number // 0-100
  factors: string[]
  recommendations: string[]
  timeframe: string // e.g., "proximos 30 min"
}

/**
 * Incident evolution summary
 */
export interface IncidentEvolution {
  incidentId: string
  startTime: string
  currentTime: string
  durationMinutes: number
  
  // Priority changes
  priorityHistory: {
    priority: PriorityLevel
    changedAt: string
    reason: string
  }[]
  
  // Key metrics
  timeToFirstResponse: number | null    // minutes
  timeToFirstArrival: number | null     // minutes
  timeToControl: number | null          // minutes (if controlled)
  
  // Current state
  currentPriority: PriorityLevel
  isControlled: boolean
  isEscalating: boolean
  
  // Predictions
  escalationRisk: EscalationRisk
}

/**
 * Situation report (SITREP)
 */
export interface SituationReport {
  id: string
  incidentId: string
  reportNumber: number
  generatedAt: string
  generatedBy: string
  
  // Summary
  summary: string
  
  // Current situation
  situation: SituationSnapshot
  
  // Evolution
  evolution: IncidentEvolution
  
  // Timeline highlights
  keyEvents: TimelineEvent[]
  
  // Recommendations
  recommendations: string[]
  
  // Next report scheduled
  nextReportAt?: string
}
