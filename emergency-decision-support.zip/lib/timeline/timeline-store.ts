/**
 * Timeline Store
 * Manages incident timeline and situation analysis
 */

import type {
  TimelineEvent,
  SituationSnapshot,
  EscalationRisk,
  IncidentEvolution,
  EventCategory,
} from './types'
import type { AgencyType, ResourceType } from '@/lib/protocols/types'
import type { Incident, PriorityLevel } from '@/lib/types'

// In-memory timeline storage
const incidentTimelines: Map<string, TimelineEvent[]> = new Map()
const situationSnapshots: Map<string, SituationSnapshot[]> = new Map()

/**
 * Timeline Store Class
 */
export class TimelineStore {
  /**
   * Add event to incident timeline
   */
  static addEvent(
    incidentId: string,
    event: Omit<TimelineEvent, 'id' | 'incidentId' | 'timestamp'>
  ): TimelineEvent {
    const timeline = incidentTimelines.get(incidentId) || []
    
    const newEvent: TimelineEvent = {
      ...event,
      id: `event-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      incidentId,
      timestamp: new Date().toISOString(),
    }
    
    timeline.push(newEvent)
    incidentTimelines.set(incidentId, timeline)
    
    return newEvent
  }
  
  /**
   * Get timeline for an incident
   */
  static getTimeline(incidentId: string): TimelineEvent[] {
    return [...(incidentTimelines.get(incidentId) || [])].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    )
  }
  
  /**
   * Get timeline events by category
   */
  static getEventsByCategory(
    incidentId: string,
    category: EventCategory
  ): TimelineEvent[] {
    const timeline = incidentTimelines.get(incidentId) || []
    return timeline.filter(e => e.category === category)
  }
  
  /**
   * Add situation snapshot
   */
  static addSnapshot(
    incidentId: string,
    snapshot: Omit<SituationSnapshot, 'id' | 'incidentId' | 'timestamp'>
  ): SituationSnapshot {
    const snapshots = situationSnapshots.get(incidentId) || []
    
    const newSnapshot: SituationSnapshot = {
      ...snapshot,
      id: `snap-${Date.now()}`,
      incidentId,
      timestamp: new Date().toISOString(),
    }
    
    snapshots.push(newSnapshot)
    situationSnapshots.set(incidentId, snapshots)
    
    return newSnapshot
  }
  
  /**
   * Get latest situation snapshot
   */
  static getLatestSnapshot(incidentId: string): SituationSnapshot | null {
    const snapshots = situationSnapshots.get(incidentId) || []
    if (snapshots.length === 0) return null
    return snapshots[snapshots.length - 1]
  }
  
  /**
   * Get all snapshots for an incident
   */
  static getSnapshots(incidentId: string): SituationSnapshot[] {
    return [...(situationSnapshots.get(incidentId) || [])]
  }
  
  /**
   * Calculate incident evolution
   */
  static calculateEvolution(incident: Incident): IncidentEvolution {
    const timeline = this.getTimeline(incident.id)
    const now = new Date()
    const startTime = new Date(incident.createdAt)
    const durationMinutes = Math.round((now.getTime() - startTime.getTime()) / 60000)
    
    // Find key events
    const firstResponse = timeline.find(e => e.category === 'decision')
    const firstArrival = timeline.find(e => e.category === 'llegada')
    const controlEvent = timeline.find(e => 
      e.category === 'operacion' && e.title.toLowerCase().includes('controlado')
    )
    
    // Build priority history
    const priorityEvents = timeline.filter(e => 
      e.category === 'escalada' || (e.category === 'clasificacion' && e.metadata?.priority)
    )
    
    const priorityHistory = [
      {
        priority: incident.priority,
        changedAt: incident.processedAt,
        reason: 'Clasificacion inicial',
      },
      ...priorityEvents.map(e => ({
        priority: (e.metadata?.newPriority as PriorityLevel) || incident.priority,
        changedAt: e.timestamp,
        reason: e.description,
      })),
    ]
    
    // Calculate escalation risk
    const escalationRisk = this.calculateEscalationRisk(incident, timeline)
    
    return {
      incidentId: incident.id,
      startTime: incident.createdAt,
      currentTime: now.toISOString(),
      durationMinutes,
      priorityHistory,
      timeToFirstResponse: firstResponse 
        ? Math.round((new Date(firstResponse.timestamp).getTime() - startTime.getTime()) / 60000)
        : null,
      timeToFirstArrival: firstArrival
        ? Math.round((new Date(firstArrival.timestamp).getTime() - startTime.getTime()) / 60000)
        : null,
      timeToControl: controlEvent
        ? Math.round((new Date(controlEvent.timestamp).getTime() - startTime.getTime()) / 60000)
        : null,
      currentPriority: incident.priority,
      isControlled: !!controlEvent,
      isEscalating: priorityHistory.length > 1 && 
        priorityHistory[priorityHistory.length - 1].priority === 'critica',
      escalationRisk,
    }
  }
  
  /**
   * Calculate escalation risk based on incident data and timeline
   */
  private static calculateEscalationRisk(
    incident: Incident,
    timeline: TimelineEvent[]
  ): EscalationRisk {
    const factors: string[] = []
    const recommendations: string[] = []
    let riskScore = 0
    
    // Factor: Current priority
    if (incident.priority === 'critica') {
      riskScore += 30
      factors.push('Prioridad critica actual')
    } else if (incident.priority === 'alta') {
      riskScore += 20
      factors.push('Prioridad alta')
    }
    
    // Factor: Urgency score
    if (incident.urgencyScore >= 8) {
      riskScore += 20
      factors.push('Indicadores de urgencia elevados')
      recommendations.push('Considerar recursos adicionales')
    }
    
    // Factor: Impact score
    if (incident.impactScore >= 7) {
      riskScore += 15
      factors.push('Alto impacto potencial')
      recommendations.push('Alertar a mandos superiores')
    }
    
    // Factor: Time without control
    const durationMinutes = Math.round(
      (Date.now() - new Date(incident.createdAt).getTime()) / 60000
    )
    if (durationMinutes > 30 && incident.status === 'pendiente') {
      riskScore += 15
      factors.push(`${durationMinutes} minutos sin decision`)
      recommendations.push('Requiere atencion inmediata')
    }
    
    // Factor: Type-specific risks
    if (['incendio', 'explosion', 'fuga_gas'].includes(incident.incidentType)) {
      riskScore += 10
      factors.push('Tipo de incidente con riesgo de propagacion')
      recommendations.push('Evaluar necesidad de evacuacion')
    }
    
    // Factor: No resources dispatched
    const dispatchEvents = timeline.filter(e => e.category === 'despacho')
    if (dispatchEvents.length === 0 && durationMinutes > 5) {
      riskScore += 10
      factors.push('Sin recursos despachados')
      recommendations.push('Despachar recursos de inmediato')
    }
    
    // Determine risk level
    let level: EscalationRisk['level']
    if (riskScore >= 60) {
      level = 'critico'
    } else if (riskScore >= 40) {
      level = 'alto'
    } else if (riskScore >= 20) {
      level = 'medio'
    } else {
      level = 'bajo'
    }
    
    // Add default recommendations if empty
    if (recommendations.length === 0) {
      recommendations.push('Continuar monitorizacion normal')
    }
    
    return {
      level,
      probability: Math.min(100, riskScore),
      factors: factors.length > 0 ? factors : ['Sin factores de riesgo identificados'],
      recommendations,
      timeframe: level === 'critico' ? 'inmediato' : 
                 level === 'alto' ? 'proximos 15 min' : 
                 level === 'medio' ? 'proximos 30 min' : 'proxima hora',
    }
  }
  
  /**
   * Initialize timeline for a new incident
   */
  static initializeIncidentTimeline(incident: Incident): void {
    // Add initial events
    this.addEvent(incident.id, {
      category: 'alerta',
      title: 'Alerta recibida',
      description: `Aviso de emergencia recibido: ${incident.rawText.substring(0, 100)}...`,
      isAutomatic: true,
    })
    
    this.addEvent(incident.id, {
      category: 'clasificacion',
      title: 'Clasificacion NLP',
      description: `Clasificado como ${incident.incidentType} con prioridad ${incident.priority}`,
      isAutomatic: true,
      metadata: {
        incidentType: incident.incidentType,
        priority: incident.priority,
        urgencyScore: incident.urgencyScore,
        impactScore: incident.impactScore,
      },
    })
  }
  
  /**
   * Record operator decision
   */
  static recordDecision(
    incidentId: string,
    action: string,
    operator: string,
    details: string
  ): TimelineEvent {
    return this.addEvent(incidentId, {
      category: 'decision',
      title: `Decision: ${action}`,
      description: details,
      operator,
      isAutomatic: false,
    })
  }
  
  /**
   * Record resource dispatch
   */
  static recordDispatch(
    incidentId: string,
    resourceType: ResourceType,
    unitCode: string,
    agency: AgencyType
  ): TimelineEvent {
    return this.addEvent(incidentId, {
      category: 'despacho',
      title: `Despacho: ${unitCode}`,
      description: `${resourceType} despachado al incidente`,
      agency,
      resourceType,
      isAutomatic: false,
    })
  }
  
  /**
   * Record unit arrival
   */
  static recordArrival(
    incidentId: string,
    resourceType: ResourceType,
    unitCode: string,
    agency: AgencyType
  ): TimelineEvent {
    return this.addEvent(incidentId, {
      category: 'llegada',
      title: `Llegada: ${unitCode}`,
      description: `${resourceType} en escena`,
      agency,
      resourceType,
      isAutomatic: false,
    })
  }
  
  /**
   * Record priority escalation
   */
  static recordEscalation(
    incidentId: string,
    newPriority: PriorityLevel,
    reason: string,
    operator: string
  ): TimelineEvent {
    return this.addEvent(incidentId, {
      category: 'escalada',
      title: `Escalada a ${newPriority.toUpperCase()}`,
      description: reason,
      operator,
      isAutomatic: false,
      metadata: { newPriority },
    })
  }
}
