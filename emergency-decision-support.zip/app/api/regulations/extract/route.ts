import { NextResponse } from 'next/server'
import { rulesEngine } from '@/lib/rules/rules-engine'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { content } = body
    
    if (!content) {
      return NextResponse.json(
        { error: 'Content is required' },
        { status: 400 }
      )
    }
    
    const rules = rulesEngine.extractRulesFromText(content)
    
    return NextResponse.json({ rules })
  } catch (error) {
    console.error('Error extracting rules:', error)
    return NextResponse.json({ error: 'Error extracting rules' }, { status: 500 })
  }
}
