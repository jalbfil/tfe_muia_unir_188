import { NextResponse } from 'next/server'
import { rulesEngine } from '@/lib/rules/rules-engine'

export async function GET() {
  try {
    const regulations = rulesEngine.getRegulations()
    return NextResponse.json(regulations)
  } catch (error) {
    console.error('Error fetching regulations:', error)
    return NextResponse.json({ error: 'Error fetching regulations' }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { title, description, category, sourceDocument, content } = body
    
    if (!title || !content) {
      return NextResponse.json(
        { error: 'Title and content are required' },
        { status: 400 }
      )
    }
    
    const regulation = rulesEngine.addRegulation({
      title,
      description,
      category: category || 'procedimiento',
      sourceDocument,
      content
    })
    
    return NextResponse.json(regulation)
  } catch (error) {
    console.error('Error adding regulation:', error)
    return NextResponse.json({ error: 'Error adding regulation' }, { status: 500 })
  }
}
