import { NextResponse } from 'next/server'
import { rulesEngine } from '@/lib/rules/rules-engine'
import type { IncidentContext } from '@/lib/rules/types'

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const context: IncidentContext = body.context
    
    if (!context) {
      return NextResponse.json(
        { error: 'Incident context is required' },
        { status: 400 }
      )
    }
    
    const results = rulesEngine.evaluateRules(context)
    
    return NextResponse.json({ results })
  } catch (error) {
    console.error('Error evaluating rules:', error)
    return NextResponse.json({ error: 'Error evaluating rules' }, { status: 500 })
  }
}
