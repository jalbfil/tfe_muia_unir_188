/**
 * API Routes for Incident Management
 * 
 * GET  /api/incidents - List all incidents
 * POST /api/incidents - Create new incident from text
 */

import { NextResponse } from 'next/server'
import { createIncidentFromText } from '@/lib/nlp-engine'
import { addIncident, getAllIncidents } from '@/lib/incident-store'

export async function GET() {
  try {
    const incidents = getAllIncidents()
    return NextResponse.json({ success: true, data: incidents })
  } catch (error) {
    console.error('[v0] Error fetching incidents:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener incidentes' },
      { status: 500 }
    )
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { text } = body
    
    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      return NextResponse.json(
        { success: false, error: 'Se requiere texto del incidente' },
        { status: 400 }
      )
    }
    
    // Process text through NLP engine
    const incident = createIncidentFromText(text.trim())
    
    // Store the incident
    addIncident(incident)
    
    return NextResponse.json({ success: true, data: incident }, { status: 201 })
  } catch (error) {
    console.error('[v0] Error creating incident:', error)
    return NextResponse.json(
      { success: false, error: 'Error al procesar el incidente' },
      { status: 500 }
    )
  }
}
