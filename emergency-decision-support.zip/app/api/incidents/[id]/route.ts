/**
 * API Routes for Individual Incident Operations
 * 
 * GET  /api/incidents/[id] - Get incident details
 */

import { NextResponse } from 'next/server'
import { getIncidentById } from '@/lib/incident-store'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const incident = getIncidentById(id)
    
    if (!incident) {
      return NextResponse.json(
        { success: false, error: 'Incidente no encontrado' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({ success: true, data: incident })
  } catch (error) {
    console.error('[v0] Error fetching incident:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener el incidente' },
      { status: 500 }
    )
  }
}
