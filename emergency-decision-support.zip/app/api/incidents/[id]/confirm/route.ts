/**
 * API Route for Confirming Incident Decision
 * 
 * POST /api/incidents/[id]/confirm - Confirm operator decision
 * 
 * This is the critical "human in the loop" endpoint.
 * The system does NOT make decisions - the operator confirms.
 */

import { NextResponse } from 'next/server'
import { confirmIncident, getIncidentById } from '@/lib/incident-store'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    // Check if incident exists
    const existing = getIncidentById(id)
    if (!existing) {
      return NextResponse.json(
        { success: false, error: 'Incidente no encontrado' },
        { status: 404 }
      )
    }
    
    // Check if already confirmed
    if (existing.status === 'confirmado') {
      return NextResponse.json(
        { success: false, error: 'El incidente ya ha sido confirmado' },
        { status: 400 }
      )
    }
    
    // Confirm the incident - this records the operator's decision
    const confirmed = confirmIncident(id)
    
    if (!confirmed) {
      return NextResponse.json(
        { success: false, error: 'Error al confirmar el incidente' },
        { status: 500 }
      )
    }
    
    return NextResponse.json({ 
      success: true, 
      data: confirmed,
      message: `Decision confirmada. TTFD: ${confirmed.ttfd} segundos`
    })
  } catch (error) {
    console.error('[v0] Error confirming incident:', error)
    return NextResponse.json(
      { success: false, error: 'Error al confirmar la decision' },
      { status: 500 }
    )
  }
}
