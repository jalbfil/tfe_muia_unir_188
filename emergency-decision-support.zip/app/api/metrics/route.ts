/**
 * API Route for System Metrics
 * 
 * GET /api/metrics - Get system statistics
 */

import { NextResponse } from 'next/server'
import { getMetrics } from '@/lib/incident-store'

export async function GET() {
  try {
    const metrics = getMetrics()
    return NextResponse.json({ success: true, data: metrics })
  } catch (error) {
    console.error('[v0] Error fetching metrics:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener metricas' },
      { status: 500 }
    )
  }
}
