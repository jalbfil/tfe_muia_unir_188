import { NextResponse } from 'next/server'
import { ResourceStore } from '@/lib/resources/resource-store'

/**
 * GET /api/resources
 * Get all resources or filter by type/agency
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const agency = searchParams.get('agency')
    const status = searchParams.get('status')
    
    let units = ResourceStore.getAllUnits()
    
    if (type) {
      units = units.filter(u => u.type === type)
    }
    
    if (agency) {
      units = units.filter(u => u.agency === agency)
    }
    
    if (status) {
      units = units.filter(u => u.status === status)
    }
    
    const availability = ResourceStore.getAvailabilitySummary()
    
    return NextResponse.json({
      success: true,
      data: {
        units,
        availability,
        total: units.length,
      },
    })
  } catch (error) {
    console.error('[API] Error fetching resources:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener recursos' },
      { status: 500 }
    )
  }
}
