import { NextResponse } from 'next/server'
import { ResourceStore } from '@/lib/resources/resource-store'
import type { ResourceType } from '@/lib/protocols/types'

/**
 * GET /api/resources/recommendations
 * Get deployment recommendations for a resource type
 */
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') as ResourceType
    const lat = searchParams.get('lat')
    const lng = searchParams.get('lng')
    
    if (!type) {
      return NextResponse.json(
        { success: false, error: 'Se requiere tipo de recurso' },
        { status: 400 }
      )
    }
    
    const location = lat && lng 
      ? { lat: parseFloat(lat), lng: parseFloat(lng) }
      : undefined
    
    const recommendations = ResourceStore.getDeploymentRecommendations(type, location)
    
    return NextResponse.json({
      success: true,
      data: recommendations,
    })
  } catch (error) {
    console.error('[API] Error getting recommendations:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener recomendaciones' },
      { status: 500 }
    )
  }
}
