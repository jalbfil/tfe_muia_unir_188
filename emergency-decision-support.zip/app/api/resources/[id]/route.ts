import { NextResponse } from 'next/server'
import { ResourceStore } from '@/lib/resources/resource-store'
import type { UnitStatus } from '@/lib/resources/types'

/**
 * GET /api/resources/[id]
 * Get a specific resource unit
 */
export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const unit = ResourceStore.getUnitById(id)
    
    if (!unit) {
      return NextResponse.json(
        { success: false, error: 'Unidad no encontrada' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({
      success: true,
      data: unit,
    })
  } catch (error) {
    console.error('[API] Error fetching resource:', error)
    return NextResponse.json(
      { success: false, error: 'Error al obtener recurso' },
      { status: 500 }
    )
  }
}

/**
 * PATCH /api/resources/[id]
 * Update resource status
 */
export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { status, incidentId, location } = body as {
      status: UnitStatus
      incidentId?: string
      location?: { lat: number; lng: number }
    }
    
    const unit = ResourceStore.updateUnitStatus(id, status, incidentId, location)
    
    if (!unit) {
      return NextResponse.json(
        { success: false, error: 'Unidad no encontrada' },
        { status: 404 }
      )
    }
    
    return NextResponse.json({
      success: true,
      data: unit,
      message: `Estado actualizado a: ${status}`,
    })
  } catch (error) {
    console.error('[API] Error updating resource:', error)
    return NextResponse.json(
      { success: false, error: 'Error al actualizar recurso' },
      { status: 500 }
    )
  }
}
