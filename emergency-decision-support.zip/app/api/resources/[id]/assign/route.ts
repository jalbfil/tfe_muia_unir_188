import { NextResponse } from 'next/server'
import { ResourceStore } from '@/lib/resources/resource-store'

/**
 * POST /api/resources/[id]/assign
 * Assign a resource to an incident
 */
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { incidentId, operatorId = 'operator-1' } = body as {
      incidentId: string
      operatorId?: string
    }
    
    if (!incidentId) {
      return NextResponse.json(
        { success: false, error: 'Se requiere ID de incidente' },
        { status: 400 }
      )
    }
    
    const assignment = ResourceStore.assignUnitToIncident(id, incidentId, operatorId)
    
    if (!assignment) {
      return NextResponse.json(
        { success: false, error: 'No se pudo asignar la unidad. Verifique que esté disponible.' },
        { status: 400 }
      )
    }
    
    const unit = ResourceStore.getUnitById(id)
    
    return NextResponse.json({
      success: true,
      data: {
        assignment,
        unit,
      },
      message: `Unidad ${unit?.code} asignada al incidente`,
    })
  } catch (error) {
    console.error('[API] Error assigning resource:', error)
    return NextResponse.json(
      { success: false, error: 'Error al asignar recurso' },
      { status: 500 }
    )
  }
}
