import { Header } from '@/components/header'
import { RegulationsPanel } from '@/components/regulations-panel'

export const metadata = {
  title: 'Normativa - Sistema de Apoyo a la Decision',
  description: 'Gestion de reglamentos y normativas aplicables',
}

export default function RegulationsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">
            Normativa y Reglamentos
          </h2>
          <p className="mt-1 text-muted-foreground">
            Carga y gestion de reglamentos normativos con extraccion automatica de reglas
          </p>
        </div>
        
        <RegulationsPanel />
      </main>
    </div>
  )
}
