import { Header } from '@/components/header'
import { ResourcePanel } from '@/components/resource-panel'

export const metadata = {
  title: 'Recursos | Sistema de Emergencias',
  description: 'Gestion de recursos y unidades de emergencia',
}

export default function ResourcesPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">
            Gestion de Recursos
          </h2>
          <p className="mt-1 text-muted-foreground">
            Estado y disponibilidad de unidades de emergencia
          </p>
        </div>
        
        <ResourcePanel />
      </main>
    </div>
  )
}
