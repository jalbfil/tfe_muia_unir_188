import { Header } from '@/components/header'
import { IncidentDetail } from '@/components/incident-detail'
import { IncidentTimeline } from '@/components/incident-timeline'
import { ResourcePanel } from '@/components/resource-panel'
import { CoordinationPanel } from '@/components/coordination-panel'
import { RegulationsPanel } from '@/components/regulations-panel'

/**
 * Incident Detail Page
 * 
 * Comprehensive incident management view with:
 * - Incident details and NLP analysis
 * - Timeline of events
 * - Resource management
 * - Multi-agency coordination
 * - Applicable regulations
 */
export default async function IncidentPage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = await params
  
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">
            Gestion de Incidente
          </h2>
          <p className="mt-1 text-muted-foreground">
            Vista integral del incidente con todas las herramientas de apoyo a la decision.
          </p>
        </div>
        
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Column - Incident Detail */}
          <div className="lg:col-span-2 space-y-6">
            <IncidentDetail incidentId={id} />
            <IncidentTimeline incidentId={id} />
          </div>
          
          {/* Side Column - Support Tools */}
          <div className="space-y-6">
            <ResourcePanel incidentId={id} compact />
            <CoordinationPanel incidentId={id} compact />
            <RegulationsPanel />
          </div>
        </div>
      </main>
    </div>
  )
}
