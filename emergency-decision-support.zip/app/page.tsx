import { Header } from '@/components/header'
import { IncidentInputForm } from '@/components/incident-input-form'

/**
 * Main Entry Page
 * 
 * Screen 1: Input
 * Allows operators to enter new emergency reports for processing.
 */
export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">
            Entrada de Avisos
          </h2>
          <p className="mt-1 text-muted-foreground">
            Procesa nuevos avisos de emergencia mediante el motor NLP del sistema.
          </p>
        </div>
        
        <IncidentInputForm />
      </main>
    </div>
  )
}
