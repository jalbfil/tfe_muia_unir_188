import { Header } from '@/components/header'
import { CoordinationPanel } from '@/components/coordination-panel'

export const metadata = {
  title: 'Coordinacion - Sistema de Apoyo a la Decision',
  description: 'Coordinacion multi-agencia para emergencias',
}

export default function CoordinationPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">
            Coordinacion Multi-Agencia
          </h2>
          <p className="mt-1 text-muted-foreground">
            Gestion de comunicaciones y coordinacion entre servicios de emergencia
          </p>
        </div>
        
        <CoordinationPanel />
      </main>
    </div>
  )
}
