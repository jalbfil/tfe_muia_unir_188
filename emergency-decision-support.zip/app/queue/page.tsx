import { Header } from '@/components/header'
import { IncidentQueue } from '@/components/incident-queue'

/**
 * Incident Queue Page
 * 
 * Screen 2: Queue
 * Displays all incidents sorted by priority and status.
 */
export default function QueuePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">
            Cola de Incidentes
          </h2>
          <p className="mt-1 text-muted-foreground">
            Incidentes detectados ordenados por prioridad. Haz clic en un incidente para ver los detalles.
          </p>
        </div>
        
        <IncidentQueue />
      </main>
    </div>
  )
}
