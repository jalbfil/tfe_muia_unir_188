import { Header } from '@/components/header'
import { MetricsDisplay } from '@/components/metrics-display'

/**
 * Metrics Page
 * 
 * Displays system statistics and TTFD metrics for evaluation.
 */
export default function MetricsPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="mx-auto max-w-7xl px-4 py-8">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-foreground">
            Metricas del Sistema
          </h2>
          <p className="mt-1 text-muted-foreground">
            Estadisticas y analisis de rendimiento para evaluacion academica.
          </p>
        </div>
        
        <MetricsDisplay />
      </main>
    </div>
  )
}
