'use client'

import useSWR from 'swr'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { formatTTFD, getIncidentTypeLabel, getPriorityLabel } from '@/lib/nlp-engine'
import type { SystemMetrics, IncidentType, PriorityLevel } from '@/lib/types'

const fetcher = (url: string) => fetch(url).then((res) => res.json())

/**
 * Metrics Display Component
 * 
 * Shows system statistics and TTFD metrics for evaluation purposes.
 */
export function MetricsDisplay() {
  const { data, error, isLoading } = useSWR('/api/metrics', fetcher, {
    refreshInterval: 5000,
  })
  
  if (isLoading) {
    return (
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="h-8 w-16 rounded bg-muted" />
              <div className="mt-2 h-4 w-24 rounded bg-muted" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }
  
  if (error || !data?.success) {
    return (
      <Card className="border-destructive">
        <CardContent className="p-6 text-center">
          <p className="text-destructive">Error al cargar las metricas</p>
        </CardContent>
      </Card>
    )
  }
  
  const metrics: SystemMetrics = data.data
  
  return (
    <div className="space-y-6">
      {/* Main Stats */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-foreground">
              {metrics.totalIncidents}
            </div>
            <div className="text-sm text-muted-foreground">
              Total Incidentes
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-status-pending">
              {metrics.pendingIncidents}
            </div>
            <div className="text-sm text-muted-foreground">
              Pendientes de Decision
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-status-confirmed">
              {metrics.confirmedIncidents}
            </div>
            <div className="text-sm text-muted-foreground">
              Decisiones Confirmadas
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-6">
            <div className="text-3xl font-bold text-primary">
              {formatTTFD(metrics.averageTTFD)}
            </div>
            <div className="text-sm text-muted-foreground">
              TTFD Promedio
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Distribution Charts */}
      <div className="grid gap-6 lg:grid-cols-2">
        {/* By Priority */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Distribucion por Prioridad</CardTitle>
            <CardDescription>
              Clasificacion de incidentes segun nivel de prioridad
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {(Object.entries(metrics.incidentsByPriority) as [PriorityLevel, number][]).map(
                ([priority, count]) => {
                  const total = metrics.totalIncidents || 1
                  const percentage = Math.round((count / total) * 100)
                  
                  const colorClasses: Record<PriorityLevel, string> = {
                    critica: 'bg-priority-critical',
                    alta: 'bg-priority-high',
                    media: 'bg-priority-medium',
                    baja: 'bg-priority-low',
                  }
                  
                  return (
                    <div key={priority}>
                      <div className="mb-1 flex justify-between text-sm">
                        <span className="text-foreground">{getPriorityLabel(priority)}</span>
                        <span className="text-muted-foreground">{count} ({percentage}%)</span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className={`h-full rounded-full transition-all ${colorClasses[priority]}`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  )
                }
              )}
            </div>
          </CardContent>
        </Card>
        
        {/* By Type */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Distribucion por Tipo</CardTitle>
            <CardDescription>
              Clasificacion de incidentes segun tipo detectado por NLP
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {(Object.entries(metrics.incidentsByType) as [IncidentType, number][])
                .filter(([, count]) => count > 0)
                .sort(([, a], [, b]) => b - a)
                .map(([type, count]) => {
                  const total = metrics.totalIncidents || 1
                  const percentage = Math.round((count / total) * 100)
                  
                  return (
                    <div key={type}>
                      <div className="mb-1 flex justify-between text-sm">
                        <span className="text-foreground">{getIncidentTypeLabel(type)}</span>
                        <span className="text-muted-foreground">{count} ({percentage}%)</span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-muted">
                        <div
                          className="h-full rounded-full bg-primary transition-all"
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                    </div>
                  )
                })}
              {Object.values(metrics.incidentsByType).every((count) => count === 0) && (
                <p className="text-sm text-muted-foreground">
                  No hay datos de tipos de incidentes
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* TTFD Explanation */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Sobre el TTFD (Time To First Decision)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm text-muted-foreground">
            <p>
              El <strong className="text-foreground">Time To First Decision (TTFD)</strong> es la 
              metrica principal de este sistema. Mide el tiempo transcurrido desde que un aviso 
              de emergencia es ingresado hasta que un operador humano confirma la decision.
            </p>
            <div className="rounded-lg bg-secondary p-4">
              <p className="font-mono text-foreground">
                TTFD = Tiempo_Confirmacion - Tiempo_Ingesta
              </p>
            </div>
            <p>
              Esta metrica permite evaluar la eficacia del sistema de apoyo a la decision 
              comparando el TTFD con y sin asistencia del sistema NLP. Un TTFD menor indica 
              una toma de decisiones mas rapida.
            </p>
            <p>
              <strong className="text-foreground">Importante:</strong> El sistema no toma 
              decisiones automaticamente. El TTFD solo se registra cuando el operador humano 
              confirma la decision, asegurando el principio de "humano en el bucle".
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
