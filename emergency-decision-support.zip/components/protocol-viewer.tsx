'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import type { Protocol, ProtocolStep, ResourceRequirement, CommunicationFlow } from '@/lib/protocols/types'
import type { PriorityLevel } from '@/lib/types'

interface ProtocolViewerProps {
  protocol: Protocol
  currentPriority: PriorityLevel
  onStepComplete?: (stepId: string) => void
  completedSteps?: string[]
}

function ResourceBadge({ resource }: { resource: ResourceRequirement }) {
  const priorityColors = {
    obligatorio: 'bg-destructive text-destructive-foreground',
    recomendado: 'bg-status-pending text-background',
    opcional: 'bg-secondary text-secondary-foreground',
  }
  
  return (
    <div className="flex items-center gap-2 rounded-lg bg-secondary/50 px-3 py-2">
      <span className="font-medium text-foreground capitalize">
        {resource.type.replace(/_/g, ' ')}
      </span>
      <Badge variant="outline" className="text-xs">
        x{resource.quantity}
      </Badge>
      <Badge className={`text-xs ${priorityColors[resource.priority]}`}>
        {resource.priority}
      </Badge>
      {resource.notes && (
        <span className="text-xs text-muted-foreground">({resource.notes})</span>
      )}
    </div>
  )
}

function StepCard({ 
  step, 
  isCompleted, 
  onComplete 
}: { 
  step: ProtocolStep
  isCompleted: boolean
  onComplete?: () => void
}) {
  const agencyColors: Record<string, string> = {
    bomberos: 'bg-destructive/20 text-destructive border-destructive/30',
    servicios_medicos: 'bg-primary/20 text-primary border-primary/30',
    policia: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
    proteccion_civil: 'bg-status-pending/20 text-status-pending border-status-pending/30',
    ayuntamiento: 'bg-secondary text-secondary-foreground border-border',
    compania_servicios: 'bg-muted text-muted-foreground border-border',
  }
  
  return (
    <div className={`rounded-lg border p-4 transition-all ${
      isCompleted 
        ? 'bg-primary/10 border-primary/30' 
        : step.isCritical 
          ? 'bg-destructive/5 border-destructive/20' 
          : 'bg-card border-border'
    }`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <span className="flex h-6 w-6 items-center justify-center rounded-full bg-secondary text-xs font-bold">
              {step.order}
            </span>
            <h4 className="font-semibold text-foreground">{step.action}</h4>
            {step.isCritical && (
              <Badge variant="destructive" className="text-xs">Critico</Badge>
            )}
            {step.timeLimit && (
              <Badge variant="outline" className="text-xs">{step.timeLimit}</Badge>
            )}
          </div>
          
          <p className="text-sm text-muted-foreground mb-3">{step.description}</p>
          
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <Badge className={agencyColors[step.responsible] || 'bg-secondary'}>
              {step.responsible.replace(/_/g, ' ')}
            </Badge>
          </div>
          
          {step.checkpoints && step.checkpoints.length > 0 && (
            <div className="mt-3 space-y-1">
              <span className="text-xs font-medium text-muted-foreground">Puntos de verificacion:</span>
              <ul className="list-inside list-disc text-sm text-foreground">
                {step.checkpoints.map((cp, idx) => (
                  <li key={idx}>{cp}</li>
                ))}
              </ul>
            </div>
          )}
          
          {step.warnings && step.warnings.length > 0 && (
            <div className="mt-3 rounded-md bg-status-pending/10 p-2 border border-status-pending/20">
              <span className="text-xs font-medium text-status-pending">Advertencias:</span>
              <ul className="list-inside list-disc text-sm text-status-pending">
                {step.warnings.map((w, idx) => (
                  <li key={idx}>{w}</li>
                ))}
              </ul>
            </div>
          )}
        </div>
        
        {onComplete && (
          <Button
            size="sm"
            variant={isCompleted ? 'secondary' : 'default'}
            onClick={onComplete}
            disabled={isCompleted}
          >
            {isCompleted ? 'Completado' : 'Marcar'}
          </Button>
        )}
      </div>
    </div>
  )
}

function CommunicationFlowCard({ flow }: { flow: CommunicationFlow }) {
  const channelIcons: Record<string, string> = {
    radio: 'Antena',
    telefono: 'Tel',
    presencial: 'Pers',
    digital: 'Dig',
  }
  
  return (
    <div className="flex items-center gap-3 rounded-lg bg-secondary/50 p-3">
      <div className="flex flex-col items-center">
        <Badge variant="outline" className="mb-1 capitalize">
          {flow.from.replace(/_/g, ' ')}
        </Badge>
        <svg className="h-4 w-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
        <Badge variant="outline" className="mt-1 capitalize">
          {flow.to.replace(/_/g, ' ')}
        </Badge>
      </div>
      <div className="flex-1">
        <div className="flex items-center gap-2 mb-1">
          <Badge className="bg-secondary text-xs">{channelIcons[flow.channel]}</Badge>
          <span className="text-xs text-muted-foreground">{flow.timing}</span>
        </div>
        <p className="text-sm text-foreground">{flow.message}</p>
      </div>
    </div>
  )
}

export function ProtocolViewer({ 
  protocol, 
  currentPriority,
  onStepComplete,
  completedSteps = []
}: ProtocolViewerProps) {
  const [activeTab, setActiveTab] = useState('overview')
  
  const resources = protocol.resourceRequirements.byPriority[currentPriority] || 
                    protocol.resourceRequirements.minimum
  
  return (
    <Card className="border-primary/20">
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              {protocol.name}
            </CardTitle>
            <p className="text-sm text-muted-foreground mt-1">{protocol.description}</p>
          </div>
          <Badge variant="outline" className="text-xs">v{protocol.version}</Badge>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-5 mb-4">
            <TabsTrigger value="overview">General</TabsTrigger>
            <TabsTrigger value="steps">Pasos</TabsTrigger>
            <TabsTrigger value="resources">Recursos</TabsTrigger>
            <TabsTrigger value="coordination">Coord.</TabsTrigger>
            <TabsTrigger value="safety">Seguridad</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div>
              <h4 className="font-medium text-foreground mb-2">Objetivos</h4>
              <ul className="list-inside list-disc text-sm text-muted-foreground space-y-1">
                {protocol.objectives.map((obj, idx) => (
                  <li key={idx}>{obj}</li>
                ))}
              </ul>
            </div>
            
            {protocol.legalReferences && (
              <div>
                <h4 className="font-medium text-foreground mb-2">Referencias Legales</h4>
                <ul className="list-inside list-disc text-sm text-muted-foreground space-y-1">
                  {protocol.legalReferences.map((ref, idx) => (
                    <li key={idx}>{ref}</li>
                  ))}
                </ul>
              </div>
            )}
            
            <div className="rounded-lg bg-secondary/30 p-3">
              <p className="text-xs text-muted-foreground">
                Ultima actualizacion: {protocol.lastUpdated}
              </p>
            </div>
          </TabsContent>
          
          <TabsContent value="steps" className="space-y-4">
            <Accordion type="single" collapsible defaultValue="assessment">
              <AccordionItem value="assessment">
                <AccordionTrigger>
                  <span className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">1</span>
                    Evaluacion Inicial
                  </span>
                </AccordionTrigger>
                <AccordionContent className="space-y-3 pt-2">
                  {protocol.initialAssessment.map((step) => (
                    <StepCard
                      key={step.id}
                      step={step}
                      isCompleted={completedSteps.includes(step.id)}
                      onComplete={onStepComplete ? () => onStepComplete(step.id) : undefined}
                    />
                  ))}
                </AccordionContent>
              </AccordionItem>
              
              <AccordionItem value="operations">
                <AccordionTrigger>
                  <span className="flex items-center gap-2">
                    <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">2</span>
                    Operaciones
                  </span>
                </AccordionTrigger>
                <AccordionContent className="space-y-3 pt-2">
                  {protocol.operationalSteps.map((step) => (
                    <StepCard
                      key={step.id}
                      step={step}
                      isCompleted={completedSteps.includes(step.id)}
                      onComplete={onStepComplete ? () => onStepComplete(step.id) : undefined}
                    />
                  ))}
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </TabsContent>
          
          <TabsContent value="resources" className="space-y-4">
            <div>
              <h4 className="font-medium text-foreground mb-3">
                Recursos para prioridad {currentPriority.toUpperCase()}
              </h4>
              <div className="flex flex-wrap gap-2">
                {resources.map((resource, idx) => (
                  <ResourceBadge key={idx} resource={resource} />
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-foreground mb-3">Recursos Minimos</h4>
              <div className="flex flex-wrap gap-2">
                {protocol.resourceRequirements.minimum.map((resource, idx) => (
                  <ResourceBadge key={idx} resource={resource} />
                ))}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="coordination" className="space-y-4">
            <div>
              <h4 className="font-medium text-foreground mb-3">Flujos de Comunicacion</h4>
              <div className="space-y-3">
                {protocol.coordinationFlows.map((flow, idx) => (
                  <CommunicationFlowCard key={idx} flow={flow} />
                ))}
              </div>
            </div>
            
            <div>
              <h4 className="font-medium text-foreground mb-3">Criterios de Escalada</h4>
              <div className="space-y-2">
                {protocol.escalationCriteria.map((criteria, idx) => (
                  <div key={idx} className="rounded-lg bg-destructive/10 border border-destructive/20 p-3">
                    <p className="font-medium text-destructive text-sm mb-2">
                      {criteria.condition}
                    </p>
                    <div className="flex flex-wrap gap-2 text-xs">
                      <Badge variant="destructive">
                        Escalar a: {criteria.newPriority.toUpperCase()}
                      </Badge>
                      {criteria.notifyAgencies.map((agency, i) => (
                        <Badge key={i} variant="outline" className="capitalize">
                          Notificar: {agency.replace(/_/g, ' ')}
                        </Badge>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="safety" className="space-y-4">
            <div>
              <h4 className="font-medium text-foreground mb-3">Consideraciones de Seguridad</h4>
              <div className="space-y-2">
                {protocol.safetyConsiderations.map((consideration, idx) => (
                  <div key={idx} className="flex items-start gap-2 rounded-lg bg-status-pending/10 border border-status-pending/20 p-3">
                    <svg className="h-5 w-5 text-status-pending shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <span className="text-sm text-foreground">{consideration}</span>
                  </div>
                ))}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
