'use client'

import React from "react"

import { useState, useCallback, useRef } from 'react'
import useSWR, { mutate } from 'swr'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import type { 
  Regulation, 
  ExtractedRule,
  RuleCategory 
} from '@/lib/rules/types'

const fetcher = (url: string) => fetch(url).then(res => res.json())

interface RegulationsPanelProps {
  incidentType?: string
}

export function RegulationsPanel({ incidentType }: RegulationsPanelProps) {
  const { data: regulations, isLoading } = useSWR<Regulation[]>(
    '/api/regulations',
    fetcher,
    { refreshInterval: 30000 }
  )
  
  const [isAddingRegulation, setIsAddingRegulation] = useState(false)
  const [isExtracting, setIsExtracting] = useState(false)
  const [newRegulation, setNewRegulation] = useState({
    title: '',
    description: '',
    category: 'procedimiento' as RuleCategory,
    sourceDocument: '',
    content: ''
  })
  const [extractedRules, setExtractedRules] = useState<ExtractedRule[]>([])
  const [expandedRegulation, setExpandedRegulation] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleAddRegulation = useCallback(async () => {
    if (!newRegulation.title || !newRegulation.content) return
    
    try {
      const response = await fetch('/api/regulations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRegulation)
      })
      
      if (response.ok) {
        mutate('/api/regulations')
        setNewRegulation({
          title: '',
          description: '',
          category: 'procedimiento',
          sourceDocument: '',
          content: ''
        })
        setIsAddingRegulation(false)
      }
    } catch (error) {
      console.error('Error adding regulation:', error)
    }
  }, [newRegulation])

  const handleExtractRules = useCallback(async () => {
    if (!newRegulation.content) return
    
    setIsExtracting(true)
    try {
      const response = await fetch('/api/regulations/extract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: newRegulation.content })
      })
      
      if (response.ok) {
        const data = await response.json()
        setExtractedRules(data.rules)
      }
    } catch (error) {
      console.error('Error extracting rules:', error)
    } finally {
      setIsExtracting(false)
    }
  }, [newRegulation.content])

  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (!file) return
    
    const reader = new FileReader()
    reader.onload = (e) => {
      const content = e.target?.result as string
      setNewRegulation(prev => ({
        ...prev,
        content,
        sourceDocument: file.name
      }))
    }
    reader.readAsText(file)
  }, [])

  const filteredRegulations = regulations || []

  const getCategoryLabel = (category: RuleCategory) => {
    const labels: Record<RuleCategory, string> = {
      ley: 'Ley',
      protocolo: 'Protocolo',
      procedimiento: 'Procedimiento',
      directriz: 'Directriz',
      normativa_local: 'Normativa Local'
    }
    return labels[category] || category
  }

  const getCategoryColor = (category: RuleCategory) => {
    const colors: Record<RuleCategory, string> = {
      ley: 'bg-red-500/20 text-red-300',
      protocolo: 'bg-blue-500/20 text-blue-300',
      procedimiento: 'bg-green-500/20 text-green-300',
      directriz: 'bg-yellow-500/20 text-yellow-300',
      normativa_local: 'bg-purple-500/20 text-purple-300'
    }
    return colors[category] || 'bg-gray-500/20 text-gray-300'
  }

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-base">
            <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Normativa Aplicable
          </CardTitle>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsAddingRegulation(!isAddingRegulation)}
          >
            {isAddingRegulation ? 'Cancelar' : 'Cargar Normativa'}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="pt-0">
        {/* Add Regulation Form */}
        {isAddingRegulation && (
          <div className="mb-6 space-y-4 rounded-lg border border-border bg-secondary/30 p-4">
            <h4 className="font-medium text-foreground">Cargar Nuevo Reglamento</h4>
            
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Titulo</label>
                <Input
                  value={newRegulation.title}
                  onChange={(e) => setNewRegulation(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="Ej: Protocolo de Evacuacion"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">Categoria</label>
                <Select 
                  value={newRegulation.category}
                  onValueChange={(value) => setNewRegulation(prev => ({ ...prev, category: value as RuleCategory }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="legal">Legal</SelectItem>
                    <SelectItem value="procedimiento">Procedimiento</SelectItem>
                    <SelectItem value="seguridad">Seguridad</SelectItem>
                    <SelectItem value="comunicacion">Comunicacion</SelectItem>
                    <SelectItem value="recursos">Recursos</SelectItem>
                    <SelectItem value="coordinacion">Coordinacion</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Descripcion</label>
              <Input
                value={newRegulation.description}
                onChange={(e) => setNewRegulation(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Breve descripcion del reglamento"
              />
            </div>
            
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-foreground">Contenido del Documento</label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                >
                  Subir Archivo
                </Button>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".txt,.md,.pdf"
                  className="hidden"
                  onChange={handleFileUpload}
                />
              </div>
              <Textarea
                value={newRegulation.content}
                onChange={(e) => setNewRegulation(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Pegue aqui el contenido del reglamento o suba un archivo..."
                rows={8}
              />
              {newRegulation.sourceDocument && (
                <p className="text-xs text-muted-foreground">
                  Archivo cargado: {newRegulation.sourceDocument}
                </p>
              )}
            </div>
            
            {/* Extract Rules Button */}
            {newRegulation.content && (
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  onClick={handleExtractRules}
                  disabled={isExtracting}
                >
                  {isExtracting ? 'Extrayendo...' : 'Extraer Reglas Automaticamente'}
                </Button>
              </div>
            )}
            
            {/* Extracted Rules Preview */}
            {extractedRules.length > 0 && (
              <div className="space-y-2 rounded-lg border border-primary/30 bg-primary/5 p-3">
                <h5 className="text-sm font-medium text-foreground">
                  Reglas Extraidas ({extractedRules.length})
                </h5>
                <div className="max-h-48 space-y-2 overflow-y-auto">
                  {extractedRules.map((rule, idx) => (
                    <div key={idx} className="rounded bg-background p-2 text-sm">
                      <div className="flex items-center gap-2">
                        <span className={`rounded px-2 py-0.5 text-xs ${getCategoryColor(rule.category)}`}>
                          {getCategoryLabel(rule.category)}
                        </span>
                        <span className="font-medium">{rule.condition}</span>
                      </div>
                      <p className="mt-1 text-muted-foreground">{rule.action}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
            
            <div className="flex gap-2">
              <Button onClick={handleAddRegulation} disabled={!newRegulation.title || !newRegulation.content}>
                Guardar Reglamento
              </Button>
              <Button variant="outline" onClick={() => setIsAddingRegulation(false)}>
                Cancelar
              </Button>
            </div>
          </div>
        )}
        
        {/* Regulations List */}
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          </div>
        ) : filteredRegulations && filteredRegulations.length > 0 ? (
          <div className="space-y-3">
            {filteredRegulations.map((regulation) => (
              <div 
                key={regulation.id}
                className="rounded-lg border border-border bg-secondary/30 p-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className={`rounded px-2 py-0.5 text-xs ${getCategoryColor(regulation.category)}`}>
                        {getCategoryLabel(regulation.category)}
                      </span>
                      <h4 className="font-medium text-foreground">{regulation.title}</h4>
                    </div>
                    {regulation.description && (
                      <p className="mt-1 text-sm text-muted-foreground">{regulation.description}</p>
                    )}
                    <div className="mt-2 flex flex-wrap gap-2 text-xs text-muted-foreground">
                      {regulation.sourceDocument && (
                        <span>Fuente: {regulation.sourceDocument}</span>
                      )}
                      <span>{regulation.extractedRules?.length || 0} reglas extraidas</span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setExpandedRegulation(
                      expandedRegulation === regulation.id ? null : regulation.id
                    )}
                  >
                    {expandedRegulation === regulation.id ? 'Ocultar' : 'Ver Reglas'}
                  </Button>
                </div>
                
                {/* Expanded Rules */}
                {expandedRegulation === regulation.id && regulation.extractedRules && (
                  <div className="mt-3 space-y-2 border-t border-border pt-3">
                    <h5 className="text-sm font-medium text-foreground">Reglas Activas</h5>
                    {regulation.extractedRules.map((rule, idx) => (
                      <div key={idx} className="rounded bg-background p-2 text-sm">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className={`rounded px-2 py-0.5 text-xs ${getCategoryColor(rule.category)}`}>
                              {getCategoryLabel(rule.category)}
                            </span>
                            <span className="text-xs text-muted-foreground">
                              Prioridad: {rule.priority}
                            </span>
                          </div>
                          <span className={`text-xs ${rule.isActive ? 'text-green-400' : 'text-red-400'}`}>
                            {rule.isActive ? 'Activa' : 'Inactiva'}
                          </span>
                        </div>
                        <p className="mt-1 font-medium text-foreground">
                          SI: {rule.condition}
                        </p>
                        <p className="text-muted-foreground">
                          ENTONCES: {rule.action}
                        </p>
                        {rule.exceptions && rule.exceptions.length > 0 && (
                          <p className="mt-1 text-xs text-yellow-400">
                            Excepciones: {rule.exceptions.join(', ')}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="py-8 text-center text-muted-foreground">
            <svg className="mx-auto h-12 w-12 text-muted-foreground/50" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <p className="mt-2">No hay normativa cargada</p>
            <p className="text-sm">Cargue reglamentos para que el sistema genere reglas automaticamente</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
