'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { SpeechRecognition, SpeechRecognitionEvent, SpeechRecognitionErrorEvent } from 'web-speech-api'

interface VoiceRecorderProps {
  onTranscript: (text: string) => void
  disabled?: boolean
}

/**
 * Voice Recorder Component
 * 
 * Uses the Web Speech API to record and transcribe speech to text.
 * Supports Spanish language recognition for emergency reports.
 */
export function VoiceRecorder({ onTranscript, disabled = false }: VoiceRecorderProps) {
  const [isRecording, setIsRecording] = useState(false)
  const [isSupported, setIsSupported] = useState(true)
  const [transcript, setTranscript] = useState('')
  const [interimTranscript, setInterimTranscript] = useState('')
  const [error, setError] = useState<string | null>(null)
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  
  // Check for Web Speech API support
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      if (!SpeechRecognition) {
        setIsSupported(false)
        setError('Tu navegador no soporta reconocimiento de voz. Usa Chrome o Edge.')
      }
    }
  }, [])
  
  const startRecording = useCallback(() => {
    if (!isSupported || disabled) return
    
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    const recognition = new SpeechRecognition()
    
    recognition.lang = 'es-ES'
    recognition.continuous = true
    recognition.interimResults = true
    recognition.maxAlternatives = 1
    
    recognition.onstart = () => {
      setIsRecording(true)
      setError(null)
      setTranscript('')
      setInterimTranscript('')
    }
    
    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let finalTranscript = ''
      let interimText = ''
      
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i]
        if (result.isFinal) {
          finalTranscript += result[0].transcript + ' '
        } else {
          interimText += result[0].transcript
        }
      }
      
      if (finalTranscript) {
        setTranscript((prev) => prev + finalTranscript)
      }
      setInterimTranscript(interimText)
    }
    
    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      if (event.error === 'not-allowed') {
        setError('Permiso de microfono denegado. Por favor, permite el acceso al microfono.')
      } else if (event.error === 'no-speech') {
        setError('No se detecto voz. Intenta de nuevo.')
      } else {
        setError(`Error de reconocimiento: ${event.error}`)
      }
      setIsRecording(false)
    }
    
    recognition.onend = () => {
      setIsRecording(false)
    }
    
    recognitionRef.current = recognition
    recognition.start()
  }, [isSupported, disabled])
  
  const stopRecording = useCallback(() => {
    if (recognitionRef.current) {
      recognitionRef.current.stop()
      setIsRecording(false)
    }
  }, [])
  
  const clearTranscript = useCallback(() => {
    setTranscript('')
    setInterimTranscript('')
    setError(null)
  }, [])
  
  // Send final transcript to parent only once when recording stops
  const sendTranscriptToParent = useCallback(() => {
    const finalText = (transcript + interimTranscript).trim()
    if (finalText) {
      onTranscript(finalText)
      // Clear after sending
      setTranscript('')
      setInterimTranscript('')
    }
  }, [transcript, interimTranscript, onTranscript])
  
  if (!isSupported) {
    return (
      <Card className="border-destructive/50 bg-destructive/5">
        <CardContent className="pt-4">
          <div className="flex items-center gap-3 text-sm text-destructive">
            <svg className="h-5 w-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
            <span>{error}</span>
          </div>
        </CardContent>
      </Card>
    )
  }
  
  const displayText = transcript + interimTranscript
  
  return (
    <Card className="border-primary/30">
      <CardContent className="pt-4">
        <div className="space-y-4">
          {/* Recording Controls */}
          <div className="flex items-center gap-3">
            <Button
              type="button"
              variant={isRecording ? 'destructive' : 'default'}
              onClick={isRecording ? stopRecording : startRecording}
              disabled={disabled}
              className="min-w-[160px] gap-2"
              aria-label={isRecording ? 'Detener grabacion' : 'Iniciar grabacion de voz'}
            >
              {isRecording ? (
                <>
                  <span className="relative flex h-3 w-3">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-destructive-foreground opacity-75" />
                    <span className="relative inline-flex h-3 w-3 rounded-full bg-destructive-foreground" />
                  </span>
                  Detener Grabacion
                </>
              ) : (
                <>
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                  </svg>
                  Grabar Voz
                </>
              )}
            </Button>
            
            {displayText && !isRecording && (
              <Button
                type="button"
                variant="default"
                size="sm"
                onClick={sendTranscriptToParent}
                disabled={disabled}
                aria-label="Usar transcripcion"
              >
                Usar Texto
              </Button>
            )}
            
            {displayText && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={clearTranscript}
                disabled={isRecording || disabled}
                aria-label="Limpiar transcripcion"
              >
                Limpiar
              </Button>
            )}
            
            {isRecording && (
              <span className="text-sm text-muted-foreground animate-pulse">
                Escuchando...
              </span>
            )}
          </div>
          
          {/* Error Display */}
          {error && (
            <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
              {error}
            </div>
          )}
          
          {/* Transcript Display */}
          {displayText && (
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Transcripcion:
              </label>
              <div 
                className="rounded-md border border-border bg-secondary/50 p-3 text-sm text-foreground min-h-[80px]"
                role="region"
                aria-live="polite"
                aria-label="Texto transcrito"
              >
                <span>{transcript}</span>
                {interimTranscript && (
                  <span className="text-muted-foreground italic">{interimTranscript}</span>
                )}
              </div>
              <p className="text-xs text-muted-foreground">
                Pulsa "Usar Texto" para copiar la transcripcion al campo del aviso.
              </p>
            </div>
          )}
          
          {/* Instructions */}
          {!displayText && !isRecording && (
            <p className="text-xs text-muted-foreground">
              Pulsa el boton para dictar el aviso de emergencia. El sistema transcribira tu voz automaticamente en espanol.
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

// Type declarations for Web Speech API
declare global {
  interface Window {
    SpeechRecognition: typeof SpeechRecognition
    webkitSpeechRecognition: typeof SpeechRecognition
  }
}
