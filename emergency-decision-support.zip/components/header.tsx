'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils'

/**
 * Application Header
 * 
 * Provides navigation between the main screens:
 * - Input: Enter new emergency reports
 * - Queue: View and manage incident queue
 * - Metrics: View system statistics
 */
export function Header() {
  const pathname = usePathname()
  
  const navItems = [
    { href: '/', label: 'Entrada' },
    { href: '/queue', label: 'Cola' },
    { href: '/resources', label: 'Recursos' },
    { href: '/coordination', label: 'Coordinacion' },
    { href: '/regulations', label: 'Normativa' },
    { href: '/metrics', label: 'Metricas' },
  ]
  
  return (
    <header className="border-b border-border bg-card">
      <div className="mx-auto max-w-7xl px-4 py-4">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
          {/* Logo / Title */}
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary">
              <svg
                className="h-6 w-6 text-primary-foreground"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 10V3L4 14h7v7l9-11h-7z"
                />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground">
                Sistema de Apoyo a la Decision
              </h1>
              <p className="text-xs text-muted-foreground">
                Puesto de Mando de Emergencias
              </p>
            </div>
          </div>
          
          {/* Navigation */}
          <nav className="flex gap-1">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  'rounded-md px-4 py-2 text-sm font-medium transition-colors',
                  pathname === item.href
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:bg-secondary hover:text-foreground'
                )}
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </div>
      </div>
    </header>
  )
}
