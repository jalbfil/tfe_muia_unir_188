'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CoordinationStore } from '@/lib/coordination/coordination-store'
import type { 
  IncidentCoordination, 
  CoordinationMessage,
  AgencyContact,
  CoordinationLogEntry 
} from '@/lib/coordination/types'
import type { AgencyType } from '@/lib/protocols/types'

interface CoordinationPanelProps {
  incidentId?: string
  leadAgency?: AgencyType
  compact?: boolean
}

const agencyColors: Record<AgencyType, string> = {
  bomberos: 'bg-destructive/20 text-destructive border-destructive/30',
  servicios_medicos: 'bg-primary/20 text-primary border-primary/30',
  policia: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  proteccion_civil: 'bg-status-pending/20 text-status-pending border-status-pending/30',
  ayuntamiento: 'bg-secondary text-secondary-foreground border-border',
  compania_servicios: 'bg-muted text-muted-foreground border-border',
}

const agencyLabels: Record<AgencyType, string> = {
  bomberos: 'Bomberos',
  servicios_medicos: 'Servicios Medicos',
  policia: 'Policia',
  proteccion_civil: 'Proteccion Civil',
  ayuntamiento: 'Ayuntamiento',
  compania_servicios: 'Compania Servicios',
}

const statusColors = {
  notificada: 'bg-secondary text-secondary-foreground',
  en_camino: 'bg-status-pending text-background',
  en_escena: 'bg-blue-500 text-white',
  operando: 'bg-primary text-primary-foreground',
  finalizada: 'bg-muted text-muted-foreground',
}

const statusLabels = {
  notificada: 'Notificada',
  en_camino: 'En Camino',
  en_escena: 'En Escena',
  operando: 'Operando',
  finalizada: 'Finalizada',
}

function AgencyContactCard({ contact }: { contact: AgencyContact }) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border bg-card p-3">
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg border ${agencyColors[contact.agency]}`}>
        <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
        </svg>
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-medium text-foreground">{contact.name}</span>
          {contact.available && (
            <span className="h-2 w-2 rounded-full bg-status-confirmed" />
          )}
        </div>
        <p className="text-sm text-muted-foreground">{contact.role}</p>
        <div className="flex flex-wrap items-center gap-2 mt-1 text-xs text-muted-foreground">
          {contact.radioChannel && (
            <span>{contact.radioChannel}</span>
          )}
          <span>{contact.phoneNumber}</span>
        </div>
      </div>
      <Button size="sm" variant="outline" className="bg-transparent">
        Contactar
      </Button>
    </div>
  )
}

function MessageCard({ message }: { message: CoordinationMessage }) {
  const priorityColors = {
    urgente: 'bg-destructive text-destructive-foreground',
    normal: 'bg-secondary text-secondary-foreground',
    informativo: 'bg-muted text-muted-foreground',
  }
  
  return (
    <div className={`rounded-lg border p-3 ${
      message.priority === 'urgente' ? 'border-destructive/30 bg-destructive/5' : 'border-border bg-card'
    }`}>
      <div className="flex items-start justify-between gap-2 mb-2">
        <div className="flex items-center gap-2">
          <Badge className={agencyColors[message.fromAgency]}>
            {agencyLabels[message.fromAgency]}
          </Badge>
          <svg className="h-4 w-4 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
          </svg>
          <Badge variant="outline">
            {message.toAgency === 'all' ? 'Todos' : agencyLabels[message.toAgency as AgencyType]}
          </Badge>
        </div>
        <Badge className={priorityColors[message.priority]}>
          {message.priority}
        </Badge>
      </div>
      <h4 className="font-medium text-foreground mb-1">{message.subject}</h4>
      <p className="text-sm text-muted-foreground">{message.content}</p>
      <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
        <span>{new Date(message.timestamp).toLocaleTimeString('es-ES')}</span>
        {message.acknowledgedAt ? (
          <span className="text-status-confirmed">Recibido</span>
        ) : (
          <span className="text-status-pending">Pendiente</span>
        )}
      </div>
    </div>
  )
}

function LogEntry({ entry }: { entry: CoordinationLogEntry }) {
  return (
    <div className="flex gap-3 pb-3 border-b border-border last:border-0">
      <div className="flex flex-col items-center">
        <div className="h-2 w-2 rounded-full bg-primary mt-2" />
        <div className="flex-1 w-px bg-border mt-1" />
      </div>
      <div className="flex-1 pb-2">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs text-muted-foreground">
            {new Date(entry.timestamp).toLocaleTimeString('es-ES')}
          </span>
          <Badge className={agencyColors[entry.agency]} variant="outline">
            {agencyLabels[entry.agency]}
          </Badge>
        </div>
        <p className="text-sm font-medium text-foreground">{entry.action}</p>
        <p className="text-sm text-muted-foreground">{entry.details}</p>
      </div>
    </div>
  )
}

export function CoordinationPanel({ incidentId, leadAgency = 'bomberos', compact = false }: CoordinationPanelProps) {
  const [activeTab, setActiveTab] = useState('agencies')
  const [coordination, setCoordination] = useState<IncidentCoordination | null>(() => {
    if (!incidentId) return null
    // Initialize or get existing coordination
    let coord = CoordinationStore.getIncidentCoordination(incidentId)
    if (!coord) {
      coord = CoordinationStore.initializeIncidentCoordination(incidentId, leadAgency)
    }
    return coord
  })
  
  // Message form state
  const [messageForm, setMessageForm] = useState({
    toAgency: '' as AgencyType | 'all' | '',
    subject: '',
    content: '',
    priority: 'normal' as 'urgente' | 'normal' | 'informativo',
  })
  
  const contacts = CoordinationStore.getAgencyContacts()
  const log = incidentId ? CoordinationStore.getCoordinationLog(incidentId) : []
  
  function handleAddAgency(agency: AgencyType) {
    if (!incidentId) return
    const updated = CoordinationStore.addAgencyToIncident(incidentId, agency)
    if (updated) {
      setCoordination({ ...updated })
    }
  }
  
  function handleSendMessage() {
    if (!incidentId) return
    if (!messageForm.toAgency || !messageForm.subject || !messageForm.content) {
      alert('Complete todos los campos del mensaje')
      return
    }
    
    const message = CoordinationStore.sendMessage(incidentId, {
      incidentId,
      fromAgency: leadAgency,
      toAgency: messageForm.toAgency as AgencyType | 'all',
      channel: 'digital',
      priority: messageForm.priority,
      subject: messageForm.subject,
      content: messageForm.content,
    })
    
    if (message) {
      const updated = CoordinationStore.getIncidentCoordination(incidentId)
      if (updated) {
        setCoordination({ ...updated })
      }
      setMessageForm({
        toAgency: '',
        subject: '',
        content: '',
        priority: 'normal',
      })
    }
  }
  
  const involvedAgencies = coordination?.involvedAgencies || []
  const messages = coordination?.messages || []
  
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
          </svg>
          Coordinacion Multi-Agencia
        </CardTitle>
        {coordination?.commandPost && (
          <p className="text-sm text-muted-foreground">
            Puesto de Mando: {coordination.commandPost.location} | {coordination.commandPost.frequency}
          </p>
        )}
      </CardHeader>
      
      <CardContent className="pt-0">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4 mb-4">
            <TabsTrigger value="agencies">Agencias</TabsTrigger>
            <TabsTrigger value="messages">
              Mensajes ({messages.length})
            </TabsTrigger>
            <TabsTrigger value="contacts">Contactos</TabsTrigger>
            <TabsTrigger value="log">Registro</TabsTrigger>
          </TabsList>
          
          <TabsContent value="agencies" className="space-y-4">
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-foreground">Agencias Involucradas</h4>
              {involvedAgencies.map((agencyStatus) => (
                <div 
                  key={agencyStatus.agency}
                  className="flex items-center justify-between rounded-lg border border-border bg-card p-3"
                >
                  <div className="flex items-center gap-3">
                    <Badge className={agencyColors[agencyStatus.agency]}>
                      {agencyLabels[agencyStatus.agency]}
                    </Badge>
                    {agencyStatus.agency === leadAgency && (
                      <Badge variant="outline" className="text-xs">Mando</Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={statusColors[agencyStatus.status]}>
                      {statusLabels[agencyStatus.status]}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {agencyStatus.unitsAssigned} unidades
                    </span>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="space-y-3">
              <h4 className="text-sm font-medium text-foreground">Agregar Agencia</h4>
              <div className="flex flex-wrap gap-2">
                {Object.keys(agencyLabels)
                  .filter(a => !involvedAgencies.some(ia => ia.agency === a))
                  .map((agency) => (
                    <Button
                      key={agency}
                      size="sm"
                      variant="outline"
                      className="bg-transparent"
                      onClick={() => handleAddAgency(agency as AgencyType)}
                    >
                      + {agencyLabels[agency as AgencyType]}
                    </Button>
                  ))
                }
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="messages" className="space-y-4">
            <div className="space-y-3 rounded-lg border border-border bg-secondary/30 p-4">
              <h4 className="text-sm font-medium text-foreground">Nuevo Mensaje</h4>
              <div className="grid gap-3 sm:grid-cols-2">
                <Select 
                  value={messageForm.toAgency}
                  onValueChange={(v) => setMessageForm(prev => ({ ...prev, toAgency: v as AgencyType | 'all' }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Destinatario" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas las agencias</SelectItem>
                    {involvedAgencies
                      .filter(a => a.agency !== leadAgency)
                      .map(a => (
                        <SelectItem key={a.agency} value={a.agency}>
                          {agencyLabels[a.agency]}
                        </SelectItem>
                      ))
                    }
                  </SelectContent>
                </Select>
                
                <Select 
                  value={messageForm.priority}
                  onValueChange={(v) => setMessageForm(prev => ({ ...prev, priority: v as 'urgente' | 'normal' | 'informativo' }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Prioridad" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="urgente">Urgente</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="informativo">Informativo</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Input
                placeholder="Asunto"
                value={messageForm.subject}
                onChange={(e) => setMessageForm(prev => ({ ...prev, subject: e.target.value }))}
              />
              
              <Textarea
                placeholder="Mensaje"
                rows={2}
                value={messageForm.content}
                onChange={(e) => setMessageForm(prev => ({ ...prev, content: e.target.value }))}
              />
              
              <Button onClick={handleSendMessage}>
                Enviar Mensaje
              </Button>
            </div>
            
            <div className="space-y-3">
              {messages.length === 0 ? (
                <p className="text-center text-sm text-muted-foreground py-4">
                  No hay mensajes en este incidente
                </p>
              ) : (
                [...messages].reverse().map((message) => (
                  <MessageCard key={message.id} message={message} />
                ))
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="contacts" className="space-y-3">
            {contacts.map((contact) => (
              <AgencyContactCard key={contact.agency} contact={contact} />
            ))}
          </TabsContent>
          
          <TabsContent value="log" className="space-y-1 max-h-96 overflow-y-auto">
            {log.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-4">
                No hay entradas en el registro
              </p>
            ) : (
              log.map((entry) => (
                <LogEntry key={entry.id} entry={entry} />
              ))
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
