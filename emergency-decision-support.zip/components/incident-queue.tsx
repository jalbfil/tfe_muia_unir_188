'use client'

import useSWR from 'swr'
import { IncidentCard } from '@/components/incident-card'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import type { Incident } from '@/lib/types'
import Link from 'next/link'

const fetcher = (url: string) => fetch(url).then((res) => res.json())

/**
 * Incident Queue Component
 * 
 * Displays the list of all incidents, sorted by priority and status.
 * Auto-refreshes every 5 seconds to show new incidents.
 */
export function IncidentQueue() {
  const { data, error, isLoading, mutate } = useSWR('/api/incidents', fetcher, {
    refreshInterval: 5000, // Auto-refresh every 5 seconds
  })
  
  if (isLoading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-4">
              <div className="space-y-3">
                <div className="flex gap-2">
                  <div className="h-5 w-16 rounded bg-muted" />
                  <div className="h-5 w-20 rounded bg-muted" />
                </div>
                <div className="h-5 w-32 rounded bg-muted" />
                <div className="h-4 w-full rounded bg-muted" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }
  
  if (error) {
    return (
      <Card className="border-destructive">
        <CardContent className="p-6 text-center">
          <p className="text-destructive">Error al cargar los incidentes</p>
          <Button 
            variant="outline" 
            size="sm" 
            className="mt-4 bg-transparent"
            onClick={() => mutate()}
          >
            Reintentar
          </Button>
        </CardContent>
      </Card>
    )
  }
  
  const incidents: Incident[] = data?.data || []
  
  if (incidents.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-muted">
            <svg
              className="h-8 w-8 text-muted-foreground"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
              />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-foreground">
            No hay incidentes
          </h3>
          <p className="mt-1 text-muted-foreground">
            Introduce un nuevo aviso para comenzar a procesar incidentes.
          </p>
          <Link href="/">
            <Button className="mt-4">
              Nuevo Aviso
            </Button>
          </Link>
        </CardContent>
      </Card>
    )
  }
  
  const pendingCount = incidents.filter((i) => i.status === 'pendiente').length
  const confirmedCount = incidents.filter((i) => i.status === 'confirmado').length
  
  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid gap-4 sm:grid-cols-3">
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-foreground">{incidents.length}</div>
            <div className="text-sm text-muted-foreground">Total Incidentes</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-status-pending">{pendingCount}</div>
            <div className="text-sm text-muted-foreground">Pendientes</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-2xl font-bold text-status-confirmed">{confirmedCount}</div>
            <div className="text-sm text-muted-foreground">Confirmados</div>
          </CardContent>
        </Card>
      </div>
      
      {/* Incident List */}
      <div className="space-y-3">
        {incidents.map((incident) => (
          <IncidentCard key={incident.id} incident={incident} />
        ))}
      </div>
      
      {/* Refresh indicator */}
      <p className="text-center text-xs text-muted-foreground">
        Actualizacion automatica cada 5 segundos
      </p>
    </div>
  )
}
