'use client'

import { useState, useEffect } from 'react'
import useSWR from 'swr' // Import useSWR
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { TimelineStore } from '@/lib/timeline/timeline-store'
import type { TimelineEvent, IncidentEvolution, EscalationRisk } from '@/lib/timeline/types'
import type { Incident } from '@/lib/types'

interface IncidentTimelineProps {
  incidentId: string
}

const categoryIcons: Record<string, string> = {
  alerta: 'M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9',
  clasificacion: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2',
  decision: 'M9 12l2 2 4-4m6 0v1a3 3 0 11-6 0v-1m6 0H9',
  despacho: 'M17 8l4 4m0 0l-4 4m4-4H3',
  llegada: 'M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z',
  operacion: 'M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c-.94 1.543.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z',
  escalada: 'M13 7h8m0 0v8m0-8l-8 8-4-4-6 6',
  coordinacion: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z',
  actualizacion: 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15',
  cierre: 'M5 13l4 4L19 7',
}

const categoryColors: Record<string, string> = {
  alerta: 'bg-destructive/20 text-destructive border-destructive/30',
  clasificacion: 'bg-primary/20 text-primary border-primary/30',
  decision: 'bg-status-confirmed/20 text-status-confirmed border-status-confirmed/30',
  despacho: 'bg-status-pending/20 text-status-pending border-status-pending/30',
  llegada: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  operacion: 'bg-primary/20 text-primary border-primary/30',
  escalada: 'bg-destructive/20 text-destructive border-destructive/30',
  coordinacion: 'bg-secondary text-secondary-foreground border-border',
  actualizacion: 'bg-muted text-muted-foreground border-border',
  cierre: 'bg-status-confirmed/20 text-status-confirmed border-status-confirmed/30',
}

const riskLevelColors: Record<EscalationRisk['level'], string> = {
  bajo: 'bg-status-confirmed text-background',
  medio: 'bg-status-pending text-background',
  alto: 'bg-destructive text-destructive-foreground',
  critico: 'bg-destructive text-destructive-foreground animate-pulse',
}

function TimelineEventCard({ event }: { event: TimelineEvent }) {
  const iconPath = categoryIcons[event.category] || categoryIcons.actualizacion
  const colorClass = categoryColors[event.category] || categoryColors.actualizacion
  
  return (
    <div className="flex gap-3">
      <div className="flex flex-col items-center">
        <div className={`flex h-8 w-8 items-center justify-center rounded-full border ${colorClass}`}>
          <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={iconPath} />
          </svg>
        </div>
        <div className="flex-1 w-px bg-border mt-2" />
      </div>
      
      <div className="flex-1 pb-6">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs text-muted-foreground">
            {new Date(event.timestamp).toLocaleTimeString('es-ES', { 
              hour: '2-digit', 
              minute: '2-digit',
              second: '2-digit'
            })}
          </span>
          {event.isAutomatic && (
            <Badge variant="outline" className="text-xs">Auto</Badge>
          )}
          {event.agency && (
            <Badge variant="outline" className="text-xs capitalize">
              {event.agency.replace(/_/g, ' ')}
            </Badge>
          )}
        </div>
        <h4 className="font-medium text-foreground">{event.title}</h4>
        <p className="text-sm text-muted-foreground">{event.description}</p>
        {event.operator && (
          <p className="text-xs text-muted-foreground mt-1">
            Operador: {event.operator}
          </p>
        )}
      </div>
    </div>
  )
}

function EscalationRiskCard({ risk }: { risk: EscalationRisk }) {
  return (
    <Card className={`border ${
      risk.level === 'critico' ? 'border-destructive bg-destructive/5' :
      risk.level === 'alto' ? 'border-destructive/50 bg-destructive/5' :
      'border-border'
    }`}>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">Riesgo de Escalada</CardTitle>
          <Badge className={riskLevelColors[risk.level]}>
            {risk.level.toUpperCase()}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        <div>
          <div className="flex items-center justify-between text-sm mb-1">
            <span className="text-muted-foreground">Probabilidad</span>
            <span className="font-medium">{risk.probability}%</span>
          </div>
          <Progress 
            value={risk.probability} 
            className={`h-2 ${risk.probability > 60 ? '[&>div]:bg-destructive' : ''}`}
          />
        </div>
        
        <div>
          <span className="text-xs font-medium text-foreground">Factores de riesgo:</span>
          <ul className="list-inside list-disc text-xs text-muted-foreground mt-1">
            {risk.factors.map((factor, idx) => (
              <li key={idx}>{factor}</li>
            ))}
          </ul>
        </div>
        
        <div>
          <span className="text-xs font-medium text-foreground">Recomendaciones:</span>
          <ul className="list-inside list-disc text-xs text-muted-foreground mt-1">
            {risk.recommendations.map((rec, idx) => (
              <li key={idx}>{rec}</li>
            ))}
          </ul>
        </div>
        
        <p className="text-xs text-muted-foreground">
          Horizonte temporal: {risk.timeframe}
        </p>
      </CardContent>
    </Card>
  )
}

function EvolutionMetrics({ evolution }: { evolution: IncidentEvolution }) {
  const formatTime = (minutes: number | null) => {
    if (minutes === null) return '--'
    if (minutes < 60) return `${minutes} min`
    const hours = Math.floor(minutes / 60)
    const mins = minutes % 60
    return `${hours}h ${mins}m`
  }
  
  return (
    <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
      <div className="rounded-lg bg-secondary/50 p-3 text-center">
        <p className="text-xs text-muted-foreground">Duracion</p>
        <p className="text-lg font-bold text-foreground">
          {formatTime(evolution.durationMinutes)}
        </p>
      </div>
      <div className="rounded-lg bg-secondary/50 p-3 text-center">
        <p className="text-xs text-muted-foreground">Primera Respuesta</p>
        <p className="text-lg font-bold text-foreground">
          {formatTime(evolution.timeToFirstResponse)}
        </p>
      </div>
      <div className="rounded-lg bg-secondary/50 p-3 text-center">
        <p className="text-xs text-muted-foreground">Primera Llegada</p>
        <p className="text-lg font-bold text-foreground">
          {formatTime(evolution.timeToFirstArrival)}
        </p>
      </div>
      <div className="rounded-lg bg-secondary/50 p-3 text-center">
        <p className="text-xs text-muted-foreground">Control</p>
        <p className="text-lg font-bold text-foreground">
          {evolution.isControlled ? formatTime(evolution.timeToControl) : 'Activo'}
        </p>
      </div>
    </div>
  )
}

const fetcher = (url: string) => fetch(url).then((res) => res.json())

export function IncidentTimeline({ incidentId }: IncidentTimelineProps) {
  const { data } = useSWR<{ success: boolean; data: Incident }>(
    incidentId ? `/api/incidents/${incidentId}` : null,
    fetcher
  )
  
  const incident = data?.success ? data.data : null
  const [timeline, setTimeline] = useState<TimelineEvent[]>([])
  const [evolution, setEvolution] = useState<IncidentEvolution | null>(null)
  const [showAll, setShowAll] = useState(false)
  
  useEffect(() => {
    if (!incident) return
    
    // Initialize timeline if empty
    const existingTimeline = TimelineStore.getTimeline(incident.id)
    if (existingTimeline.length === 0) {
      TimelineStore.initializeIncidentTimeline(incident)
    }
    
    // Get timeline and evolution
    setTimeline(TimelineStore.getTimeline(incident.id))
    setEvolution(TimelineStore.calculateEvolution(incident))
    
    // Refresh every 30 seconds
    const interval = setInterval(() => {
      setTimeline(TimelineStore.getTimeline(incident.id))
      setEvolution(TimelineStore.calculateEvolution(incident))
    }, 30000)
    
    return () => clearInterval(interval)
  }, [incident])
  
  const displayedEvents = showAll ? timeline : timeline.slice(-5)
  
  return (
    <div className="space-y-4">
      {/* Evolution Metrics */}
      {evolution && <EvolutionMetrics evolution={evolution} />}
      
      {/* Escalation Risk */}
      {evolution && <EscalationRiskCard risk={evolution.escalationRisk} />}
      
      {/* Timeline */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-base">
              <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              Linea de Tiempo
            </CardTitle>
            <Badge variant="outline">{timeline.length} eventos</Badge>
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          {timeline.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground py-4">
              No hay eventos registrados
            </p>
          ) : (
            <>
              <div className="space-y-1">
                {[...displayedEvents].reverse().map((event) => (
                  <TimelineEventCard key={event.id} event={event} />
                ))}
              </div>
              
              {timeline.length > 5 && (
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-2 bg-transparent"
                  onClick={() => setShowAll(!showAll)}
                >
                  {showAll ? 'Mostrar menos' : `Ver todos (${timeline.length})`}
                </Button>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
