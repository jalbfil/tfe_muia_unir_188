'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import useSWR from 'swr'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { PriorityBadge } from '@/components/priority-badge'
import { StatusBadge } from '@/components/status-badge'
import { getIncidentTypeLabel, formatTTFD, getSuggestedDecision, getSuggestedResources, getActionLabel, getActionDescription } from '@/lib/nlp-engine'
import type { Incident } from '@/lib/types'
import { ProtocolViewer } from '@/components/protocol-viewer'
import { getProtocolForIncident } from '@/lib/protocols/protocol-database'

const fetcher = (url: string) => fetch(url).then((res) => res.json())

interface IncidentDetailProps {
  incidentId: string
}

/**
 * Incident Detail Component
 * 
 * Displays full details of an incident and allows the operator
 * to confirm the decision. This is the "human in the loop" interface.
 */
export function IncidentDetail({ incidentId }: IncidentDetailProps) {
  const router = useRouter()
  const [isConfirming, setIsConfirming] = useState(false)
  const [confirmationResult, setConfirmationResult] = useState<{
    ttfd: number
    message: string
  } | null>(null)
  const [selectedAction, setSelectedAction] = useState<string | null>(null)
  
  const { data, error, isLoading, mutate } = useSWR(
    `/api/incidents/${incidentId}`,
    fetcher
  )
  
  console.log('[v0] IncidentDetail data:', { data, error, isLoading, incidentId })
  
  async function handleConfirm() {
    setIsConfirming(true)
    
    try {
      const response = await fetch(`/api/incidents/${incidentId}/confirm`, {
        method: 'POST',
        body: JSON.stringify({ action: selectedAction }),
        headers: {
          'Content-Type': 'application/json'
        }
      })
      
      const result = await response.json()
      
      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Error al confirmar')
      }
      
      setConfirmationResult({
        ttfd: result.data.ttfd,
        message: result.message,
      })
      
      // Refresh data
      mutate()
    } catch (err) {
      console.error('[v0] Confirmation error:', err)
      alert(err instanceof Error ? err.message : 'Error al confirmar la decision')
    } finally {
      setIsConfirming(false)
      setSelectedAction(null)
    }
  }
  
  if (isLoading) {
    return (
      <Card className="animate-pulse">
        <CardHeader>
          <div className="h-6 w-48 rounded bg-muted" />
          <div className="h-4 w-32 rounded bg-muted" />
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="h-24 rounded bg-muted" />
            <div className="h-32 rounded bg-muted" />
          </div>
        </CardContent>
      </Card>
    )
  }
  
  if (error || !data?.success) {
    return (
      <Card className="border-destructive">
        <CardContent className="p-6 text-center">
          <p className="text-destructive">
            {data?.error || 'Error al cargar el incidente'}
          </p>
          <Button 
            variant="outline" 
            className="mt-4 bg-transparent"
            onClick={() => router.push('/queue')}
          >
            Volver a la Cola
          </Button>
        </CardContent>
      </Card>
    )
  }
  
  const incident: Incident = data.data
  
  return (
    <div className="space-y-6">
      {/* Confirmation Result Banner */}
      {confirmationResult && (
        <Card className="border-status-confirmed bg-status-confirmed/10">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-status-confirmed text-background">
                <svg className="h-6 w-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-status-confirmed">
                  Decision Confirmada
                </h3>
                <p className="text-foreground">
                  Time To First Decision (TTFD): <strong>{formatTTFD(confirmationResult.ttfd)}</strong>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
      
      {/* Header Card */}
      <Card>
        <CardHeader>
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <CardTitle className="flex items-center gap-3">
                {getIncidentTypeLabel(incident.incidentType)}
                <PriorityBadge priority={incident.priority} size="lg" />
              </CardTitle>
              <CardDescription className="mt-2">
                ID: {incident.id.substring(0, 8)}... | 
                Creado: {new Date(incident.createdAt).toLocaleString('es-ES')}
              </CardDescription>
            </div>
            <StatusBadge status={incident.status} />
          </div>
        </CardHeader>
      </Card>
      
      {/* Location Card */}
      {incident.location && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Ubicacion
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <p className="text-lg text-foreground">{incident.location}</p>
          </CardContent>
        </Card>
      )}
      
      {/* Raw Text Card */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            Texto Original del Aviso
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="rounded-lg bg-secondary p-4">
            <p className="whitespace-pre-wrap font-mono text-sm text-foreground">
              {incident.rawText}
            </p>
          </div>
        </CardContent>
      </Card>
      
      {/* Decision Sugerida Card */}
      <Card className="border-primary/50 bg-primary/5">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 01-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            Decision Sugerida por el Sistema
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-4">
            <div className="rounded-lg bg-background p-4 border border-border">
              <p className="font-semibold text-foreground mb-2">
                Clasificacion: {getIncidentTypeLabel(incident.incidentType)}
              </p>
              <p className="text-sm text-muted-foreground mb-3">
                {getSuggestedDecision(incident)}
              </p>
              <div className="flex flex-wrap gap-2">
                {getSuggestedResources(incident).map((resource, idx) => (
                  <span 
                    key={idx} 
                    className="inline-flex items-center gap-1 rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground"
                  >
                    {resource}
                  </span>
                ))}
              </div>
            </div>
            <p className="text-xs text-muted-foreground italic">
              Esta es una sugerencia automatica basada en el analisis NLP. El operador debe validar y puede modificar la decision.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Acciones del Operador */}
      {incident.status === 'pendiente' && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
              Acciones Disponibles
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <div className="grid gap-3 sm:grid-cols-2">
              <Button 
                variant="outline" 
                className="justify-start gap-2 h-auto py-3 px-4 bg-transparent"
                onClick={() => setSelectedAction('despachar')}
              >
                <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </svg>
                <div className="text-left">
                  <div className="font-medium">Despachar Recursos</div>
                  <div className="text-xs text-muted-foreground">Enviar unidades al lugar</div>
                </div>
              </Button>
              
              <Button 
                variant="outline" 
                className="justify-start gap-2 h-auto py-3 px-4 bg-transparent"
                onClick={() => setSelectedAction('escalar')}
              >
                <svg className="h-5 w-5 text-status-pending" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                </svg>
                <div className="text-left">
                  <div className="font-medium">Escalar Prioridad</div>
                  <div className="text-xs text-muted-foreground">Aumentar nivel de urgencia</div>
                </div>
              </Button>
              
              <Button 
                variant="outline" 
                className="justify-start gap-2 h-auto py-3 px-4 bg-transparent"
                onClick={() => setSelectedAction('reasignar')}
              >
                <svg className="h-5 w-5 text-muted-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" />
                </svg>
                <div className="text-left">
                  <div className="font-medium">Reasignar Tipo</div>
                  <div className="text-xs text-muted-foreground">Cambiar clasificacion</div>
                </div>
              </Button>
              
              <Button 
                variant="outline" 
                className="justify-start gap-2 h-auto py-3 px-4 bg-transparent"
                onClick={() => setSelectedAction('descartar')}
              >
                <svg className="h-5 w-5 text-destructive" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12m0 0l-4-4-6 6" />
                </svg>
                <div className="text-left">
                  <div className="font-medium">Descartar</div>
                  <div className="text-xs text-muted-foreground">Falsa alarma o duplicado</div>
                </div>
              </Button>
            </div>
            
            {selectedAction && (
              <div className="mt-4 p-4 rounded-lg bg-secondary border border-border">
                <p className="text-sm text-foreground mb-3">
                  <strong>Accion seleccionada:</strong> {getActionLabel(selectedAction)}
                </p>
                <p className="text-xs text-muted-foreground mb-3">
                  {getActionDescription(selectedAction)}
                </p>
                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    onClick={handleConfirm}
                    disabled={isConfirming}
                  >
                    {isConfirming ? 'Procesando...' : 'Confirmar Accion'}
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => setSelectedAction(null)}
                  >
                    Cancelar
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Scores Card */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
            Analisis NLP
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="grid gap-4 sm:grid-cols-2">
            {/* Urgency Score */}
            <div className="rounded-lg bg-secondary p-4">
              <div className="mb-2 text-sm text-muted-foreground">Puntuacion de Urgencia</div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-foreground">{incident.urgencyScore}</span>
                <span className="mb-1 text-muted-foreground">/ 10</span>
              </div>
              <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
                <div 
                  className="h-full rounded-full bg-priority-high transition-all"
                  style={{ width: `${incident.urgencyScore * 10}%` }}
                />
              </div>
            </div>
            
            {/* Impact Score */}
            <div className="rounded-lg bg-secondary p-4">
              <div className="mb-2 text-sm text-muted-foreground">Puntuacion de Impacto</div>
              <div className="flex items-end gap-2">
                <span className="text-3xl font-bold text-foreground">{incident.impactScore}</span>
                <span className="mb-1 text-muted-foreground">/ 10</span>
              </div>
              <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-muted">
                <div 
                  className="h-full rounded-full bg-primary transition-all"
                  style={{ width: `${incident.impactScore * 10}%` }}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Timestamps Card */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Registro de Tiempos
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="space-y-3">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Ingesta</span>
              <span className="font-mono text-sm text-foreground">
                {new Date(incident.createdAt).toLocaleString('es-ES')}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Procesado</span>
              <span className="font-mono text-sm text-foreground">
                {new Date(incident.processedAt).toLocaleString('es-ES')}
              </span>
            </div>
            {incident.confirmedAt && (
              <>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Confirmado</span>
                  <span className="font-mono text-sm text-foreground">
                    {new Date(incident.confirmedAt).toLocaleString('es-ES')}
                  </span>
                </div>
                <div className="flex justify-between border-t border-border pt-3">
                  <span className="font-semibold text-foreground">TTFD</span>
                  <span className="font-mono text-lg font-bold text-status-confirmed">
                    {formatTTFD(incident.ttfd)}
                  </span>
                </div>
              </>
            )}
          </div>
        </CardContent>
      </Card>
      
      {/* Action Buttons */}
      <div className="flex flex-wrap gap-3">
        <Button
          variant="outline"
          onClick={() => router.push('/queue')}
        >
          Volver a la Cola
        </Button>
        
        {incident.status === 'pendiente' && (
          <Button
            onClick={handleConfirm}
            disabled={isConfirming}
            className="flex-1 sm:flex-none"
          >
            {isConfirming ? (
              <>
                <svg
                  className="mr-2 h-4 w-4 animate-spin"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                  />
                </svg>
                Confirmando...
              </>
            ) : (
              <>
                <svg className="mr-2 h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                Confirmar Decision
              </>
            )}
          </Button>
        )}
      </div>
      
      {/* Protocol Viewer */}
      {getProtocolForIncident(incident.incidentType) && (
        <ProtocolViewer
          protocol={getProtocolForIncident(incident.incidentType)!}
          currentPriority={incident.priority}
        />
      )}
      
      {/* Human in the Loop Notice */}
      {incident.status === 'pendiente' && (
        <Card className="border-primary/30 bg-primary/5">
          <CardContent className="p-4">
            <div className="flex gap-3">
              <svg className="h-5 w-5 shrink-0 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div>
                <p className="font-medium text-foreground">Humano en el Bucle</p>
                <p className="text-sm text-muted-foreground">
                  Este sistema apoya decisiones, no decide. La decision solo existe cuando 
                  el operador confirma. El boton "Confirmar Decision" registra que usted, 
                  como operador humano, ha revisado y validado la informacion.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
