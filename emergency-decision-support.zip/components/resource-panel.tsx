'use client'

import { useState } from 'react'
import useSWR from 'swr'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import type { ResourceUnit, ResourceAvailability, UnitStatus } from '@/lib/resources/types'

const fetcher = (url: string) => fetch(url).then((res) => res.json())

interface ResourcePanelProps {
  incidentId?: string
  onAssign?: (unitId: string) => void
  compact?: boolean
}

const statusColors: Record<UnitStatus, string> = {
  disponible: 'bg-status-confirmed text-background',
  en_camino: 'bg-status-pending text-background',
  en_escena: 'bg-blue-500 text-white',
  operando: 'bg-primary text-primary-foreground',
  retornando: 'bg-secondary text-secondary-foreground',
  fuera_servicio: 'bg-muted text-muted-foreground',
}

const statusLabels: Record<UnitStatus, string> = {
  disponible: 'Disponible',
  en_camino: 'En Camino',
  en_escena: 'En Escena',
  operando: 'Operando',
  retornando: 'Retornando',
  fuera_servicio: 'Fuera de Servicio',
}

const typeIcons: Record<string, string> = {
  bomberos: 'M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z',
  ambulancia: 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z',
  samu: 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z',
  policia_local: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z',
  proteccion_civil: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z',
  hazmat: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z',
  grua: 'M9 17a2 2 0 11-4 0 2 2 0 014 0zM19 17a2 2 0 11-4 0 2 2 0 014 0z M13 16V6a1 1 0 00-1-1H4a1 1 0 00-1 1v10 M8 16h1m6 0h1',
}

function ResourceTypeIcon({ type }: { type: string }) {
  const path = typeIcons[type] || typeIcons.proteccion_civil
  return (
    <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={path} />
    </svg>
  )
}

function UnitCard({ 
  unit, 
  onAssign,
  showAssign = false 
}: { 
  unit: ResourceUnit
  onAssign?: (unitId: string) => void
  showAssign?: boolean 
}) {
  const [isAssigning, setIsAssigning] = useState(false)
  
  async function handleAssign() {
    if (!onAssign) return
    setIsAssigning(true)
    try {
      onAssign(unit.id)
    } finally {
      setIsAssigning(false)
    }
  }
  
  return (
    <div className="flex items-center gap-3 rounded-lg border border-border bg-card p-3 transition-colors hover:bg-secondary/30">
      <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${
        unit.status === 'disponible' ? 'bg-status-confirmed/20 text-status-confirmed' :
        unit.status === 'fuera_servicio' ? 'bg-muted text-muted-foreground' :
        'bg-status-pending/20 text-status-pending'
      }`}>
        <ResourceTypeIcon type={unit.type} />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <span className="font-bold text-foreground">{unit.code}</span>
          <Badge className={statusColors[unit.status]}>
            {statusLabels[unit.status]}
          </Badge>
        </div>
        <p className="text-sm text-muted-foreground truncate">{unit.name}</p>
        <div className="flex items-center gap-2 mt-1">
          {unit.radioChannel && (
            <span className="text-xs text-muted-foreground">
              {unit.radioChannel}
            </span>
          )}
          <span className="text-xs text-muted-foreground">
            {unit.crewSize} tripulantes
          </span>
        </div>
      </div>
      
      {showAssign && unit.status === 'disponible' && onAssign && (
        <Button
          size="sm"
          onClick={handleAssign}
          disabled={isAssigning}
        >
          {isAssigning ? 'Asignando...' : 'Asignar'}
        </Button>
      )}
    </div>
  )
}

function AvailabilityBar({ availability }: { availability: ResourceAvailability }) {
  const availablePercent = (availability.available / availability.total) * 100
  const enRoutePercent = (availability.enRoute / availability.total) * 100
  const onScenePercent = (availability.onScene / availability.total) * 100
  
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <span className="text-sm font-medium text-foreground capitalize">
          {availability.type.replace(/_/g, ' ')}
        </span>
        <span className="text-sm text-muted-foreground">
          {availability.available}/{availability.total} disponibles
        </span>
      </div>
      <div className="flex h-2 overflow-hidden rounded-full bg-muted">
        <div 
          className="bg-status-confirmed transition-all"
          style={{ width: `${availablePercent}%` }}
        />
        <div 
          className="bg-status-pending transition-all"
          style={{ width: `${enRoutePercent}%` }}
        />
        <div 
          className="bg-primary transition-all"
          style={{ width: `${onScenePercent}%` }}
        />
      </div>
    </div>
  )
}

export function ResourcePanel({ incidentId, onAssign, compact = false }: ResourcePanelProps) {
  const [activeTab, setActiveTab] = useState('overview')
  const [selectedType, setSelectedType] = useState<string | null>(null)
  
  const { data, error, isLoading, mutate } = useSWR('/api/resources', fetcher, {
    refreshInterval: 10000, // Refresh every 10 seconds
  })
  
  async function handleAssignUnit(unitId: string) {
    if (!incidentId) return
    
    try {
      const response = await fetch(`/api/resources/${unitId}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ incidentId }),
      })
      
      const result = await response.json()
      
      if (!result.success) {
        throw new Error(result.error)
      }
      
      mutate()
      onAssign?.(unitId)
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error al asignar recurso')
    }
  }
  
  if (isLoading) {
    return (
      <Card className="animate-pulse">
        <CardHeader>
          <div className="h-6 w-32 rounded bg-muted" />
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-16 rounded bg-muted" />
            ))}
          </div>
        </CardContent>
      </Card>
    )
  }
  
  if (error || !data?.success) {
    return (
      <Card className="border-destructive">
        <CardContent className="p-6 text-center">
          <p className="text-destructive">Error al cargar recursos</p>
          <Button variant="outline" className="mt-4 bg-transparent" onClick={() => mutate()}>
            Reintentar
          </Button>
        </CardContent>
      </Card>
    )
  }
  
  const { units, availability } = data.data as {
    units: ResourceUnit[]
    availability: ResourceAvailability[]
  }
  
  const filteredUnits = selectedType 
    ? units.filter(u => u.type === selectedType)
    : units
  
  const availableUnits = filteredUnits.filter(u => u.status === 'disponible')
  const activeUnits = filteredUnits.filter(u => 
    u.status !== 'disponible' && u.status !== 'fuera_servicio'
  )
  
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <svg className="h-5 w-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
          </svg>
          Gestion de Recursos
        </CardTitle>
      </CardHeader>
      
      <CardContent className="pt-0">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3 mb-4">
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="available">
              Disponibles ({availableUnits.length})
            </TabsTrigger>
            <TabsTrigger value="active">
              Activos ({activeUnits.length})
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            {availability.map((avail) => (
              <AvailabilityBar key={avail.type} availability={avail} />
            ))}
            
            <div className="flex flex-wrap gap-2 pt-2">
              <Button
                size="sm"
                variant={selectedType === null ? 'default' : 'outline'}
                onClick={() => setSelectedType(null)}
                className={selectedType === null ? '' : 'bg-transparent'}
              >
                Todos
              </Button>
              {availability.map((avail) => (
                <Button
                  key={avail.type}
                  size="sm"
                  variant={selectedType === avail.type ? 'default' : 'outline'}
                  onClick={() => setSelectedType(avail.type)}
                  className={selectedType === avail.type ? '' : 'bg-transparent'}
                >
                  {avail.type.replace(/_/g, ' ')}
                </Button>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="available" className="space-y-3">
            {availableUnits.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-4">
                No hay unidades disponibles{selectedType ? ` de tipo ${selectedType}` : ''}
              </p>
            ) : (
              availableUnits.map((unit) => (
                <UnitCard
                  key={unit.id}
                  unit={unit}
                  onAssign={incidentId ? handleAssignUnit : undefined}
                  showAssign={!!incidentId}
                />
              ))
            )}
          </TabsContent>
          
          <TabsContent value="active" className="space-y-3">
            {activeUnits.length === 0 ? (
              <p className="text-center text-sm text-muted-foreground py-4">
                No hay unidades activas{selectedType ? ` de tipo ${selectedType}` : ''}
              </p>
            ) : (
              activeUnits.map((unit) => (
                <UnitCard key={unit.id} unit={unit} />
              ))
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
