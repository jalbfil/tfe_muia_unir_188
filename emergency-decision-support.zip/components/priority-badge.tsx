import { cn } from '@/lib/utils'
import type { PriorityLevel } from '@/lib/types'
import { getPriorityLabel } from '@/lib/nlp-engine'

interface PriorityBadgeProps {
  priority: PriorityLevel
  size?: 'sm' | 'md' | 'lg'
}

/**
 * Priority Badge Component
 * 
 * Displays the priority level of an incident with
 * appropriate color coding.
 */
export function PriorityBadge({ priority, size = 'md' }: PriorityBadgeProps) {
  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-xs',
    lg: 'px-3 py-1.5 text-sm',
  }
  
  const colorClasses: Record<PriorityLevel, string> = {
    critica: 'bg-priority-critical/20 text-priority-critical border-priority-critical/50',
    alta: 'bg-priority-high/20 text-priority-high border-priority-high/50',
    media: 'bg-priority-medium/20 text-priority-medium border-priority-medium/50',
    baja: 'bg-priority-low/20 text-priority-low border-priority-low/50',
  }
  
  return (
    <span
      className={cn(
        'inline-flex items-center rounded-md border font-semibold uppercase tracking-wide',
        sizeClasses[size],
        colorClasses[priority]
      )}
    >
      {getPriorityLabel(priority)}
    </span>
  )
}
