'use client'

import React from "react"

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { SAMPLE_REPORTS } from '@/lib/sample-data'
import { VoiceRecorder } from '@/components/voice-recorder'

/**
 * Incident Input Form Component
 * 
 * Allows operators to input emergency text reports for processing.
 * Includes sample data for demonstration purposes.
 */
export function IncidentInputForm() {
  const router = useRouter()
  const [text, setText] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    
    if (!text.trim()) {
      setError('Por favor, introduce el texto del aviso de emergencia.')
      return
    }
    
    setIsProcessing(true)
    setError(null)
    
    try {
      const response = await fetch('/api/incidents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: text.trim() }),
      })
      
      const result = await response.json()
      
      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Error al procesar el incidente')
      }
      
      // Clear form and redirect to queue
      setText('')
      router.push('/queue')
      router.refresh()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setIsProcessing(false)
    }
  }
  
  function loadSample(sampleText: string) {
    setText(sampleText)
    setError(null)
  }
  
  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {/* Main Input Form */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Nuevo Aviso de Emergencia</CardTitle>
          <CardDescription>
            Introduce el texto del aviso, informe o comunicacion de emergencia.
            El sistema extraera automaticamente la informacion relevante.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Voice Input Section */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Entrada por Voz
              </label>
              <VoiceRecorder 
                onTranscript={(transcribedText) => {
                  setText(transcribedText)
                  setError(null)
                }}
                disabled={isProcessing}
              />
            </div>
            
            <div className="relative flex items-center py-2">
              <div className="grow border-t border-border" />
              <span className="mx-4 shrink text-xs text-muted-foreground">o escribe manualmente</span>
              <div className="grow border-t border-border" />
            </div>
            
            {/* Text Input Section */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Texto del Aviso
              </label>
              <Textarea
                placeholder="Escribe o pega aqui el texto del aviso de emergencia...&#10;&#10;Ejemplo: Se ha declarado un incendio en la Calle Mayor 45. Hay humo visible y se reportan personas atrapadas."
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="min-h-[200px] resize-none font-mono text-sm"
                disabled={isProcessing}
              />
              <p className="text-xs text-muted-foreground">
                {text.length} caracteres
              </p>
            </div>
            
            {error && (
              <div className="rounded-md bg-destructive/10 p-3 text-sm text-destructive">
                {error}
              </div>
            )}
            
            <div className="flex gap-3">
              <Button 
                type="submit" 
                disabled={isProcessing || !text.trim()}
                className="min-w-[140px]"
              >
                {isProcessing ? (
                  <>
                    <svg
                      className="mr-2 h-4 w-4 animate-spin"
                      fill="none"
                      viewBox="0 0 24 24"
                    >
                      <circle
                        className="opacity-25"
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeWidth="4"
                      />
                      <path
                        className="opacity-75"
                        fill="currentColor"
                        d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"
                      />
                    </svg>
                    Procesando...
                  </>
                ) : (
                  'Procesar Aviso'
                )}
              </Button>
              
              <Button 
                type="button" 
                variant="outline"
                onClick={() => setText('')}
                disabled={isProcessing || !text}
              >
                Limpiar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
      
      {/* Sample Data Panel */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Ejemplos de Prueba</CardTitle>
          <CardDescription>
            Carga un aviso de ejemplo para probar el sistema.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 max-h-[400px] overflow-y-auto pr-2">
            {SAMPLE_REPORTS.map((sample) => (
              <button
                key={sample.id}
                type="button"
                onClick={() => loadSample(sample.text)}
                className="w-full rounded-md border border-border p-3 text-left text-sm transition-colors hover:bg-secondary"
                disabled={isProcessing}
              >
                <span className="font-medium text-foreground">
                  {sample.title}
                </span>
                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">
                  {sample.text.substring(0, 100)}...
                </p>
              </button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
