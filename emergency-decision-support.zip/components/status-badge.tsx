import { cn } from '@/lib/utils'
import type { IncidentStatus } from '@/lib/types'

interface StatusBadgeProps {
  status: IncidentStatus
  size?: 'sm' | 'md'
}

/**
 * Status Badge Component
 * 
 * Displays the confirmation status of an incident.
 */
export function StatusBadge({ status, size = 'md' }: StatusBadgeProps) {
  const sizeClasses = {
    sm: 'px-2 py-0.5 text-xs',
    md: 'px-2.5 py-1 text-xs',
  }
  
  const labels: Record<IncidentStatus, string> = {
    pendiente: 'Pendiente',
    confirmado: 'Confirmado',
  }
  
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-md font-medium',
        sizeClasses[size],
        status === 'pendiente'
          ? 'bg-status-pending/20 text-status-pending'
          : 'bg-status-confirmed/20 text-status-confirmed'
      )}
    >
      <span
        className={cn(
          'h-1.5 w-1.5 rounded-full',
          status === 'pendiente'
            ? 'animate-pulse bg-status-pending'
            : 'bg-status-confirmed'
        )}
      />
      {labels[status]}
    </span>
  )
}
