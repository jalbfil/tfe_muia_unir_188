import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { PriorityBadge } from '@/components/priority-badge'
import { StatusBadge } from '@/components/status-badge'
import { getIncidentTypeLabel, formatTTFD } from '@/lib/nlp-engine'
import type { Incident } from '@/lib/types'
import { cn } from '@/lib/utils'

interface IncidentCardProps {
  incident: Incident
}

/**
 * Incident Card Component
 * 
 * Displays a summary of an incident in the queue view.
 * Clicking navigates to the detail view.
 */
export function IncidentCard({ incident }: IncidentCardProps) {
  const timeAgo = getTimeAgo(incident.createdAt)
  
  return (
    <Link href={`/incident/${incident.id}`}>
      <Card
        className={cn(
          'transition-all hover:border-primary/50 hover:bg-secondary/50',
          incident.status === 'pendiente' && 'border-l-4',
          incident.priority === 'critica' && 'border-l-priority-critical',
          incident.priority === 'alta' && 'border-l-priority-high',
          incident.priority === 'media' && 'border-l-priority-medium',
          incident.priority === 'baja' && 'border-l-priority-low'
        )}
      >
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-4">
            {/* Left: Main info */}
            <div className="min-w-0 flex-1 space-y-2">
              <div className="flex flex-wrap items-center gap-2">
                <PriorityBadge priority={incident.priority} />
                <StatusBadge status={incident.status} size="sm" />
                <span className="text-xs text-muted-foreground">
                  {timeAgo}
                </span>
              </div>
              
              <h3 className="font-semibold text-foreground">
                {getIncidentTypeLabel(incident.incidentType)}
              </h3>
              
              {incident.location && (
                <p className="flex items-center gap-1.5 text-sm text-muted-foreground">
                  <svg className="h-4 w-4 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span className="truncate">{incident.location}</span>
                </p>
              )}
              
              <p className="line-clamp-2 text-sm text-muted-foreground">
                {incident.rawText}
              </p>
            </div>
            
            {/* Right: Scores and TTFD */}
            <div className="shrink-0 text-right">
              <div className="space-y-1 text-xs">
                <div className="text-muted-foreground">
                  Urgencia: <span className="font-mono font-semibold text-foreground">{incident.urgencyScore}/10</span>
                </div>
                <div className="text-muted-foreground">
                  Impacto: <span className="font-mono font-semibold text-foreground">{incident.impactScore}/10</span>
                </div>
                {incident.ttfd !== null && (
                  <div className="mt-2 rounded bg-status-confirmed/10 px-2 py-1 text-status-confirmed">
                    TTFD: {formatTTFD(incident.ttfd)}
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </Link>
  )
}

/**
 * Helper function to format relative time
 */
function getTimeAgo(dateString: string): string {
  const date = new Date(dateString)
  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffSecs = Math.floor(diffMs / 1000)
  const diffMins = Math.floor(diffSecs / 60)
  const diffHours = Math.floor(diffMins / 60)
  
  if (diffSecs < 60) return 'Hace unos segundos'
  if (diffMins < 60) return `Hace ${diffMins} min`
  if (diffHours < 24) return `Hace ${diffHours}h`
  return date.toLocaleDateString('es-ES')
}
